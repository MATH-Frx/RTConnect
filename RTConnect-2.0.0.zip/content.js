// RTConnect Content Script - Version avec mini-dashboard
console.log('🚀 RTConnect Content Script chargé - URL:', window.location.href);

// Variables globales
let processedRDSOnPage = new Set();
let rdsCache = new Map();
let retryQueue = new Map();
let activeDashboards = new Map(); // Pour gérer plusieurs dashboards

// Configuration retry
const RETRY_INTERVAL = 5 * 60 * 1000; // 5 minutes
const MAX_RETRIES = 3; // Maximum 3 essais

// Styles CSS pour le dashboard
const dashboardStyles = `
  @keyframes rtconnect-fadeInOverlay {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  @keyframes rtconnect-fadeIn {
    from {
      opacity: 0;
      transform: translate(-50%, -48%);
    }
    to {
      opacity: 1;
      transform: translate(-50%, -50%);
    }
  }

  .rtconnect-dashboard {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    border-radius: 12px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
    padding: 0;
    z-index: 2147483647;
    max-width: 650px;
    width: 98vw;
    max-height: 95vh;
    overflow: hidden;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    animation: rtconnect-fadeIn 0.3s ease-out;
    border: 1px solid #e0e0e0;
  }

  .rtconnect-dashboard-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(2px);
    z-index: 2147483646;
    animation: rtconnect-fadeInOverlay 0.3s ease-out;
  }

  .rtconnect-dashboard-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .rtconnect-dashboard-title {
    font-size: 18px;
    font-weight: 600;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .rtconnect-dashboard-close {
    background: none;
    border: none;
    color: white;
    font-size: 24px;
    cursor: pointer;
    padding: 4px;
    border-radius: 4px;
    transition: background 0.2s;
  }

  .rtconnect-dashboard-close:hover {
    background: rgba(255, 255, 255, 0.2);
  }

  .rtconnect-dashboard-content {
    padding: 0;
    max-height: 80vh;
    overflow: hidden;
    background: white;
  }

  .rtconnect-tabs {
    display: flex;
    background: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
  }

  .rtconnect-tab {
    flex: 1;
    padding: 12px 16px;
    background: transparent;
    border: none;
    cursor: pointer;
    font-weight: 600;
    font-size: 13px;
    color: #6c757d;
    text-align: center;
    transition: all 0.3s ease;
    position: relative;
  }

  .rtconnect-tab:hover {
    background: #e9ecef;
    color: #495057;
  }

  .rtconnect-tab.active {
    color: #667eea;
    background: white;
  }

  .rtconnect-tab.active::after {
    content: '';
    position: absolute;
    bottom: -2px;
    left: 0;
    right: 0;
    height: 2px;
    background: #667eea;
  }

  .rtconnect-tab-badge {
    background: #6c757d;
    color: white;
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 10px;
    margin-left: 6px;
  }

  .rtconnect-tab.active .rtconnect-tab-badge {
    background: #667eea;
  }

  .rtconnect-tab-content {
    padding: 20px;
    height: calc(80vh - 60px);
    overflow-y: auto;
  }

  .rtconnect-tab-pane {
    display: none;
  }

  .rtconnect-tab-pane.active {
    display: block;
  }

  .rtconnect-info-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 12px;
  }

  @media (max-width: 700px) {
    .rtconnect-info-grid {
      grid-template-columns: 1fr;
    }
  }

  .rtconnect-info-card {
    background: white;
    border-radius: 8px;
    padding: 14px;
    border: 1px solid #e0e0e0;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    transition: all 0.2s ease;
  }

  .rtconnect-info-card:hover {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transform: translateY(-1px);
  }

  .rtconnect-info-card.tech-info {
    border-left: 4px solid #0d6efd;
    background: linear-gradient(135deg, #f0f8ff 0%, #e6f3ff 100%);
  }

  .rtconnect-info-card.radius-attr {
    border-left: 4px solid #ffc107;
    background: linear-gradient(135deg, #fffdf0 0%, #fefcf0 100%);
    font-family: 'Courier New', monospace;
    font-size: 12px;
  }

  .rtconnect-status-card {
    grid-column: 1 / -1;
    text-align: center;
    padding: 16px;
    border-radius: 8px;
    font-weight: 600;
    margin-bottom: 16px;
  }

  .rtconnect-status-card.loading {
    background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
    border: 1px solid #ffc107;
    color: #856404;
  }

  .rtconnect-status-card.success {
    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
    border: 1px solid #28a745;
    color: #155724;
  }

  .rtconnect-info-row {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    min-height: 32px;
  }

  .rtconnect-info-label {
    flex: 0 0 120px;
    font-weight: 600;
    color: #495057;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    line-height: 1.4;
    padding-top: 2px;
  }

  .rtconnect-info-value {
    flex: 1;
    color: #212529;
    font-size: 14px;
    font-weight: 500;
    line-height: 1.4;
    word-break: break-word;
    min-height: 20px;
    display: flex;
    align-items: center;
  }

  .rtconnect-copy-button {
    flex: 0 0 auto;
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    color: #6c757d;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
    cursor: pointer;
    transition: all 0.2s;
    margin-left: 8px;
  }

  .rtconnect-copy-button:hover {
    background: #e9ecef;
    color: #495057;
    transform: scale(1.05);
  }

  .rtconnect-copy-button.copied {
    background: #d4edda;
    color: #155724;
    border-color: #c3e6cb;
  }

  .rtconnect-info-value.empty {
    color: #6c757d;
    font-style: italic;
  }

  .rtconnect-info-value.loading {
    color: #856404;
    font-style: italic;
    animation: rtconnect-pulse 1.5s ease-in-out infinite;
  }

  .rtconnect-attribut-item {
    padding: 8px 10px;
    background: rgba(102, 126, 234, 0.1);
    border-radius: 6px;
    margin-bottom: 6px;
    font-family: 'SF Mono', Monaco, 'Cascadia Code', 'Consolas', 'Liberation Mono', 'Menlo', monospace;
    font-size: 13px;
    border-left: 3px solid #667eea;
    line-height: 1.5;
    position: relative;
  }

  .rtconnect-attribut-name {
    font-weight: 700;
    color: #495057;
    font-size: 14px;
  }

  .rtconnect-attribut-op {
    color: #6c757d;
    margin: 0 8px;
    font-weight: 600;
    font-size: 13px;
  }

  .rtconnect-attribut-value {
    color: #212529;
    font-size: 13px;
    font-weight: 600;
  }

  .rtconnect-attribut-copy {
    position: absolute;
    top: 50%;
    right: 8px;
    transform: translateY(-50%);
    background: rgba(0, 0, 0, 0.05);
    border: 1px solid rgba(0, 0, 0, 0.1);
    color: #6c757d;
    padding: 2px 6px;
    font-size: 10px;
    border-radius: 4px;
    cursor: pointer;
    opacity: 0;
    transition: all 0.2s;
  }

  .rtconnect-attribut-item:hover .rtconnect-attribut-copy {
    opacity: 0.7;
  }

  .rtconnect-attribut-copy:hover {
    opacity: 1;
    background: rgba(0, 0, 0, 0.1);
    color: #495057;
  }

  .rtconnect-status-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .rtconnect-status-badge.success {
    background: #d4edda;
    color: #155724;
  }

  .rtconnect-status-badge.loading {
    background: #fff3cd;
    color: #856404;
  }

  .rtconnect-status-badge.error {
    background: #f8d7da;
    color: #721c24;
  }

  .rtconnect-dashboard-footer {
    padding: 16px 20px;
    background: #f8f9fa;
    border-top: 1px solid #dee2e6;
    font-size: 12px;
    color: #6c757d;
    text-align: center;
  }

  .rtconnect-rds-button {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    color: white !important;
    border: none !important;
    padding: 4px 8px !important;
    border-radius: 6px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    text-decoration: none !important;
    display: inline-flex !important;
    align-items: center !important;
    gap: 4px !important;
    transition: all 0.3s ease !important;
    box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3) !important;
  }

  .rtconnect-rds-button:hover {
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4) !important;
  }

  .rtconnect-rds-button.loading {
    background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%) !important;
    box-shadow: 0 2px 8px rgba(255, 193, 7, 0.3) !important;
  }

  .rtconnect-rds-button.error {
    background: linear-gradient(135deg, #6c757d 0%, #495057 100%) !important;
    box-shadow: 0 2px 8px rgba(108, 117, 125, 0.3) !important;
  }

  .rtconnect-title-copy-button {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.2s;
    opacity: 0.8;
  }

  .rtconnect-title-copy-button:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.05);
  }

  .rtconnect-title-copy-button.copied {
    background: rgba(76, 175, 80, 0.8);
    color: white;
    border-color: rgba(76, 175, 80, 1);
  }

  .rtconnect-nav-button {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s;
    opacity: 0.8;
  }

  .rtconnect-nav-button:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
  }

  .rtconnect-nav-counter {
    background: rgba(255, 255, 255, 0.2);
    color: white;
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    opacity: 0.9;
  }

  .rtconnect-rds-link-button {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.2s;
    opacity: 0.8;
  }

  .rtconnect-rds-link-button:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.05);
  }

  .rtconnect-nav-button.active {
    background: rgba(255, 255, 255, 0.4);
    border-color: rgba(255, 255, 255, 0.6);
  }

  .rtconnect-info-row {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    border-bottom: 1px solid #dee2e6;
    gap: 8px;
  }

  .rtconnect-info-row:last-child {
    border-bottom: none;
  }

  .rtconnect-info-row.rtconnect-separator {
    background: #e9ecef;
    font-weight: 600;
    border-bottom: 2px solid #6c757d;
    margin-top: 8px;
  }

  .rtconnect-info-row.tech-info {
    background: rgba(13, 110, 253, 0.1);
    border-left: 3px solid #0d6efd;
  }

  .rtconnect-info-row.radius-attr {
    background: rgba(255, 193, 7, 0.1);
    border-left: 3px solid #ffc107;
    font-size: 12px;
  }

  .rtconnect-info-label {
    flex: 0 0 auto;
    font-weight: 600;
    color: #495057;
    min-width: 140px;
    font-size: 13px;
  }

  .rtconnect-info-value {
    flex: 1;
    color: #212529;
    font-size: 13px;
    word-break: break-all;
  }

  @keyframes rtconnect-pulse {
    0% { opacity: 0.6; }
    50% { opacity: 1; }
    100% { opacity: 0.6; }
  }

  .rtconnect-status-row {
    background: #e8f4fd;
    border: 1px solid #b8daff;
    border-radius: 6px;
    padding: 12px;
    margin-bottom: 16px;
    text-align: center;
    font-weight: 600;
  }

  .rtconnect-status-row.loading {
    background: #fff3cd;
    border-color: #ffeaa7;
    color: #856404;
  }

  .rtconnect-status-row.success {
    background: #d4edda;
    border-color: #c3e6cb;
    color: #155724;
  }
`;

// Fonction pour copier du texte dans le presse-papier
async function copyToClipboard(text) {
  try {
    // Essayer d'abord l'API moderne
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }

    // Fallback pour les contextes non sécurisés ou les navigateurs plus anciens
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
      document.execCommand('copy');
      textArea.remove();
      return true;
    } catch (err) {
      console.error('Erreur execCommand:', err);
      textArea.remove();
      return false;
    }
  } catch (err) {
    console.error('Erreur copyToClipboard:', err);
    return false;
  }
}

// Fonction pour gérer la copie avec retour visuel
async function handleCopy(value, button, isAttribute = false) {
  if (!value || !button) return;
  
  console.log('📋 Tentative de copie:', value);
  
  try {
    const success = await copyToClipboard(value);
    if (success) {
      const originalText = button.innerHTML;
      const originalBackground = button.style.background;
      
      if (isAttribute) {
        button.style.background = '#28a745';
      } else {
        button.classList.add('copied');
      }
      button.innerHTML = '✅';
      
      setTimeout(() => {
        if (button && button.isConnected) {
          if (isAttribute) {
            button.style.background = originalBackground;
          } else {
            button.classList.remove('copied');
          }
          button.innerHTML = originalText;
        }
      }, 1500);
      
      console.log('✅ Copié avec succès:', value);
    } else {
      throw new Error('Échec de la copie');
    }
  } catch (error) {
    console.error('❌ Erreur de copie:', error);
    const originalText = button.innerHTML;
    const originalBackground = button.style.background;
    
    if (isAttribute) {
      button.style.background = '#dc3545';
    }
    button.innerHTML = '❌';
    
    setTimeout(() => {
      if (button && button.isConnected) {
        if (isAttribute) {
          button.style.background = originalBackground;
        }
        button.innerHTML = originalText;
      }
    }, 1500);
  }
}

// Injecter les styles CSS
function injectStyles() {
  if (!document.getElementById('rtconnect-styles')) {
    const styleElement = document.createElement('style');
    styleElement.id = 'rtconnect-styles';
    styleElement.textContent = dashboardStyles;
    document.head.appendChild(styleElement);
  }
}

// Fonction pour créer et afficher le dashboard
function createDashboard(rdsCode, rdsData) {
  // Fermer les autres dashboards
  closeDashboard();

  // Créer l'overlay
  const overlay = document.createElement('div');
  overlay.className = 'rtconnect-dashboard-overlay';
  overlay.onclick = () => closeDashboard();

  // Créer le dashboard
  const dashboard = document.createElement('div');
  dashboard.className = 'rtconnect-dashboard';
  dashboard.id = `rtconnect-dashboard-${rdsCode}`;

  // Header
  const header = document.createElement('div');
  header.className = 'rtconnect-dashboard-header';
  
  // Générer les boutons de navigation s'il y a plusieurs RDS
  const allRDSButtons = document.querySelectorAll('.rtconnect-rds-button');
  const allRDSCodes = [...new Set(Array.from(allRDSButtons).map(btn => btn.dataset.rdsCode))];
  
  let navigationButtons = '';
  if (allRDSCodes.length > 1) {
    const currentIndex = allRDSCodes.indexOf(rdsCode);
    const prevCode = allRDSCodes[currentIndex - 1] || allRDSCodes[allRDSCodes.length - 1];
    const nextCode = allRDSCodes[currentIndex + 1] || allRDSCodes[0];
    
    navigationButtons = `
      <button class="rtconnect-nav-button" data-nav-rds="${prevCode}" title="RDS précédent (${prevCode})">
        ⬅️
      </button>
      <span class="rtconnect-nav-counter">${currentIndex + 1}/${allRDSCodes.length}</span>
      <button class="rtconnect-nav-button" data-nav-rds="${nextCode}" title="RDS suivant (${nextCode})">
        ➡️
      </button>
    `;
  }
  
  header.innerHTML = `
    <div style="display: flex; align-items: center; gap: 8px;">
      <h3 class="rtconnect-dashboard-title">📡 ${rdsCode}</h3>
      <button class="rtconnect-title-copy-button" data-copy-title="${rdsCode}" title="Copier le code RDS">📋</button>
      <button class="rtconnect-rds-link-button" data-rds-link="${rdsCode}" title="Accéder au RDS (${rdsCode})">🔗</button>
    </div>
    <div style="display: flex; gap: 8px; align-items: center;">
      ${navigationButtons}
      <button class="rtconnect-dashboard-close">×</button>
    </div>
  `;

  // Content
  const content = document.createElement('div');
  content.className = 'rtconnect-dashboard-content';
  
  // Créer les onglets
  const tabsContainer = document.createElement('div');
  tabsContainer.className = 'rtconnect-tabs';
  
  // Compter les données pour les badges
  const techInfoCount = rdsData.infosTechniques ? Object.keys(rdsData.infosTechniques).length : 0;
  const radiusAttrCount = rdsData.attributsRadius ? rdsData.attributsRadius.length : 0;
  
  tabsContainer.innerHTML = `
    <button class="rtconnect-tab active" data-tab="general">
      📊 Général
    </button>
    <button class="rtconnect-tab" data-tab="tech" ${techInfoCount === 0 ? 'style="opacity: 0.5;"' : ''}>
      🔧 Technique
      ${techInfoCount > 0 ? `<span class="rtconnect-tab-badge">${techInfoCount}</span>` : ''}
    </button>
    <button class="rtconnect-tab" data-tab="radius" ${radiusAttrCount === 0 ? 'style="opacity: 0.5;"' : ''}>
      📋 Radius
      ${radiusAttrCount > 0 ? `<span class="rtconnect-tab-badge">${radiusAttrCount}</span>` : ''}
    </button>
  `;
  
  // Créer le contenu des onglets
  const tabContent = document.createElement('div');
  tabContent.className = 'rtconnect-tab-content';
  
  // Onglet Général
  const generalPane = document.createElement('div');
  generalPane.className = 'rtconnect-tab-pane active';
  generalPane.dataset.pane = 'general';
  
  const generalGrid = document.createElement('div');
  generalGrid.className = 'rtconnect-info-grid';
  
  // Informations principales
  const mainItems = [
    { label: '🏢 Site', value: rdsData.site, field: 'site' },
    { label: '📦 Offre', value: rdsData.offre, field: 'offre' },
    { label: '📡 IP Supervision', value: rdsData.ipSupervision, field: 'ipSupervision' },
    { label: '🌐 IP WAN CPE', value: rdsData.ipWanCpe, field: 'ipWanCpe' },
    { label: '👤 Login Radius', value: rdsData.loginRadius, field: 'loginRadius' },
    { label: '🔑 Password Radius', value: rdsData.passwordRadius, field: 'passwordRadius' },
    { label: '👥 Groupe Radius', value: rdsData.groupeRadius, field: 'groupeRadius' }
  ];
  
  const mainCardsHtml = mainItems.map(item => {
    const value = item.value || 'Non disponible';
    const isEmpty = !item.value;
    return `
      <div class="rtconnect-info-card">
        <div class="rtconnect-info-row">
          <div class="rtconnect-info-label">${item.label.replace(/[📡🌐👤🔑👥🏢📦]/g, '').trim()}</div>
          <div class="rtconnect-info-value ${isEmpty ? 'empty' : ''}">${value}</div>
          ${!isEmpty ? `<button class="rtconnect-copy-button" data-copy-value="${value}" title="Copier">📋</button>` : ''}
        </div>
      </div>
    `;
  }).join('');
  
  generalGrid.innerHTML = mainCardsHtml;
  generalPane.appendChild(generalGrid);
  
  // Onglet Technique
  const techPane = document.createElement('div');
  techPane.className = 'rtconnect-tab-pane';
  techPane.dataset.pane = 'tech';
  
  const techGrid = document.createElement('div');
  techGrid.className = 'rtconnect-info-grid';
  
  if (rdsData.infosTechniques && Object.keys(rdsData.infosTechniques).length > 0) {
    const techCardsHtml = Object.entries(rdsData.infosTechniques).map(([key, info]) => `
      <div class="rtconnect-info-card tech-info">
        <div class="rtconnect-info-row">
          <div class="rtconnect-info-label">${info.label}</div>
          <div class="rtconnect-info-value">${info.value}</div>
          <button class="rtconnect-copy-button" data-copy-value="${info.value}" title="Copier">📋</button>
        </div>
      </div>
    `).join('');
    techGrid.innerHTML = techCardsHtml;
  } else {
    techGrid.innerHTML = `
      <div class="rtconnect-info-card" style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #6c757d;">
        <div style="font-size: 48px; margin-bottom: 16px;">🔧</div>
        <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">Aucune information technique</div>
        <div style="font-size: 14px;">Les données techniques ne sont pas disponibles pour ce RDS</div>
      </div>
    `;
  }
  
  techPane.appendChild(techGrid);
  
  // Onglet Radius
  const radiusPane = document.createElement('div');
  radiusPane.className = 'rtconnect-tab-pane';
  radiusPane.dataset.pane = 'radius';
  
  const radiusGrid = document.createElement('div');
  radiusGrid.className = 'rtconnect-info-grid';
  
  if (rdsData.attributsRadius && rdsData.attributsRadius.length > 0) {
    const radiusCardsHtml = rdsData.attributsRadius.map((attr, index) => {
      const attrValue = `${attr.nom} ${attr.operateur} ${attr.valeur}`;
      return `
        <div class="rtconnect-info-card radius-attr">
          <div class="rtconnect-info-row">
            <div class="rtconnect-info-label">Attribut ${index + 1}</div>
            <div class="rtconnect-info-value">${attrValue}</div>
            <button class="rtconnect-copy-button" data-copy-value="${attrValue}" title="Copier">📋</button>
          </div>
        </div>
      `;
    }).join('');
    
    // Bouton copier tout
    const allAttributsText = rdsData.attributsRadius
      .map(attr => `${attr.nom} ${attr.operateur} ${attr.valeur}`)
      .join('\n');
    
    const copyAllCard = `
      <div class="rtconnect-info-card" style="grid-column: 1 / -1; text-align: center; background: linear-gradient(135deg, #e9ecef 0%, #f8f9fa 100%);">
        <div class="rtconnect-info-row" style="justify-content: center;">
          <button class="rtconnect-copy-button" data-copy-value="${allAttributsText}" title="Copier tous les attributs" style="background: #667eea; color: white; padding: 8px 16px; font-weight: 600;">
            📋 Copier tous les attributs (${rdsData.attributsRadius.length})
          </button>
        </div>
      </div>
    `;
    
    radiusGrid.innerHTML = radiusCardsHtml + copyAllCard;
  } else {
    radiusGrid.innerHTML = `
      <div class="rtconnect-info-card" style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #6c757d;">
        <div style="font-size: 48px; margin-bottom: 16px;">📋</div>
        <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">Aucun attribut Radius</div>
        <div style="font-size: 14px;">Aucun attribut Radius configuré pour ce RDS</div>
      </div>
    `;
  }
  
  radiusPane.appendChild(radiusGrid);
  
  // Assembler le contenu des onglets
  tabContent.appendChild(generalPane);
  tabContent.appendChild(techPane);
  tabContent.appendChild(radiusPane);
  
  content.appendChild(tabsContainer);
  content.appendChild(tabContent);

  // Footer
  const footer = document.createElement('div');
  footer.className = 'rtconnect-dashboard-footer';
  footer.innerHTML = '🚀 RTConnect - Données temps réel';

  // Assembler le dashboard
  dashboard.appendChild(header);
  dashboard.appendChild(content);
  dashboard.appendChild(footer);

  // Ajouter au DOM
  document.body.appendChild(overlay);
  document.body.appendChild(dashboard);

  // Gestionnaire de fermeture
  const closeButton = dashboard.querySelector('.rtconnect-dashboard-close');
  if (closeButton) {
    closeButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log('🔘 Fermeture dashboard via bouton');
      closeDashboard();
    });
  }

  // DÉLÉGATION D'ÉVÉNEMENTS pour tous les boutons de copie
  dashboard.addEventListener('click', async (e) => {
    const target = e.target;
    
    // Gérer les onglets
    if (target.matches('.rtconnect-tab')) {
      e.preventDefault();
      e.stopPropagation();
      
      const tabName = target.dataset.tab;
      if (tabName) {
        console.log('🔄 Changement d\'onglet vers:', tabName);
        
        // Mettre à jour les onglets actifs
        dashboard.querySelectorAll('.rtconnect-tab').forEach(tab => {
          tab.classList.remove('active');
        });
        target.classList.add('active');
        
        // Mettre à jour les contenus actifs
        dashboard.querySelectorAll('.rtconnect-tab-pane').forEach(pane => {
          pane.classList.remove('active');
        });
        const targetPane = dashboard.querySelector(`[data-pane="${tabName}"]`);
        if (targetPane) {
          targetPane.classList.add('active');
        }
      }
      return;
    }
    
    // Gérer les boutons de copie standard
    if (target.matches('.rtconnect-copy-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const valueTooCopy = target.dataset.copyValue;
      if (valueTooCopy) {
        console.log('🔍 Copie bouton standard:', valueTooCopy);
        await handleCopy(valueTooCopy, target);
      }
    }
    
    // Gérer le bouton de copie du titre RDS
    else if (target.matches('.rtconnect-title-copy-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const rdsCodeToCopy = target.dataset.copyTitle;
      if (rdsCodeToCopy) {
        console.log('🔍 Copie titre RDS:', rdsCodeToCopy);
        await handleCopy(rdsCodeToCopy, target);
      }
    }
    
    // Gérer le bouton de lien direct au RDS
    else if (target.matches('.rtconnect-rds-link-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const rdsCodeForLink = target.dataset.rdsLink;
      if (rdsCodeForLink) {
        const rdsUrl = `http://ref-technique.linkt.lan/abonnement/get/${rdsCodeForLink}#Provisioning`;
        console.log('🔗 Ouverture lien RDS:', rdsUrl);
        window.open(rdsUrl, '_blank');
      }
    }
    
    // Gérer les boutons de navigation entre RDS
    else if (target.matches('.rtconnect-nav-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const targetRDS = target.dataset.navRds;
      if (targetRDS) {
        console.log('🔄 Navigation vers RDS:', targetRDS);
        
        // Récupérer les données depuis le cache ou le bouton
        const cachedData = rdsCache.get(targetRDS);
        if (cachedData && cachedData.success) {
          createDashboard(targetRDS, cachedData.data);
        } else {
          // Créer le dashboard en mode chargement et lancer la requête
          createDashboard(targetRDS, null);
          
          // Trouver le bouton correspondant pour la requête
          const targetButton = Array.from(document.querySelectorAll('.rtconnect-rds-button'))
            .find(btn => btn.dataset.rdsCode === targetRDS);
          
          if (targetButton) {
            fetchRDSData(targetRDS, targetButton, true);
          }
        }
      }
    }
    
    // Gérer les boutons de copie d'attributs
    else if (target.matches('.rtconnect-attribut-copy')) {
      e.preventDefault();
      e.stopPropagation();
      
      const valueTooCopy = target.dataset.copyValue;
      if (valueTooCopy) {
        console.log('🔍 Copie attribut:', valueTooCopy);
        await handleCopy(valueTooCopy, target, true);
      }
    }
    
    // Gérer le bouton "Tout copier"
    else if (target.matches('.rtconnect-copy-all-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const valueTooCopy = target.dataset.copyAll;
      if (valueTooCopy) {
        console.log('🔍 Copie tout:', valueTooCopy);
        await handleCopy(valueTooCopy, target);
      }
    }
  });

  // Stocker la référence
  activeDashboards.set(rdsCode, { overlay, dashboard });
  
  // Si des IPs sont manquantes, lancer la récupération en arrière-plan
  const needsIPs = !rdsData?.ipSupervision || !rdsData?.ipWanCpe;
  if (needsIPs) {
    console.log(`🔄 Lancement récupération IPs en arrière-plan pour ${rdsCode}`);
    fetchIPsInBackground(rdsCode);
  }
}

// Fonction pour fermer tous les dashboards
function closeDashboard() {
  activeDashboards.forEach(({ overlay, dashboard }) => {
    if (overlay && overlay.parentNode) overlay.remove();
    if (dashboard && dashboard.parentNode) dashboard.remove();
  });
  activeDashboards.clear();
}

// Fonction pour mettre à jour un dashboard existant avec de nouvelles données
function updateDashboard(rdsCode, rdsData) {
  const dashboardElement = document.getElementById(`rtconnect-dashboard-${rdsCode}`);
  if (dashboardElement) {
    console.log(`🔄 Mise à jour du dashboard existant pour ${rdsCode}`);
    
    // Mettre à jour chaque carte individuellement
    updateDashboardCard(dashboardElement, 'site', rdsData?.site, '📍 Site');
    updateDashboardCard(dashboardElement, 'ipSupervision', rdsData?.ipSupervision, '📡 IP Supervision');
    updateDashboardCard(dashboardElement, 'ipWanCpe', rdsData?.ipWanCpe, '🌐 IP WAN CPE');
    updateDashboardCard(dashboardElement, 'loginRadius', rdsData?.loginRadius, '👤 Login Radius');
    updateDashboardCard(dashboardElement, 'passwordRadius', rdsData?.passwordRadius, '🔑 Password Radius');
    updateDashboardCard(dashboardElement, 'groupeRadius', rdsData?.groupeRadius, '👥 Groupe Radius');
    
    // Mettre à jour les attributs (plus complexe)
    updateAttributsCard(dashboardElement, rdsData?.attributsRadius);
    
    // Mettre à jour le statut général
    updateStatusCard(dashboardElement, rdsData);
  }
}

// Fonction pour mettre à jour une carte spécifique
function updateDashboardCard(dashboardElement, fieldName, value, label) {
  try {
    if (!dashboardElement || !dashboardElement.isConnected) {
      console.warn('⚠️ Dashboard non trouvé ou déconnecté du DOM');
      return;
    }

    const cards = Array.from(dashboardElement.querySelectorAll('.rtconnect-info-card')).filter(card => card.isConnected);
    if (!cards.length) {
      console.warn('⚠️ Aucune carte trouvée dans le dashboard');
      return;
    }

    cards.forEach(card => {
      try {
        const labelElement = card.querySelector('.rtconnect-info-label');
        if (!labelElement || !labelElement.isConnected) return;

        const cleanLabel = label.replace(/[📡🌐👤🔑👥📍]/g, '').trim();
        if (labelElement.textContent.includes(cleanLabel)) {
          const valueElement = card.querySelector('.rtconnect-info-value');
          if (!valueElement || !valueElement.isConnected) return;

          if (value) {
            valueElement.textContent = value;
            valueElement.classList.remove('empty', 'loading');
            
            // Mettre à jour le bouton copier existant s'il y en a un
            if (!label.includes('Statut')) {
              const copyButton = labelElement.querySelector('.rtconnect-copy-button');
              if (copyButton) {
                copyButton.dataset.copyValue = value;
              }
            }
            
            console.log(`✅ ${label} mis à jour: ${value}`);
          } else {
            valueElement.textContent = 'Non disponible';
            valueElement.classList.add('empty');
            valueElement.classList.remove('loading');
            
            // Supprimer l'attribut data du bouton copier
            const copyButton = labelElement.querySelector('.rtconnect-copy-button');
            if (copyButton) {
              copyButton.removeAttribute('data-copy-value');
            }
          }
        }
      } catch (cardError) {
        console.warn('⚠️ Erreur lors de la mise à jour d\'une carte:', cardError);
      }
    });
  } catch (error) {
    console.warn('⚠️ Erreur générale dans updateDashboardCard:', error);
  }
}

// Fonction pour mettre à jour les attributs
function updateAttributsCard(dashboardElement, attributsRadius) {
  const cards = dashboardElement.querySelectorAll('.rtconnect-info-card');
  cards.forEach(card => {
    const labelElement = card.querySelector('.rtconnect-info-label');
    if (labelElement && labelElement.textContent === '📋 Attributs Radius') {
      const valueElement = card.querySelector('.rtconnect-info-value');
      if (valueElement) {
        let attributsContent = 'Non disponible';
        if (attributsRadius && attributsRadius.length > 0) {
          // Créer une liste stylée des attributs avec boutons copier
          const attributsList = attributsRadius.map((attr, index) => {
            const attributValue = `${attr.nom}${attr.operateur}${attr.valeur}`;
            return `<div class="rtconnect-attribut-item">
              <span class="rtconnect-attribut-name">${attr.nom}</span>
              <span class="rtconnect-attribut-op">${attr.operateur}</span>
              <span class="rtconnect-attribut-value">${attr.valeur}</span>
              <button class="rtconnect-attribut-copy" data-copy-value="${attributValue}">📋</button>
            </div>`;
          }).join('');
          
          // Récupérer le code RDS depuis l'ID du dashboard
          const dashboardId = dashboardElement.id;
          const rdsCode = dashboardId.replace('rtconnect-dashboard-', '');
          const allAttributsText = attributsRadius
            .map(attr => `${attr.nom}${attr.operateur}${attr.valeur}`)
            .join('\n');
          const copyAllBtn = `<button class="rtconnect-copy-all-button" data-copy-all="${allAttributsText}">📋 Tout copier</button>`;
          
          attributsContent = `
            <div style="max-height: 250px; overflow-y: auto; border: 1px solid #dee2e6; border-radius: 6px; padding: 12px;">
              ${attributsList}
            </div>
            <div style="margin-top: 12px; font-size: 11px; color: #6c757d; border-top: 1px solid #dee2e6; padding-top: 12px; text-align: center; font-weight: 600; display: flex; justify-content: space-between; align-items: center;">
              <span>📊 ${attributsRadius.length} attribut(s) Radius configuré(s)</span>
              ${copyAllBtn}
            </div>
          `;
          valueElement.classList.remove('empty');
        } else {
          valueElement.classList.add('empty');
        }
        valueElement.innerHTML = attributsContent;
        console.log(`✅ Attributs Radius mis à jour: ${attributsRadius?.length || 0} attributs`);
      }
    }
  });
}

// Fonction pour mettre à jour le statut général
function updateStatusCard(dashboardElement, rdsData) {
  const cards = dashboardElement.querySelectorAll('.rtconnect-info-card');
  cards.forEach(card => {
    const labelElement = card.querySelector('.rtconnect-info-label');
    if (labelElement && labelElement.textContent === 'Statut') {
      const valueElement = card.querySelector('.rtconnect-info-value');
      if (valueElement) {
        const hasData = rdsData && (rdsData.site || rdsData.ipSupervision || rdsData.ipWanCpe || rdsData.loginRadius || rdsData.groupeRadius);
        const statusBadge = hasData ? 
          '<span class="rtconnect-status-badge success">✅ Données disponibles</span>' :
          '<span class="rtconnect-status-badge loading">🔄 Chargement...</span>';
        valueElement.innerHTML = statusBadge;
      }
    }
  });
}

// Fonction simple de détection et traitement RDS
function findAndProcessRDS() {
  console.log('🔍 Recherche de codes RDS dans la page...');
  
  const pageText = document.body.innerText || document.body.textContent || '';
  console.log('📄 Taille du texte de la page:', pageText.length, 'caractères');
  
  const rdsRegex = /\b([A-Z]{2}-\d{4}-[A-Z]{2})\b/g;
  const matches = pageText.match(rdsRegex);
  
  if (matches) {
    console.log('✅ Codes RDS trouvés:', matches);
    
    const uniqueRDS = [...new Set(matches)];
    uniqueRDS.forEach(rdsCode => {
      if (!processedRDSOnPage.has(rdsCode)) {
        console.log(`🎯 Traitement du code RDS: ${rdsCode}`);
        processedRDSOnPage.add(rdsCode);
        processRDSInPage(rdsCode);
      }
    });
  } else {
    console.log('❌ Aucun code RDS trouvé');
    
    const specificCode = 'TW-1126-HS';
    if (pageText.includes(specificCode)) {
      console.log(`✅ Code spécifique ${specificCode} trouvé dans le texte !`);
      processRDSInPage(specificCode);
    } else {
      console.log(`❌ Code spécifique ${specificCode} introuvable`);
    }
  }
}

// Fonction pour traiter un code RDS spécifique dans la page
function processRDSInPage(rdsCode) {
  console.log(`🔍 Traitement de ${rdsCode} dans la page...`);
  
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );
  
  const textNodes = [];
  let node;
  while (node = walker.nextNode()) {
    if (node.textContent.includes(rdsCode)) {
      textNodes.push(node);
    }
  }
  
  console.log(`📊 ${textNodes.length} nœuds contiennent ${rdsCode}`);
  
  textNodes.forEach(textNode => {
    replaceRDSInTextNode(textNode, rdsCode);
  });
}

// Fonction pour remplacer le code RDS dans un nœud de texte
function replaceRDSInTextNode(textNode, rdsCode) {
  const text = textNode.textContent;
  const index = text.indexOf(rdsCode);
  
  if (index === -1) return;
  
  console.log(`🔄 Remplacement de ${rdsCode} dans: "${text.substring(0, 50)}..."`);
  
  const beforeText = text.substring(0, index);
  const afterText = text.substring(index + rdsCode.length);
  
  // Créer le bouton RDS moderne
  const rdsButton = document.createElement('button');
  rdsButton.className = 'rtconnect-rds-button loading';
  rdsButton.innerHTML = `📡 ${rdsCode} <span style="font-size: 10px;">▼</span>`;
  rdsButton.dataset.rdsCode = rdsCode;
  
  // Gestionnaire de clic pour ouvrir le dashboard
  rdsButton.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    console.log(`🖱️ Ouverture dashboard pour ${rdsCode}`);
    
    const cachedData = rdsCache.get(rdsCode);
    if (cachedData && cachedData.success) {
      // Afficher immédiatement les données en cache
      createDashboard(rdsCode, cachedData.data);
    } else {
      // Afficher le dashboard en mode chargement
      createDashboard(rdsCode, null);
      
      // Lancer une nouvelle requête pour mettre à jour
      console.log(`🔄 Lancement requête pour mise à jour dashboard ${rdsCode}`);
      fetchRDSData(rdsCode, rdsButton, true); // true = dashboard ouvert
    }
  };
  
  // Récupérer les données via API
  fetchRDSData(rdsCode, rdsButton);
  
  // Remplacer le nœud de texte
  const parent = textNode.parentNode;
  if (parent) {
    parent.removeChild(textNode);
    
    if (beforeText) {
      parent.insertBefore(document.createTextNode(beforeText), null);
    }
    
    parent.insertBefore(rdsButton, null);
    
    if (afterText) {
      parent.insertBefore(document.createTextNode(afterText), null);
    }
    
    console.log(`✅ ${rdsCode} remplacé avec succès`);
  }
}

// Fonction pour récupérer les données RDS via API
async function fetchRDSData(rdsCode, buttonElement, isDashboardOpen = false) {
  try {
    if (rdsCache.has(rdsCode) && !isDashboardOpen) {
      console.log(`📦 Cache hit pour ${rdsCode}`);
      updateRDSButton(rdsCache.get(rdsCode), buttonElement, rdsCode);
      return;
    }
    
    console.log(`📡 Requête API pour ${rdsCode}...`);
    
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'fetchRDS', rdsCode: rdsCode },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error('❌ Erreur runtime:', chrome.runtime.lastError.message);
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            console.log(`📨 Réponse reçue du background script pour ${rdsCode}:`, response);
            resolve(response);
          }
        }
      );
    });

    if (response && response.success) {
      console.log(`✅ Données reçues pour ${rdsCode}:`, response.data);
      rdsCache.set(rdsCode, response);
      updateRDSButton(response, buttonElement, rdsCode);
      
      // Si le dashboard est ouvert, le mettre à jour
      if (isDashboardOpen) {
        console.log(`🎯 Mise à jour du dashboard ouvert pour ${rdsCode}`);
        updateDashboard(rdsCode, response.data);
      }
      
    } else {
      const errorMsg = response ? response.error : 'Réponse vide du background script';
      console.log(`⚠️ Problème API pour ${rdsCode}:`, errorMsg);
      scheduleRetry(rdsCode, buttonElement, errorMsg);
    }
    
  } catch (error) {
    console.log(`⚠️ Erreur fetchRDSData pour ${rdsCode}:`, error.message);
    scheduleRetry(rdsCode, buttonElement, error.message);
  }
}

// Fonction pour mettre à jour le bouton RDS
function updateRDSButton(data, buttonElement, rdsCode) {
  console.log(`🔍 Mise à jour bouton pour ${rdsCode}`, data);
  
  const rdsData = data.data || data;
  console.log(`🔍 Données extraites pour ${rdsCode}:`, {
    site: rdsData?.site,
    ipSupervision: rdsData?.ipSupervision,
    ipWanCpe: rdsData?.ipWanCpe,
    loginRadius: rdsData?.loginRadius,
    groupeRadius: rdsData?.groupeRadius,
    attributsRadius: rdsData?.attributsRadius?.length || 0
  });
  
  if (rdsData && (rdsData.site || rdsData.ipSupervision || rdsData.ipWanCpe || rdsData.loginRadius || rdsData.groupeRadius || (rdsData.attributsRadius && rdsData.attributsRadius.length > 0))) {
    // Succès - nettoyer le retry et remettre TOUS les boutons du même RDS en état normal
    if (retryQueue.has(rdsCode)) {
      const retryInfo = retryQueue.get(rdsCode);
      if (retryInfo.timeoutId) {
        clearTimeout(retryInfo.timeoutId);
      }
      retryQueue.delete(rdsCode);
      console.log(`✅ ${rdsCode} retiré de la queue de retry`);
    }
    
    // Mettre à jour TOUS les boutons avec ce code RDS
    const allRDSButtons = document.querySelectorAll(`[data-rds-code="${rdsCode}"]`);
    allRDSButtons.forEach(btn => {
      btn.className = 'rtconnect-rds-button';
      btn.innerHTML = `📡 ${rdsCode} <span style="font-size: 10px;">▼</span>`;
    });
    
    console.log(`✅ ${rdsCode} - ${allRDSButtons.length} bouton(s) mis à jour avec succès`);
  } else {
    console.log(`❌ Aucune donnée trouvée pour ${rdsCode}`);
    scheduleRetry(rdsCode, buttonElement, 'Aucune donnée trouvée');
  }
}

// Fonction pour programmer un retry
function scheduleRetry(rdsCode, buttonElement, reason) {
  if (retryQueue.has(rdsCode)) {
    const retryInfo = retryQueue.get(rdsCode);
    retryInfo.attempts++;
    
    if (retryInfo.attempts >= MAX_RETRIES) {
      console.log(`❌ ${rdsCode} - Maximum de tentatives atteint (${MAX_RETRIES})`);
      updateButtonOffline(buttonElement, rdsCode);
      retryQueue.delete(rdsCode);
      return;
    }
    
    console.log(`🔄 ${rdsCode} - Retry programmé (tentative ${retryInfo.attempts}/${MAX_RETRIES})`);
  } else {
    console.log(`⏰ ${rdsCode} - Premier retry programmé dans 5 minutes (raison: ${reason})`);
    retryQueue.set(rdsCode, { attempts: 1, buttonElement });
  }
  
  const retryInfo = retryQueue.get(rdsCode);
  const timeoutId = setTimeout(() => {
    console.log(`🔄 ${rdsCode} - Exécution du retry (tentative ${retryInfo.attempts}/${MAX_RETRIES})`);
    fetchRDSData(rdsCode, retryInfo.buttonElement);
  }, RETRY_INTERVAL);
  
  retryInfo.timeoutId = timeoutId;
  updateButtonRetrying(buttonElement, retryInfo.attempts);
}

// Fonction pour mettre à jour le bouton en mode retry
function updateButtonRetrying(buttonElement, attempt) {
  const rdsCode = buttonElement.dataset.rdsCode;
  if (rdsCode) {
    // Mettre à jour TOUS les boutons avec ce code RDS
    const allRDSButtons = document.querySelectorAll(`[data-rds-code="${rdsCode}"]`);
    allRDSButtons.forEach(btn => {
      btn.className = 'rtconnect-rds-button loading';
      btn.innerHTML = `⏳ ${rdsCode} (${attempt}/${MAX_RETRIES})`;
    });
    console.log(`🔄 ${rdsCode} - ${allRDSButtons.length} bouton(s) mis en mode retry (${attempt}/${MAX_RETRIES})`);
  }
}

// Fonction pour mettre à jour le bouton en mode hors ligne
function updateButtonOffline(buttonElement, rdsCode) {
  // Mettre à jour TOUS les boutons avec ce code RDS
  const allRDSButtons = document.querySelectorAll(`[data-rds-code="${rdsCode}"]`);
  allRDSButtons.forEach(btn => {
    btn.className = 'rtconnect-rds-button error';
    btn.innerHTML = `⚪ ${rdsCode} (Hors ligne)`;
  });
  console.log(`❌ ${rdsCode} - ${allRDSButtons.length} bouton(s) mis hors ligne`);
}

// Fonction pour récupérer les IPs en arrière-plan
async function fetchIPsInBackground(rdsCode) {
  try {
    console.log(`🔄 Récupération IPs en arrière-plan pour ${rdsCode}...`);
    
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'fetchRDSIPs', rdsCode: rdsCode },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error('❌ Erreur runtime IPs:', chrome.runtime.lastError.message);
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            console.log(`📨 Réponse IPs reçue pour ${rdsCode}:`, response);
            resolve(response);
          }
        }
      );
    });

    if (response && response.success) {
      console.log(`✅ IPs reçues pour ${rdsCode}:`, response.data);
      
      // Mettre à jour le dashboard avec les IPs
      const dashboardElement = document.getElementById(`rtconnect-dashboard-${rdsCode}`);
      if (dashboardElement) {
        if (response.data.ipSupervision) {
          updateDashboardCard(dashboardElement, 'ipSupervision', response.data.ipSupervision, '📡 IP Supervision');
        }
        if (response.data.ipWanCpe) {
          updateDashboardCard(dashboardElement, 'ipWanCpe', response.data.ipWanCpe, '🌐 IP WAN CPE');
        }
        
        // Mettre à jour le cache avec les nouvelles IPs
        if (rdsCache.has(rdsCode)) {
          const cachedData = rdsCache.get(rdsCode);
          const updatedData = {
            ...cachedData,
            data: {
              ...cachedData.data,
              ipSupervision: response.data.ipSupervision || cachedData.data.ipSupervision,
              ipWanCpe: response.data.ipWanCpe || cachedData.data.ipWanCpe
            }
          };
          rdsCache.set(rdsCode, updatedData);
        }
      }
      
    } else {
      console.log(`⚠️ Problème récupération IPs pour ${rdsCode}:`, response?.error || 'Réponse vide');
      
      // Mettre les IPs en "Non disponible" après échec
      const dashboardElement = document.getElementById(`rtconnect-dashboard-${rdsCode}`);
      if (dashboardElement) {
        updateDashboardCard(dashboardElement, 'ipSupervision', null, '📡 IP Supervision');
        updateDashboardCard(dashboardElement, 'ipWanCpe', null, '🌐 IP WAN CPE');
      }
    }
    
  } catch (error) {
    console.log(`⚠️ Erreur récupération IPs pour ${rdsCode}:`, error.message);
    
    // Mettre les IPs en "Non disponible" après erreur
    const dashboardElement = document.getElementById(`rtconnect-dashboard-${rdsCode}`);
    if (dashboardElement) {
      updateDashboardCard(dashboardElement, 'ipSupervision', null, '📡 IP Supervision');
      updateDashboardCard(dashboardElement, 'ipWanCpe', null, '🌐 IP WAN CPE');
    }
  }
}

// Fonction d'initialisation
function init() {
  console.log('🏁 Initialisation RTConnect...');
  console.log('📊 Document ready state:', document.readyState);
  console.log('📍 URL:', window.location.href);
  
  if (typeof chrome === 'undefined' || !chrome.runtime) {
    console.error('❌ Chrome runtime non disponible');
    return;
  }
  
  console.log('✅ Chrome runtime disponible');
  
  // Injecter les styles CSS
  injectStyles();
  
  // Lancer la détection
  setTimeout(() => {
    console.log('🚀 Lancement de la détection RDS...');
    findAndProcessRDS();
  }, 1000);
  
  // Observer les changements de DOM
  const observer = new MutationObserver((mutations) => {
    let shouldRescan = false;
    
    mutations.forEach(mutation => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.TEXT_NODE || node.nodeType === Node.ELEMENT_NODE) {
            const text = node.textContent || '';
            if (/[A-Z]{2}-\d{4}-[A-Z]{2}/.test(text)) {
              shouldRescan = true;
              break;
            }
          }
        }
      }
    });
    
    if (shouldRescan) {
      console.log('🔄 Changement DOM détecté, nouveau scan...');
      setTimeout(findAndProcessRDS, 500);
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Fermer les dashboards avec Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeDashboard();
    }
  });
  
  console.log('👀 Observer DOM installé');
}

// Nettoyage lors du déchargement de la page
window.addEventListener('beforeunload', () => {
  console.log('🧹 Nettoyage des timers avant déchargement...');
  retryQueue.forEach((retryInfo, rdsCode) => {
    if (retryInfo.timeoutId) {
      clearTimeout(retryInfo.timeoutId);
      console.log(`⏹️ Timer annulé pour ${rdsCode}`);
    }
  });
  retryQueue.clear();
  closeDashboard();
});

// Démarrage
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

console.log('✅ RTConnect Content Script chargé et prêt'); 
// RTConnect Popup Script - Version simplifiée avec auto-sync
document.addEventListener('DOMContentLoaded', async () => {
  console.log('🚀 Popup RTConnect chargé');
  
  const EXTENSION_VERSION = '2.0.0';
  const STORAGE_KEY = 'rtconnect_state';
  
  // Configuration du serveur avec option dev
  const DEV_MODE = false; // Mettre à true pour le développement
  const SERVER_URL = DEV_MODE ? 'http://localhost:3001' : 'http://10.210.35.203:3001';
  
  // Fonction pour obtenir les éléments DOM avec vérification
  function getDOMElements() {
    const requiredElements = {
      status: document.getElementById('status'),
      serverStatus: document.getElementById('server-status'),
      cookiesStatus: document.getElementById('cookies-status'),
      version: document.getElementById('version'),
      refreshBtn: document.getElementById('refresh-btn')
    };

    const missingElements = Object.entries(requiredElements)
      .filter(([key, element]) => !element)
      .map(([key]) => key);

    if (missingElements.length > 0) {
      throw new Error(`Éléments manquants: ${missingElements.join(', ')}`);
    }

    return requiredElements;
  }

  // Variable pour suivre si une requête est en cours
  let isRefreshing = false;
  let elements = null;

  try {
    elements = getDOMElements();
  } catch (error) {
    console.error('❌ Erreur initialisation DOM:', error);
    return;
  }

  // Fonction pour sauvegarder l'état
  function saveState(state) {
    try {
      chrome.storage.local.set({ [STORAGE_KEY]: state }, () => {
        if (chrome.runtime.lastError) {
          console.error('❌ Erreur sauvegarde état:', chrome.runtime.lastError);
          return;
        }
        console.log('💾 État sauvegardé:', state);
      });
    } catch (error) {
      console.error('❌ Erreur sauvegarde état:', error);
    }
  }

  // Fonction pour restaurer l'état
  async function restoreState() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get([STORAGE_KEY], (result) => {
          if (chrome.runtime.lastError) {
            console.error('❌ Erreur restauration état:', chrome.runtime.lastError);
            resolve(null);
            return;
          }
          const state = result[STORAGE_KEY];
          console.log('📂 État restauré:', state);
          if (state) {
            updateUI(state);
          }
          resolve(state);
        });
      } catch (error) {
        console.error('❌ Erreur restauration état:', error);
        resolve(null);
      }
    });
  }

  // Fonction pour mettre à jour l'interface utilisateur
  function updateUI(state) {
    if (!state || !elements) {
      console.warn('⚠️ Impossible de mettre à jour l\'UI: état ou éléments manquants');
      return;
    }

    try {
      // Mettre à jour le statut du serveur
      if (state.serverConnected) {
        safeUpdateElement(elements.status, {
          className: 'status connected',
          innerHTML: '✅ Serveur connecté'
        });
      } else {
        safeUpdateElement(elements.status, {
          className: 'status disconnected',
          innerHTML: '❌ Serveur inaccessible - Démarrez le serveur'
        });
      }

      // Mettre à jour les autres éléments
      safeUpdateElement(elements.serverStatus, {
        textContent: state.serverStatus,
        style: { color: state.serverConnected ? '#28a745' : '#dc3545' }
      });

      safeUpdateElement(elements.cookiesStatus, {
        textContent: state.cookieStatus,
        style: { color: state.cookieStatus === 'Synchronisés' ? '#28a745' : '#ffc107' }
      });

      safeUpdateElement(elements.version, {
        textContent: `v${EXTENSION_VERSION}`,
        style: { color: state.needsUpdate ? '#ffc107' : '#28a745' }
      });
    } catch (error) {
      console.error('❌ Erreur mise à jour UI:', error);
    }
  }

  // Fonction pour mettre à jour un élément en toute sécurité
  function safeUpdateElement(element, updates) {
    try {
      if (!element) {
        console.warn('⚠️ Tentative de mise à jour d\'un élément null');
        return;
      }

      if (!document.body.contains(element)) {
        console.warn('⚠️ L\'élément n\'est plus dans le DOM');
        return;
      }

      if (typeof updates === 'object') {
        Object.entries(updates).forEach(([key, value]) => {
          try {
            if (!element) return; // Vérification supplémentaire
            
            if (key === 'innerHTML' || key === 'textContent') {
              element[key] = value;
            } else if (key === 'style' && typeof value === 'object') {
              Object.assign(element.style, value);
            } else if (key === 'className') {
              if (typeof value === 'string') {
                element.className = value;
              } else {
                console.warn('⚠️ Valeur invalide pour className:', value);
              }
            }
          } catch (updateError) {
            console.error(`❌ Erreur mise à jour ${key}:`, updateError);
          }
        });
      }
    } catch (error) {
      console.error('❌ Erreur mise à jour élément:', error);
    }
  }

  // Fonction pour comparer les versions
  function compareVersions(v1, v2) {
    try {
      const parts1 = v1.split('.').map(Number);
      const parts2 = v2.split('.').map(Number);
      
      for (let i = 0; i < 3; i++) {
        if (parts1[i] > parts2[i]) return 1;
        if (parts1[i] < parts2[i]) return -1;
      }
      return 0;
    } catch (error) {
      console.error('❌ Erreur comparaison versions:', error);
      return 0;
    }
  }

  // Fonction pour tester la connexion au serveur
  async function checkServerStatus() {
    if (isRefreshing || !elements) {
      console.log('⚠️ Vérification impossible: rafraîchissement en cours ou éléments non initialisés');
      return;
    }

    try {
      isRefreshing = true;
      console.log('🔍 Vérification du statut serveur...');
      
      // Vérifier d'abord le statut général du serveur
      const serverResponse = await fetch(`${SERVER_URL}/api/status`);
      if (!serverResponse.ok) throw new Error('Serveur inaccessible');
      
      const serverData = await serverResponse.json();
      
      // Vérifier ensuite le statut d'authentification
      const authResponse = await fetch(`${SERVER_URL}/api/auth/status`);
      const authData = await authResponse.json();
      
      console.log('📊 Statut serveur:', serverData);
      console.log('🔐 Statut auth:', authData);
      
      let needsUpdate = false;
      
      if (serverData.success) {
        // Vérifier la version du serveur
        if (serverData.server && serverData.server.version) {
          const serverVersion = serverData.server.version;
          const versionCompare = compareVersions(serverVersion, EXTENSION_VERSION);
          needsUpdate = versionCompare > 0;
          
          if (needsUpdate) {
            const shouldUpdate = confirm(`Une nouvelle version (${serverVersion}) est disponible.\nVoulez-vous mettre à jour l'extension ?`);
            if (shouldUpdate) {
              window.open('https://github.com/votre-repo/rtconnect/releases', '_blank');
            }
          }
        }

        // Créer l'état à sauvegarder
        const newState = {
          serverConnected: true,
          serverStatus: 'En ligne',
          cookieStatus: authData.cookieStatus === 'synchronized' ? 'Synchronisés' : 'Non synchronisés',
          lastCheck: new Date().toISOString(),
          needsUpdate
        };

        // Mettre à jour l'UI et sauvegarder l'état
        updateUI(newState);
        saveState(newState);
        
      } else {
        throw new Error(serverData.error || 'Erreur inconnue');
      }
      
    } catch (error) {
      console.error('❌ Erreur vérification serveur:', error);
      
      const errorState = {
        serverConnected: false,
        serverStatus: 'Hors ligne',
        cookieStatus: 'Indisponible',
        lastCheck: new Date().toISOString(),
        needsUpdate: false
      };

      updateUI(errorState);
      saveState(errorState);
    } finally {
      isRefreshing = false;
    }
  }

  // Gestionnaire pour le bouton actualiser
  if (elements.refreshBtn) {
    elements.refreshBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      
      // Revérifier les éléments DOM avant l'actualisation
      try {
        elements = getDOMElements();
      } catch (error) {
        console.error('❌ Éléments DOM non disponibles pour l\'actualisation:', error);
        return;
      }
      
      if (isRefreshing) {
        console.log('⚠️ Une actualisation est déjà en cours');
        return;
      }
      
      console.log('🔄 Actualisation manuelle du statut...');
      
      // Désactiver le bouton et montrer le chargement
      elements.refreshBtn.disabled = true;
      const originalText = elements.refreshBtn.innerHTML;
      elements.refreshBtn.innerHTML = '⏳ Actualisation...';
      
      try {
        await checkServerStatus();
        elements.refreshBtn.innerHTML = '✅ Actualisé';
      } catch (error) {
        console.error('❌ Erreur lors de l\'actualisation:', error);
        elements.refreshBtn.innerHTML = '❌ Erreur';
      } finally {
        setTimeout(() => {
          if (elements.refreshBtn) {
            elements.refreshBtn.innerHTML = originalText;
            elements.refreshBtn.disabled = false;
          }
        }, 1500);
      }
    });
  }
  
  try {
    // Restaurer l'état au chargement
    const savedState = await restoreState();
    
    // Si pas d'état sauvegardé ou dernier check trop ancien (> 5 minutes), vérifier le statut
    if (!savedState || 
        !savedState.lastCheck || 
        (new Date() - new Date(savedState.lastCheck)) > 5 * 60 * 1000) {
      console.log('🔄 Vérification automatique nécessaire');
      await checkServerStatus();
    }
  } catch (error) {
    console.error('❌ Erreur initialisation état:', error);
  }
  
  console.log('✅ Popup RTConnect initialisé');
}); 
// RTConnect Content Script - Version avec mini-dashboard
console.log('🚀 RTConnect Content Script chargé - URL:', window.location.href);

// Variables globales
let processedRDSOnPage = new Set();
let rdsCache = new Map();
let retryQueue = new Map();
let activeDashboards = new Map(); // Pour gérer plusieurs dashboards
let rdsProcessingTimeout = null; // Pour le debouncing du retraitement RDS

// Variables pour la vérification de mise à jour
let updateCheckInterval = null;
let lastUpdateCheck = 0;
const UPDATE_CHECK_INTERVAL = 10 * 60 * 1000; // Vérifier toutes les 10 minutes
const UPDATE_NOTIFICATION_DURATION = 30 * 1000; // Notification visible 30 secondes

// File d'attente pour optimiser les requêtes RDS
let requestQueue = [];
let activeRequests = new Map(); // Suivi des requêtes en cours
let requestInProgress = false;
const MAX_CONCURRENT_REQUESTS = 4; // Augmenté de 2 à 4 requêtes simultanées
const REQUEST_DELAY = 100; // Réduit de 250ms à 100ms entre chaque requête
let currentConcurrentRequests = 0;

// Configuration retry
const RETRY_INTERVAL = 30 * 1000; // 30 secondes au lieu de 5 minutes pour plus de réactivité
const MAX_RETRIES = 3; // Maximum 3 essais

// Système de file d'attente RDS intelligent
const rdsQueue = {
  queue: [],
  processing: false,
  
  // Ajouter une requête à la file
  add(rdsCode, buttonElement, isDashboardOpen = false, forceRefresh = false) {
    // Éviter les doublons si pas de forceRefresh
    if (!forceRefresh && this.queue.some(item => item.rdsCode === rdsCode)) {
      console.log(`⚠️ ${rdsCode} déjà dans la queue, ignoré`);
      return;
    }
    
    this.queue.push({
      rdsCode,
      buttonElement,
      isDashboardOpen,
      timestamp: Date.now()
    });
    
    console.log(`📋 ${rdsCode} ajouté à la queue (${this.queue.length} éléments)`);
    this.process();
  },
  
  async process() {
    if (this.processing) return;
    
    this.processing = true;
    console.log(`🔄 Traitement de la queue (${this.queue.length} éléments)...`);
    
    while (this.queue.length > 0) {
      const item = this.queue.shift();
      await this.processItem(item);
      
      // Délai entre les requêtes pour éviter la surcharge
      if (this.queue.length > 0) {
        await new Promise(resolve => setTimeout(resolve, REQUEST_DELAY));
      }
    }
    
    this.processing = false;
    console.log('✅ Queue traitée complètement');
  },
  
  // Traiter un élément de la queue
  async processItem(item) {
    try {
      console.log(`📡 Traitement ${item.rdsCode}... (source: ${item.isDashboardOpen ? 'dashboard' : 'page load'})`);
      
      const response = await new Promise((resolve, reject) => {
        // Vérifier si l'extension est encore valide
        if (!chrome.runtime || !chrome.runtime.sendMessage) {
          reject(new Error('Extension context invalidated - page needs reload'));
          return;
        }
        
        chrome.runtime.sendMessage(
          { type: 'fetchRDS', rdsCode: item.rdsCode },
          (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(response);
            }
          }
        );
      });
      
      console.log(`📨 Réponse reçue pour ${item.rdsCode}:`, response);
      
      // *** VÉRIFICATION AUTOMATIQUE DE VERSION QUAND LE SERVEUR RÉPOND ***
      if (response && response.success && response.serverVersion) {
        console.log(`🔍 Vérification automatique de version déclenchée par réponse serveur pour ${item.rdsCode}`);
        checkVersionFromServerResponse(response.serverVersion);
      }
      
      updateRDSButton(response, item.buttonElement, item.rdsCode);
      
      if (item.isDashboardOpen && response && response.success) {
        // Si le dashboard est ouvert, mettre à jour automatiquement
        if (response.data) {
          updateDashboard(item.rdsCode, response.data);
          
          // Récupérer les IPs en arrière-plan après un délai
          setTimeout(() => {
            fetchIPsInBackground(item.rdsCode);
          }, 1000);
        }
      }
      
    } catch (error) {
      console.error(`❌ Erreur traitement ${item.rdsCode}:`, error);
      
      // Gestion spéciale pour "Extension context invalidated"
      if (error.message.includes('Extension context invalidated') || error.message.includes('context invalidated')) {
        console.log('🔄 Extension context invalidated - arrêt du traitement pour éviter les erreurs');
        
        // Mettre à jour le bouton avec un message informatif
        if (item.buttonElement) {
          item.buttonElement.className = 'rtconnect-rds-button error';
          item.buttonElement.innerHTML = `🔄 ${item.rdsCode} (Recharger la page)`;
          item.buttonElement.title = 'Extension mise à jour - Rechargez la page';
        }
        
        // Arrêter le traitement de la queue
        this.processing = false;
        this.queue = [];
        return;
      }
      
      // Pour les autres erreurs, programmer un retry directement
      scheduleRetry(item.rdsCode, item.buttonElement, error.message || 'Erreur de communication');
    }
  }
};

// Configuration et fonctions pour le système de mise à jour
function getStoredConfig() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['rtconnect_config'], (result) => {
      const defaultConfig = {
        environment: 'prod',
        serverUrls: {
          dev: 'http://localhost:3001',
          prod: 'http://10.210.35.203:3001'
        }
      };
      
      const config = result.rtconnect_config || defaultConfig;
      resolve(config);
    });
  });
}

// Fonction pour récupérer la version de l'extension
function getExtensionVersion() {
  return chrome.runtime.getManifest().version;
}

// Fonction pour vérifier les mises à jour
async function checkForUpdates() {
  try {
    // Vérifier si l'extension est encore valide
    if (!chrome.runtime || !chrome.runtime.getManifest) {
      console.log('🔄 RTConnect - Extension context invalidated, arrêt de la vérification de mise à jour');
      stopUpdateChecker(); // Arrêter le vérificateur pour éviter les erreurs répétées
      return;
    }
    
    // Vérifier si l'ID runtime est encore valide
    if (!chrome.runtime.id) {
      console.log('🔄 RTConnect - Extension runtime ID invalide, arrêt de la vérification');
      stopUpdateChecker();
      return;
    }
    
    console.log('🔍 RTConnect - Vérification de mise à jour...');
    
    const config = await getStoredConfig();
    const serverUrl = config.serverUrls[config.environment];
    
    const response = await fetch(`${serverUrl}/api/status`);
    if (!response.ok) {
      console.log('🔄 RTConnect - Serveur non disponible pour vérification de version');
      return;
    }
    
    const data = await response.json();
    console.log('🎉 RTConnect - Réponse serveur complète:', data);
    
    // Essayer plusieurs sources pour la version serveur
    let serverVersion = null;
    
    if (data.success && data.server && data.server.version) {
      serverVersion = data.server.version;
    } else if (data.version) {
      serverVersion = data.version;
    } else if (data.data && data.data.version) {
      serverVersion = data.data.version;
    } else if (data.info && data.info.version) {
      serverVersion = data.info.version;
    }
    
    if (!serverVersion) {
      console.log('⚠️ RTConnect - Aucune version serveur trouvée dans la réponse:', data);
      // Forcer une version test pour voir si le système fonctionne
      serverVersion = "2.1.0"; // Version test plus récente que 2.0.0
      console.log('🧪 RTConnect - Version test forcée pour debug:', serverVersion);
    }
    
    const extensionVersion = getExtensionVersion();
    const versionCompare = compareVersions(serverVersion, extensionVersion);
    const needsUpdate = versionCompare > 0;
    
    console.log(`🔍 RTConnect - Versions: Serveur=${serverVersion}, Extension=${extensionVersion}, Comparaison=${versionCompare}, Mise à jour=${needsUpdate}`);
    
    if (needsUpdate) {
      const shouldShow = await shouldShowUpdateToast(serverVersion);
      console.log(`🎉 RTConnect - Doit afficher notification: ${shouldShow}`);
      
      if (shouldShow) {
        const updateUrl = data.updateUrl || 'https://math-frx.github.io/RTConnect/';
        console.log(`🚀 RTConnect - Affichage notification avec URL: ${updateUrl}`);
        showUpdateToast(extensionVersion, serverVersion, updateUrl);
        console.log(`🎉 RTConnect - Notification de mise à jour affichée (${extensionVersion} → ${serverVersion})`);
      } else {
        console.log(`🔄 RTConnect - Notification de mise à jour ignorée (déjà vue récemment)`);
      }
    } else {
      console.log(`✅ RTConnect - Extension à jour (${extensionVersion})`);
      // Debug forcé pour tester le système
      if (serverVersion === "2.1.0" && extensionVersion === "2.0.0") {
        console.log(`🧪 RTConnect - FORÇAGE NOTIFICATION DEBUG: ${extensionVersion} vs ${serverVersion}`);
        const updateUrl = data.updateUrl || 'https://math-frx.github.io/RTConnect/';
        showUpdateToast(extensionVersion, serverVersion, updateUrl);
      }
    }
  } catch (error) {
    // Gestion spéciale pour "Extension context invalidated"
    if (error.message && (
        error.message.includes('Extension context invalidated') || 
        error.message.includes('context invalidated') ||
        error.message.includes('runtime.id')
    )) {
      console.log('🔄 RTConnect - Extension rechargée, arrêt automatique de la vérification de mise à jour');
      stopUpdateChecker();
      return;
    }
    
    console.error('❌ RTConnect - Erreur vérification mise à jour:', error);
  }
}

// Fonction pour comparer les versions
function compareVersions(v1, v2) {
  try {
    const parts1 = v1.split('.').map(n => parseInt(n, 10));
    const parts2 = v2.split('.').map(n => parseInt(n, 10));
    
    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const part1 = parts1[i] || 0;
      const part2 = parts2[i] || 0;
      
      if (part1 > part2) return 1;
      if (part1 < part2) return -1;
    }
    
    return 0;
  } catch (error) {
    console.error('❌ RTConnect - Erreur comparaison versions:', error);
    return 0;
  }
}

// Fonction pour vérifier la version automatiquement quand le serveur répond
async function checkVersionFromServerResponse(serverVersion) {
  try {
    if (!serverVersion) return;
    
    console.log('🔍 RTConnect - Vérification version automatique depuis réponse serveur...');
    
    const extensionVersion = getExtensionVersion();
    const versionCompare = compareVersions(serverVersion, extensionVersion);
    const needsUpdate = versionCompare > 0;
    
    console.log(`🔍 RTConnect - Versions (auto): Serveur=${serverVersion}, Extension=${extensionVersion}, Besoin MAJ=${needsUpdate}`);
    
    if (needsUpdate) {
      const shouldShow = await shouldShowUpdateToast(serverVersion);
      console.log(`🔔 RTConnect - Notification auto: ${shouldShow}`);
      
      if (shouldShow) {
        const updateUrl = 'https://math-frx.github.io/RTConnect/';
        console.log(`🚀 RTConnect - Affichage notification automatique`);
        showUpdateToast(extensionVersion, serverVersion, updateUrl);
        console.log(`🔔 RTConnect - Notification automatique affichée (${extensionVersion} → ${serverVersion})`);
      }
    }
  } catch (error) {
    console.error('❌ RTConnect - Erreur vérification auto version:', error);
  }
}

// Styles CSS pour le dashboard
const dashboardStyles = `
  @keyframes rtconnect-fadeInOverlay {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  @keyframes rtconnect-fadeIn {
    from {
      opacity: 0;
      transform: translate(-50%, -48%);
    }
    to {
      opacity: 1;
      transform: translate(-50%, -50%);
    }
  }

  /* Styles pour la notification toast de mise à jour */
  .rtconnect-update-toast {
    position: fixed;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 16px 20px;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    max-width: 350px;
    animation: rtconnect-slideInRight 0.4s ease-out;
    cursor: pointer;
    transition: transform 0.2s ease;
  }

  .rtconnect-update-toast:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
  }

  .rtconnect-update-toast-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 8px;
  }

  .rtconnect-update-toast-icon {
    font-size: 24px;
    animation: rtconnect-pulse 2s infinite;
  }

  .rtconnect-update-toast-title {
    font-size: 16px;
    font-weight: 600;
    margin: 0;
  }

  .rtconnect-update-toast-close {
    margin-left: auto;
    background: none;
    border: none;
    color: white;
    font-size: 18px;
    cursor: pointer;
    padding: 4px;
    border-radius: 4px;
    opacity: 0.8;
    transition: opacity 0.2s;
  }

  .rtconnect-update-toast-close:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 0.2);
  }

  .rtconnect-update-toast-message {
    font-size: 14px;
    line-height: 1.4;
    margin-bottom: 12px;
    opacity: 0.9;
  }

  .rtconnect-update-toast-versions {
    display: flex;
    justify-content: space-between;
    font-size: 12px;
    margin-bottom: 12px;
    background: rgba(255, 255, 255, 0.1);
    padding: 8px 12px;
    border-radius: 6px;
  }

  .rtconnect-update-toast-version-current {
    color: #ffcccb;
  }

  .rtconnect-update-toast-version-new {
    color: #90ee90;
    font-weight: 600;
  }

  .rtconnect-update-toast-actions {
    display: flex;
    gap: 8px;
  }

  .rtconnect-update-toast-btn {
    flex: 1;
    padding: 8px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 12px;
    font-weight: 500;
    transition: all 0.2s;
  }

  .rtconnect-update-toast-btn-later {
    background: rgba(255, 255, 255, 0.2);
    color: white;
  }

  .rtconnect-update-toast-btn-later:hover {
    background: rgba(255, 255, 255, 0.3);
  }

  .rtconnect-update-toast-btn-download {
    background: white;
    color: #667eea;
    font-weight: 600;
  }

  .rtconnect-update-toast-btn-download:hover {
    background: #f8f9ff;
  }

  .rtconnect-update-toast-progress {
    position: absolute;
    bottom: 0;
    left: 0;
    height: 3px;
    background: rgba(255, 255, 255, 0.3);
    border-radius: 0 0 12px 12px;
    animation: rtconnect-progressBar 30s linear forwards;
  }

  @keyframes rtconnect-slideInRight {
    from {
      opacity: 0;
      transform: translateX(100%);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes rtconnect-slideOutRight {
    from {
      opacity: 1;
      transform: translateX(0);
    }
    to {
      opacity: 0;
      transform: translateX(100%);
    }
  }

  @keyframes rtconnect-pulse {
    0%, 100% {
      transform: scale(1);
    }
    50% {
      transform: scale(1.1);
    }
  }

  @keyframes rtconnect-progressBar {
    from {
      width: 100%;
    }
    to {
      width: 0%;
    }
  }

  .rtconnect-dashboard {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    border-radius: 12px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
    padding: 0;
    z-index: 2147483647;
    max-width: 650px;
    width: 98vw;
    max-height: 95vh;
    overflow: hidden;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    animation: rtconnect-fadeIn 0.3s ease-out;
    border: 1px solid #e0e0e0;
  }

  .rtconnect-dashboard-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(2px);
    z-index: 2147483646;
    animation: rtconnect-fadeInOverlay 0.3s ease-out;
  }

  .rtconnect-dashboard-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .rtconnect-dashboard-title {
    font-size: 18px;
    font-weight: 600;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .rtconnect-dashboard-close {
    background: none;
    border: none;
    color: white;
    font-size: 24px;
    cursor: pointer;
    padding: 4px;
    border-radius: 4px;
    transition: background 0.2s;
  }

  .rtconnect-dashboard-close:hover {
    background: rgba(255, 255, 255, 0.2);
  }

  .rtconnect-dashboard-content {
    padding: 0;
    max-height: 80vh;
    overflow: hidden;
    background: white;
  }

  .rtconnect-tabs {
    display: flex;
    background: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
  }

  .rtconnect-tab {
    flex: 1;
    padding: 12px 16px;
    background: transparent;
    border: none;
    cursor: pointer;
    font-weight: 600;
    font-size: 13px;
    color: #6c757d;
    text-align: center;
    transition: all 0.3s ease;
    position: relative;
  }

  .rtconnect-tab:hover {
    background: #e9ecef;
    color: #495057;
  }

  .rtconnect-tab.active {
    color: #667eea;
    background: white;
  }

  .rtconnect-tab.active::after {
    content: '';
    position: absolute;
    bottom: -2px;
    left: 0;
    right: 0;
    height: 2px;
    background: #667eea;
  }

  .rtconnect-tab-badge {
    background: #6c757d;
    color: white;
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 10px;
    margin-left: 6px;
  }

  .rtconnect-tab.active .rtconnect-tab-badge {
    background: #667eea;
  }

  .rtconnect-tab-content {
    padding: 20px;
    height: calc(80vh - 60px);
    overflow-y: auto;
  }

  .rtconnect-tab-pane {
    display: none;
  }

  .rtconnect-tab-pane.active {
    display: block;
  }

  .rtconnect-info-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 12px;
  }

  @media (max-width: 700px) {
    .rtconnect-info-grid {
      grid-template-columns: 1fr;
    }
  }

  .rtconnect-info-card {
    background: white;
    border-radius: 8px;
    padding: 14px;
    border: 1px solid #e0e0e0;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    transition: all 0.2s ease;
  }

  .rtconnect-info-card:hover {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transform: translateY(-1px);
  }

  .rtconnect-info-card.tech-info {
    border-left: 4px solid #0d6efd;
    background: linear-gradient(135deg, #f0f8ff 0%, #e6f3ff 100%);
  }

  .rtconnect-info-card.radius-attr {
    border-left: 4px solid #ffc107;
    background: linear-gradient(135deg, #fffdf0 0%, #fefcf0 100%);
    font-family: 'Courier New', monospace;
    font-size: 12px;
  }

  .rtconnect-status-card {
    grid-column: 1 / -1;
    text-align: center;
    padding: 16px;
    border-radius: 8px;
    font-weight: 600;
    margin-bottom: 16px;
  }

  .rtconnect-status-card.loading {
    background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
    border: 1px solid #ffc107;
    color: #856404;
  }

  .rtconnect-status-card.success {
    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
    border: 1px solid #28a745;
    color: #155724;
  }

  .rtconnect-info-row {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    min-height: 32px;
  }

  .rtconnect-info-label {
    flex: 0 0 120px;
    font-weight: 600;
    color: #495057;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    line-height: 1.4;
    padding-top: 2px;
  }

  .rtconnect-info-value {
    flex: 1;
    color: #212529;
    font-size: 14px;
    font-weight: 500;
    line-height: 1.4;
    word-break: break-word;
    min-height: 20px;
    display: flex;
    align-items: center;
  }

  .rtconnect-copy-button {
    flex: 0 0 auto;
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    color: #6c757d;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
    cursor: pointer;
    transition: all 0.2s;
    margin-left: 8px;
  }

  .rtconnect-copy-button:hover {
    background: #e9ecef;
    color: #495057;
    transform: scale(1.05);
  }

  .rtconnect-copy-button.copied {
    background: #d4edda;
    color: #155724;
    border-color: #c3e6cb;
  }

  .rtconnect-info-value.empty {
    color: #6c757d;
    font-style: italic;
  }

  .rtconnect-info-value.loading {
    color: #856404;
    font-style: italic;
    animation: rtconnect-pulse 1.5s ease-in-out infinite;
  }

  .rtconnect-attribut-item {
    padding: 8px 10px;
    background: rgba(102, 126, 234, 0.1);
    border-radius: 6px;
    margin-bottom: 6px;
    font-family: 'SF Mono', Monaco, 'Cascadia Code', 'Consolas', 'Liberation Mono', 'Menlo', monospace;
    font-size: 13px;
    border-left: 3px solid #667eea;
    line-height: 1.5;
    position: relative;
  }

  .rtconnect-attribut-name {
    font-weight: 700;
    color: #495057;
    font-size: 14px;
  }

  .rtconnect-attribut-op {
    color: #6c757d;
    margin: 0 8px;
    font-weight: 600;
    font-size: 13px;
  }

  .rtconnect-attribut-value {
    color: #212529;
    font-size: 13px;
    font-weight: 600;
  }

  .rtconnect-attribut-copy {
    position: absolute;
    top: 50%;
    right: 8px;
    transform: translateY(-50%);
    background: rgba(0, 0, 0, 0.05);
    border: 1px solid rgba(0, 0, 0, 0.1);
    color: #6c757d;
    padding: 2px 6px;
    font-size: 10px;
    border-radius: 4px;
    cursor: pointer;
    opacity: 0;
    transition: all 0.2s;
  }

  .rtconnect-attribut-item:hover .rtconnect-attribut-copy {
    opacity: 0.7;
  }

  .rtconnect-attribut-copy:hover {
    opacity: 1;
    background: rgba(0, 0, 0, 0.1);
    color: #495057;
  }

  .rtconnect-status-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .rtconnect-status-badge.success {
    background: #d4edda;
    color: #155724;
  }

  .rtconnect-status-badge.loading {
    background: #fff3cd;
    color: #856404;
  }

  .rtconnect-status-badge.error {
    background: #f8d7da;
    color: #721c24;
  }

  .rtconnect-dashboard-footer {
    padding: 16px 20px;
    background: #f8f9fa;
    border-top: 1px solid #dee2e6;
    font-size: 12px;
    color: #6c757d;
    text-align: center;
  }

  .rtconnect-rds-button {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    color: white !important;
    border: none !important;
    padding: 4px 8px !important;
    border-radius: 6px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    text-decoration: none !important;
    display: inline-flex !important;
    align-items: center !important;
    gap: 4px !important;
    transition: all 0.3s ease !important;
    box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3) !important;
  }

  .rtconnect-rds-button:hover {
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4) !important;
  }

  .rtconnect-rds-button.loading {
    background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%) !important;
    box-shadow: 0 2px 8px rgba(255, 193, 7, 0.3) !important;
  }

  .rtconnect-rds-button.error {
    background: linear-gradient(135deg, #6c757d 0%, #495057 100%) !important;
    box-shadow: 0 2px 8px rgba(108, 117, 125, 0.3) !important;
  }

  .rtconnect-title-copy-button {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.2s;
    opacity: 0.8;
  }

  .rtconnect-title-copy-button:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.05);
  }

  .rtconnect-title-copy-button.copied {
    background: rgba(76, 175, 80, 0.8);
    color: white;
    border-color: rgba(76, 175, 80, 1);
  }

  .rtconnect-nav-button {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s;
    opacity: 0.8;
  }

  .rtconnect-nav-button:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
  }

  .rtconnect-nav-counter {
    background: rgba(255, 255, 255, 0.2);
    color: white;
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    opacity: 0.9;
  }

  .rtconnect-rds-link-button {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 12px;
    cursor: pointer;
    transition: all 0.2s;
    opacity: 0.8;
  }

  .rtconnect-rds-link-button:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.05);
  }

  .rtconnect-nav-button.active {
    background: rgba(255, 255, 255, 0.4);
    border-color: rgba(255, 255, 255, 0.6);
  }

  .rtconnect-info-row {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    border-bottom: 1px solid #dee2e6;
    gap: 8px;
  }

  .rtconnect-info-row:last-child {
    border-bottom: none;
  }

  .rtconnect-info-row.rtconnect-separator {
    background: #e9ecef;
    font-weight: 600;
    border-bottom: 2px solid #6c757d;
    margin-top: 8px;
  }

  .rtconnect-info-row.tech-info {
    background: rgba(13, 110, 253, 0.1);
    border-left: 3px solid #0d6efd;
  }

  .rtconnect-info-row.radius-attr {
    background: rgba(255, 193, 7, 0.1);
    border-left: 3px solid #ffc107;
    font-size: 12px;
  }

  .rtconnect-info-label {
    flex: 0 0 auto;
    font-weight: 600;
    color: #495057;
    min-width: 140px;
    font-size: 13px;
  }

  .rtconnect-info-value {
    flex: 1;
    color: #212529;
    font-size: 13px;
    word-break: break-all;
  }

  @keyframes rtconnect-pulse {
    0% { opacity: 0.6; }
    50% { opacity: 1; }
    100% { opacity: 0.6; }
  }

  .rtconnect-status-row {
    background: #e8f4fd;
    border: 1px solid #b8daff;
    border-radius: 6px;
    padding: 12px;
    margin-bottom: 16px;
    text-align: center;
    font-weight: 600;
  }

  .rtconnect-status-row.loading {
    background: #fff3cd;
    border-color: #ffeaa7;
    color: #856404;
  }

  .rtconnect-status-row.success {
    background: #d4edda;
    border-color: #c3e6cb;
    color: #155724;
  }

  /* Styles pour les indicateurs de statut de vérification */
  .rtconnect-verification-status {
    pointer-events: auto !important;
  }

  .rtconnect-verification-status:hover {
    z-index: 9999 !important;
  }

  /* Amélioration des tooltips natifs */
  .rtconnect-verification-status[title]:hover:after {
    content: attr(title);
    position: absolute;
    bottom: 100%;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.9);
    color: white;
    padding: 6px 8px;
    border-radius: 4px;
    font-size: 12px;
    white-space: nowrap;
    z-index: 10000;
    pointer-events: none;
    opacity: 0;
    animation: rtconnect-tooltipFadeIn 0.1s ease-out 0.1s forwards;
  }

  @keyframes rtconnect-tooltipFadeIn {
    from {
      opacity: 0;
      transform: translateX(-50%) translateY(4px);
    }
    to {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
  }
`;

// Fonction pour copier du texte dans le presse-papier
async function copyToClipboard(text) {
  try {
    // Essayer d'abord l'API moderne
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }

    // Fallback pour les contextes non sécurisés ou les navigateurs plus anciens
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
      document.execCommand('copy');
      textArea.remove();
      return true;
    } catch (err) {
      console.error('Erreur execCommand:', err);
      textArea.remove();
      return false;
    }
  } catch (err) {
    console.error('Erreur copyToClipboard:', err);
    return false;
  }
}

// Fonction pour gérer la copie avec retour visuel
async function handleCopy(value, button, isAttribute = false) {
  if (!value || !button) return;
  
  console.log('🔍 Tentative de copie:', value);
  
  try {
    const success = await copyToClipboard(value);
    if (success) {
      const originalText = button.innerHTML;
      const originalBackground = button.style.background;
      
      if (isAttribute) {
        button.style.background = '#28a745';
      } else {
        button.classList.add('copied');
      }
      button.innerHTML = '✅';
      
      setTimeout(() => {
        if (button && button.isConnected) {
          if (isAttribute) {
            button.style.background = originalBackground;
          } else {
            button.classList.remove('copied');
          }
          button.innerHTML = originalText;
        }
      }, 1500);
      
      console.log('✅ Copié avec succès:', value);
    } else {
      throw new Error('Échec de la copie');
    }
  } catch (error) {
    console.error('❌ Erreur de copie:', error);
    const originalText = button.innerHTML;
    const originalBackground = button.style.background;
    
    if (isAttribute) {
      button.style.background = '#dc3545';
    }
    button.innerHTML = '❌';
    
    setTimeout(() => {
      if (button && button.isConnected) {
        if (isAttribute) {
          button.style.background = originalBackground;
        }
        button.innerHTML = originalText;
      }
    }, 1500);
  }
}

// Fonction pour arrêter la vérification périodique
function stopUpdateChecker() {
  if (updateCheckInterval) {
    clearInterval(updateCheckInterval);
    updateCheckInterval = null;
    console.log('🔄 RTConnect - Vérificateur de mise à jour arrêté');
  }
}

// Fonction pour injecter les styles CSS
function injectStyles() {
  if (!document.getElementById('rtconnect-styles')) {
    const styleElement = document.createElement('style');
    styleElement.id = 'rtconnect-styles';
    styleElement.textContent = dashboardStyles;
    document.head.appendChild(styleElement);
  }
}

// Fonction pour créer et afficher le dashboard
function createDashboard(rdsCode, rdsData) {
  // Fermer les autres dashboards
  closeDashboard();

  // Créer l'overlay
  const overlay = document.createElement('div');
  overlay.className = 'rtconnect-dashboard-overlay';
  overlay.onclick = () => closeDashboard();

  // Créer le dashboard
  const dashboard = document.createElement('div');
  dashboard.className = 'rtconnect-dashboard';
  dashboard.id = `rtconnect-dashboard-${rdsCode}`;

  // Header
  const header = document.createElement('div');
  header.className = 'rtconnect-dashboard-header';
  
  // Générer les boutons de navigation s'il y a plusieurs RDS
  const allRDSButtons = document.querySelectorAll('.rtconnect-rds-button');
  const allRDSCodes = [...new Set(Array.from(allRDSButtons).map(btn => btn.dataset.rdsCode))];
  
  let navigationButtons = '';
  if (allRDSCodes.length > 1) {
    const currentIndex = allRDSCodes.indexOf(rdsCode);
    const prevCode = allRDSCodes[currentIndex - 1] || allRDSCodes[allRDSCodes.length - 1];
    const nextCode = allRDSCodes[currentIndex + 1] || allRDSCodes[0];
    
    navigationButtons = `
      <button class="rtconnect-nav-button" data-nav-rds="${prevCode}" title="RDS précédent (${prevCode})">
        ←
      </button>
      <span class="rtconnect-nav-counter">${currentIndex + 1}/${allRDSCodes.length}</span>
      <button class="rtconnect-nav-button" data-nav-rds="${nextCode}" title="RDS suivant (${nextCode})">
        →
      </button>
    `;
  }
  
  header.innerHTML = `
    <div style="display: flex; align-items: center; gap: 8px;">
      <h3 class="rtconnect-dashboard-title">${rdsCode}</h3>
      <button class="rtconnect-title-copy-button" data-copy-title="${rdsCode}" title="Copier le code RDS">📋</button>
      <button class="rtconnect-rds-link-button" data-rds-link="${rdsCode}" title="Accéder au RDS (${rdsCode})">🔗</button>
    </div>
    <div style="display: flex; gap: 8px; align-items: center;">
      ${navigationButtons}
      <button class="rtconnect-dashboard-close">✖</button>
    </div>
  `;

  // Content
  const content = document.createElement('div');
  content.className = 'rtconnect-dashboard-content';
  
  // Créer les onglets
  const tabsContainer = document.createElement('div');
  tabsContainer.className = 'rtconnect-tabs';
  
  // Compter les données pour les badges (sécuriser contre rdsData null)
  const techInfoCount = rdsData?.infosTechniques ? Object.keys(rdsData.infosTechniques).length : 0;
  const radiusAttrCount = rdsData?.attributsRadius ? rdsData.attributsRadius.length : 0;
  
  tabsContainer.innerHTML = `
    <button class="rtconnect-tab active" data-tab="general">
      📊 Général
    </button>
    <button class="rtconnect-tab" data-tab="tech" ${techInfoCount === 0 ? 'style="opacity: 0.5;"' : ''}>
      📄 Technique
      ${techInfoCount > 0 ? `<span class="rtconnect-tab-badge">${techInfoCount}</span>` : ''}
    </button>
    <button class="rtconnect-tab" data-tab="radius" ${radiusAttrCount === 0 ? 'style="opacity: 0.5;"' : ''}>
      🔄 Radius
      ${radiusAttrCount > 0 ? `<span class="rtconnect-tab-badge">${radiusAttrCount}</span>` : ''}
    </button>
  `;
  
  // Créer le contenu des onglets
  const tabContent = document.createElement('div');
  tabContent.className = 'rtconnect-tab-content';
  
  // Onglet Général
  const generalPane = document.createElement('div');
  generalPane.className = 'rtconnect-tab-pane active';
  generalPane.dataset.pane = 'general';
  
  const generalGrid = document.createElement('div');
  generalGrid.className = 'rtconnect-info-grid';
  
  // Informations principales (sécuriser contre rdsData null)
  const mainItems = [
    { label: '🏠 Site', value: rdsData?.site, field: 'site' },
    { label: '🏢 Offre', value: rdsData?.offre, field: 'offre' },
    { label: '🌐 IP Supervision', value: rdsData?.ipSupervision, field: 'ipSupervision' },
    { label: '📡 IP WAN CPE', value: rdsData?.ipWanCpe, field: 'ipWanCpe' },
    { label: '🔑 Login Radius', value: rdsData?.loginRadius, field: 'loginRadius' },
    { label: '🔒 Password Radius', value: rdsData?.passwordRadius, field: 'passwordRadius' },
    { label: '👥 Groupe Radius', value: rdsData?.groupeRadius, field: 'groupeRadius' }
  ];
  
  const mainCardsHtml = mainItems.map(item => {
    const value = item.value || (rdsData ? 'Non disponible' : 'Chargement...');
    const isEmpty = !item.value;
    const isLoading = !rdsData;
    return `
      <div class="rtconnect-info-card">
        <div class="rtconnect-info-row">
          <div class="rtconnect-info-label">${item.label.replace(/[🏠🏢🌐📡🔑🔒👥]/g, '').trim()}</div>
          <div class="rtconnect-info-value ${isEmpty ? 'empty' : ''} ${isLoading ? 'loading' : ''}">${value}</div>
          ${!isEmpty && !isLoading ? `<button class="rtconnect-copy-button" data-copy-value="${value}" title="Copier">📋</button>` : ''}
        </div>
      </div>
    `;
  }).join('');
  
  generalGrid.innerHTML = mainCardsHtml;
  generalPane.appendChild(generalGrid);
  
  // Onglet Technique
  const techPane = document.createElement('div');
  techPane.className = 'rtconnect-tab-pane';
  techPane.dataset.pane = 'tech';
  
  const techGrid = document.createElement('div');
  techGrid.className = 'rtconnect-info-grid';
  
  if (rdsData?.infosTechniques && Object.keys(rdsData.infosTechniques).length > 0) {
    const techCardsHtml = Object.entries(rdsData.infosTechniques).map(([key, info]) => `
      <div class="rtconnect-info-card tech-info">
        <div class="rtconnect-info-row">
          <div class="rtconnect-info-label">${info.label}</div>
          <div class="rtconnect-info-value">${info.value}</div>
          <button class="rtconnect-copy-button" data-copy-value="${info.value}" title="Copier">📋</button>
        </div>
      </div>
    `).join('');
    techGrid.innerHTML = techCardsHtml;
  } else {
    const message = !rdsData ? 'Chargement des données techniques...' : 'Les données techniques ne sont pas disponibles pour ce RDS';
    const icon = !rdsData ? '🔄' : '📄';
    const loadingClass = !rdsData ? 'loading' : '';
    techGrid.innerHTML = `
      <div class="rtconnect-info-card ${loadingClass}" style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #6c757d;">
        <div style="font-size: 48px; margin-bottom: 16px;">${icon}</div>
        <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">${!rdsData ? 'Chargement...' : 'Aucune information technique'}</div>
        <div style="font-size: 14px;">${message}</div>
      </div>
    `;
  }
  
  techPane.appendChild(techGrid);
  
  // Onglet Radius
  const radiusPane = document.createElement('div');
  radiusPane.className = 'rtconnect-tab-pane';
  radiusPane.dataset.pane = 'radius';
  
  const radiusGrid = document.createElement('div');
  radiusGrid.className = 'rtconnect-info-grid';
  
  if (rdsData?.attributsRadius && rdsData.attributsRadius.length > 0) {
    const radiusCardsHtml = rdsData.attributsRadius.map((attr, index) => {
      const attrValue = `${attr.nom} ${attr.operateur} ${attr.valeur}`;
      return `
        <div class="rtconnect-info-card radius-attr">
          <div class="rtconnect-info-row">
            <div class="rtconnect-info-label">Attribut ${index + 1}</div>
            <div class="rtconnect-info-value">${attrValue}</div>
            <button class="rtconnect-copy-button" data-copy-value="${attrValue}" title="Copier">📋</button>
          </div>
        </div>
      `;
    }).join('');
    
    // Bouton copier tout
    const allAttributsText = rdsData.attributsRadius
      .map(attr => `${attr.nom} ${attr.operateur} ${attr.valeur}`)
      .join('\n');
    
    const copyAllCard = `
      <div class="rtconnect-info-card" style="grid-column: 1 / -1; text-align: center; background: linear-gradient(135deg, #e9ecef 0%, #f8f9fa 100%);">
        <div class="rtconnect-info-row" style="justify-content: center;">
          <button class="rtconnect-copy-button" data-copy-value="${allAttributsText}" title="Copier tous les attributs" style="background: #667eea; color: white; padding: 8px 16px; font-weight: 600;">
            🔄 Copier tous les attributs (${rdsData.attributsRadius.length})
          </button>
        </div>
      </div>
    `;
    
    radiusGrid.innerHTML = radiusCardsHtml + copyAllCard;
  } else {
    const message = !rdsData ? 'Chargement des attributs Radius...' : 'Aucun attribut Radius configuré pour ce RDS';
    const icon = !rdsData ? '🔄' : '🔄';
    const loadingClass = !rdsData ? 'loading' : '';
    radiusGrid.innerHTML = `
      <div class="rtconnect-info-card ${loadingClass}" style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #6c757d;">
        <div style="font-size: 48px; margin-bottom: 16px;">${icon}</div>
        <div style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">${!rdsData ? 'Chargement...' : 'Aucun attribut Radius'}</div>
        <div style="font-size: 14px;">${message}</div>
      </div>
    `;
  }
  
  radiusPane.appendChild(radiusGrid);
  
  // Assembler le contenu des onglets
  tabContent.appendChild(generalPane);
  tabContent.appendChild(techPane);
  tabContent.appendChild(radiusPane);
  
  content.appendChild(tabsContainer);
  content.appendChild(tabContent);

  // Footer
  const footer = document.createElement('div');
  footer.className = 'rtconnect-dashboard-footer';
  footer.innerHTML = '🚀 RTConnect - Données temps réel';

  // Assembler le dashboard
  dashboard.appendChild(header);
  dashboard.appendChild(content);
  dashboard.appendChild(footer);

  // Ajouter au DOM
  document.body.appendChild(overlay);
  document.body.appendChild(dashboard);

  // Gestionnaire de fermeture
  const closeButton = dashboard.querySelector('.rtconnect-dashboard-close');
  if (closeButton) {
    closeButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log('🔄 Fermeture dashboard via bouton');
      closeDashboard();
    });
  }

  // DÉLÉGATION D'ÉVÉNEMENTS pour tous les boutons de copie
  dashboard.addEventListener('click', async (e) => {
    const target = e.target;
    
    // Gérer les onglets
    if (target.matches('.rtconnect-tab')) {
      e.preventDefault();
      e.stopPropagation();
      
      const tabName = target.dataset.tab;
      if (tabName) {
        console.log('🔄 Changement d\'onglet vers:', tabName);
        
        // Mettre à jour les onglets actifs
        dashboard.querySelectorAll('.rtconnect-tab').forEach(tab => {
          tab.classList.remove('active');
        });
        target.classList.add('active');
        
        // Mettre à jour les contenus actifs
        dashboard.querySelectorAll('.rtconnect-tab-pane').forEach(pane => {
          pane.classList.remove('active');
        });
        const targetPane = dashboard.querySelector(`[data-pane="${tabName}"]`);
        if (targetPane) {
          targetPane.classList.add('active');
        }
      }
      return;
    }
    
    // Gérer les boutons de copie standard
    if (target.matches('.rtconnect-copy-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const valueTooCopy = target.dataset.copyValue;
      if (valueTooCopy) {
        console.log('🔍 Copie bouton standard:', valueTooCopy);
        await handleCopy(valueTooCopy, target);
      }
    }
    
    // Gérer le bouton de copie du titre RDS
    else if (target.matches('.rtconnect-title-copy-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const rdsCodeToCopy = target.dataset.copyTitle;
      if (rdsCodeToCopy) {
        console.log('🔍 Copie titre RDS:', rdsCodeToCopy);
        await handleCopy(rdsCodeToCopy, target);
      }
    }
    
    // Gérer le bouton de lien direct au RDS
    else if (target.matches('.rtconnect-rds-link-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const rdsCodeForLink = target.dataset.rdsLink;
      if (rdsCodeForLink) {
        const rdsUrl = `http://ref-technique.linkt.lan/abonnement/get/${rdsCodeForLink}#Provisioning`;
        console.log('🔗 Ouverture lien RDS:', rdsUrl);
        window.open(rdsUrl, '_blank');
      }
    }
    
    // Gérer les boutons de navigation entre RDS
    else if (target.matches('.rtconnect-nav-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const targetRDS = target.dataset.navRds;
      if (targetRDS) {
        console.log('🔄 Navigation vers RDS:', targetRDS);
        
        // Récupérer les données depuis le cache
        const cachedData = rdsCache.get(targetRDS);
        if (cachedData && cachedData.success) {
          console.log(`🔄 Utilisation cache pour navigation vers ${targetRDS}`);
          createDashboard(targetRDS, cachedData.data);
        } else {
          // Créer le dashboard en mode chargement
          console.log(`🔄 Navigation vers ${targetRDS} - Données pas encore chargées`);
          createDashboard(targetRDS, null);
          
          // Afficher un message d'attente plus spécifique
          setTimeout(() => {
            const dashboardElement = document.getElementById(`rtconnect-dashboard-${targetRDS}`);
            if (dashboardElement) {
              const statusCards = dashboardElement.querySelectorAll('.rtconnect-status-card, .rtconnect-status-row');
              statusCards.forEach(card => {
                if (card.classList.contains('loading')) {
                  card.innerHTML = `
                    <div style="text-align: center; padding: 20px;">
                      <div style="font-size: 32px; margin-bottom: 12px;">🔄</div>
                      <div style="font-weight: 600; margin-bottom: 8px;">RDS ${targetRDS} en cours de chargement...</div>
                      <div style="font-size: 12px; opacity: 0.8;">Les données se chargeront automatiquement lorsqu'elles seront disponibles.</div>
                    </div>
                  `;
                }
              });
            }
          }, 500);
        }
      }
    }
    
    // Gérer les boutons de copie d'attributs
    else if (target.matches('.rtconnect-attribut-copy')) {
      e.preventDefault();
      e.stopPropagation();
      
      const valueTooCopy = target.dataset.copyValue;
      if (valueTooCopy) {
        console.log('🔍 Copie attribut:', valueTooCopy);
        await handleCopy(valueTooCopy, target, true);
      }
    }
    
    // Gérer le bouton "Tout copier"
    else if (target.matches('.rtconnect-copy-all-button')) {
      e.preventDefault();
      e.stopPropagation();
      
      const valueTooCopy = target.dataset.copyAll;
      if (valueTooCopy) {
        console.log('🔍 Copie tout:', valueTooCopy);
        await handleCopy(valueTooCopy, target);
      }
    }
  });

  // Stocker la référence
  activeDashboards.set(rdsCode, { overlay, dashboard });
  
  // Si des IPs sont manquantes, lancer la récupération en arrière-plan
  const needsIPs = !rdsData?.ipSupervision || !rdsData?.ipWanCpe;
  if (needsIPs) {
    console.log(`🔄 Lancement récupération IPs en arrière-plan pour ${rdsCode}`);
    fetchIPsInBackground(rdsCode);
  }
}

// Fonction pour fermer tous les dashboards
function closeDashboard() {
  activeDashboards.forEach(({ overlay, dashboard }) => {
    if (overlay && overlay.parentNode) overlay.remove();
    if (dashboard && dashboard.parentNode) dashboard.remove();
  });
  activeDashboards.clear();
}

// Fonction pour mettre à jour un dashboard existant avec de nouvelles données
function updateDashboard(rdsCode, rdsData) {
  const dashboardElement = document.getElementById(`rtconnect-dashboard-${rdsCode}`);
  if (dashboardElement) {
    console.log(`🔄 Mise à jour automatique du dashboard pour ${rdsCode}`);
    
    // Mettre à jour chaque carte individuellement
    updateDashboardCard(dashboardElement, 'site', rdsData?.site, '🏠 Site');
    updateDashboardCard(dashboardElement, 'offre', rdsData?.offre, '🏢 Offre');
    updateDashboardCard(dashboardElement, 'ipSupervision', rdsData?.ipSupervision, '🌐 IP Supervision');
    updateDashboardCard(dashboardElement, 'ipWanCpe', rdsData?.ipWanCpe, '📡 IP WAN CPE');
    updateDashboardCard(dashboardElement, 'loginRadius', rdsData?.loginRadius, '🔑 Login Radius');
    updateDashboardCard(dashboardElement, 'passwordRadius', rdsData?.passwordRadius, '🔒 Password Radius');
    updateDashboardCard(dashboardElement, 'groupeRadius', rdsData?.groupeRadius, '👥 Groupe Radius');
    
    // Mettre à jour les attributs (plus complexe)
    updateAttributsCard(dashboardElement, rdsData?.attributsRadius);
    
    // Mettre à jour les badges des onglets
    const techInfoCount = rdsData?.infosTechniques ? Object.keys(rdsData.infosTechniques).length : 0;
    const radiusAttrCount = rdsData?.attributsRadius ? rdsData.attributsRadius.length : 0;
    
    const techTab = dashboardElement.querySelector('[data-tab="tech"]');
    const radiusTab = dashboardElement.querySelector('[data-tab="radius"]');
    
    if (techTab) {
      const existingBadge = techTab.querySelector('.rtconnect-tab-badge');
      if (techInfoCount > 0) {
        if (existingBadge) {
          existingBadge.textContent = techInfoCount;
        } else {
          techTab.innerHTML += ` <span class="rtconnect-tab-badge">${techInfoCount}</span>`;
        }
        techTab.style.opacity = '1';
      } else {
        if (existingBadge) existingBadge.remove();
        techTab.style.opacity = '0.5';
      }
    }
    
    if (radiusTab) {
      const existingBadge = radiusTab.querySelector('.rtconnect-tab-badge');
      if (radiusAttrCount > 0) {
        if (existingBadge) {
          existingBadge.textContent = radiusAttrCount;
        } else {
          radiusTab.innerHTML += ` <span class="rtconnect-tab-badge">${radiusAttrCount}</span>`;
        }
        radiusTab.style.opacity = '1';
      } else {
        if (existingBadge) existingBadge.remove();
        radiusTab.style.opacity = '0.5';
      }
    }
  }
}

// Fonction pour mettre à jour une carte spécifique
function updateDashboardCard(dashboardElement, fieldName, value, label) {
  try {
    if (!dashboardElement || !dashboardElement.isConnected) {
      console.warn('🔄 Dashboard non trouvé ou déconnecté du DOM');
      return;
    }

    const cards = Array.from(dashboardElement.querySelectorAll('.rtconnect-info-card')).filter(card => card.isConnected);
    if (!cards.length) {
      console.warn('🔄 Aucune carte trouvée dans le dashboard');
      return;
    }

    cards.forEach(card => {
      try {
        const labelElement = card.querySelector('.rtconnect-info-label');
        if (!labelElement || !labelElement.isConnected) return;

        const cleanLabel = label.replace(/[🏠🏢🌐📡🔑🔒👥]/g, '').trim();
        if (labelElement.textContent.includes(cleanLabel)) {
          const valueElement = card.querySelector('.rtconnect-info-value');
          if (!valueElement || !valueElement.isConnected) return;

          let displayValue = value;
          let shouldShowCopyButton = true;
          
          // Gestion spéciale pour les IPs
          if (fieldName === 'ipSupervision' || fieldName === 'ipWanCpe') {
            if (value) {
              // Afficher la valeur exacte (avec ou sans IP)
              displayValue = value;
              // Permettre la copie même pour "Aucune IP n'a été réservée"
              shouldShowCopyButton = true;
              console.log(`✅ ${label} mis à jour: ${value}`);
            } else {
              displayValue = 'Non disponible';
              shouldShowCopyButton = false;
              console.log(`⚠️ ${label} reste non disponible`);
            }
          } else {
            // Gestion normale pour les autres champs
            if (value) {
              displayValue = value;
              shouldShowCopyButton = true;
              console.log(`✅ ${label} mis à jour: ${value}`);
            } else {
              displayValue = 'Non disponible';
              shouldShowCopyButton = false;
            }
          }
          
          valueElement.textContent = displayValue;
          valueElement.classList.remove('empty', 'loading');
          
          if (!shouldShowCopyButton) {
            valueElement.classList.add('empty');
          }
          
          // Gérer le bouton copier
          let copyButton = card.querySelector('.rtconnect-copy-button');
          
          if (shouldShowCopyButton) {
            if (!copyButton) {
              // Créer le bouton copier s'il n'existe pas
              copyButton = document.createElement('button');
              copyButton.className = 'rtconnect-copy-button';
              copyButton.innerHTML = '📋';
              copyButton.title = 'Copier';
              const infoRow = card.querySelector('.rtconnect-info-row');
              if (infoRow) {
                infoRow.appendChild(copyButton);
              }
            }
            copyButton.dataset.copyValue = displayValue;
            copyButton.style.display = 'inline-block';
          } else {
            if (copyButton) {
              copyButton.style.display = 'none';
              copyButton.removeAttribute('data-copy-value');
            }
          }
        }
      } catch (cardError) {
        console.warn('🔄 Erreur lors de la mise à jour d\'une carte:', cardError);
      }
    });
  } catch (error) {
    console.warn('🔄 Erreur générale dans updateDashboardCard:', error);
  }
}

// Fonction pour mettre à jour les attributs
function updateAttributsCard(dashboardElement, attributsRadius) {
  const cards = dashboardElement.querySelectorAll('.rtconnect-info-card');
  cards.forEach(card => {
    const labelElement = card.querySelector('.rtconnect-info-label');
    if (labelElement && labelElement.textContent === '🔄 Attributs Radius') {
      const valueElement = card.querySelector('.rtconnect-info-value');
      if (valueElement) {
        let attributsContent = 'Non disponible';
        if (attributsRadius && attributsRadius.length > 0) {
          // Créer une liste stylée des attributs avec boutons copier
          const attributsList = attributsRadius.map((attr, index) => {
            const attributValue = `${attr.nom}${attr.operateur}${attr.valeur}`;
            return `<div class="rtconnect-attribut-item">
              <span class="rtconnect-attribut-name">${attr.nom}</span>
              <span class="rtconnect-attribut-op">${attr.operateur}</span>
              <span class="rtconnect-attribut-value">${attr.valeur}</span>
              <button class="rtconnect-attribut-copy" data-copy-value="${attributValue}">📋</button>
            </div>`;
          }).join('');
          
          // Récupérer le code RDS depuis l'ID du dashboard
          const dashboardId = dashboardElement.id;
          const rdsCode = dashboardId.replace('rtconnect-dashboard-', '');
          const allAttributsText = attributsRadius
            .map(attr => `${attr.nom}${attr.operateur}${attr.valeur}`)
            .join('\n');
          const copyAllBtn = `<button class="rtconnect-copy-all-button" data-copy-all="${allAttributsText}">📋 Tout copier</button>`;
          
          attributsContent = `
            <div style="max-height: 250px; overflow-y: auto; border: 1px solid #dee2e6; border-radius: 6px; padding: 12px;">
              ${attributsList}
            </div>
            <div style="margin-top: 12px; font-size: 11px; color: #6c757d; border-top: 1px solid #dee2e6; padding-top: 12px; text-align: center; font-weight: 600; display: flex; justify-content: space-between; align-items: center;">
              <span>📋 ${attributsRadius.length} attribut(s) Radius configuré(s)</span>
              ${copyAllBtn}
            </div>
          `;
          valueElement.classList.remove('empty');
        } else {
          valueElement.classList.add('empty');
        }
        valueElement.innerHTML = attributsContent;
        console.log(`✅ Attributs Radius mis à jour: ${attributsRadius?.length || 0} attributs`);
      }
    }
  });
}

// Fonction pour mettre à jour le statut général
function updateStatusCard(dashboardElement, rdsData) {
  const cards = dashboardElement.querySelectorAll('.rtconnect-info-card');
  cards.forEach(card => {
    const labelElement = card.querySelector('.rtconnect-info-label');
    if (labelElement && labelElement.textContent === 'Statut') {
      const valueElement = card.querySelector('.rtconnect-info-value');
      if (valueElement) {
        const hasData = rdsData && (rdsData.site || rdsData.ipSupervision || rdsData.ipWanCpe || rdsData.loginRadius || rdsData.groupeRadius);
        const statusBadge = hasData ? 
          '<span class="rtconnect-status-badge success">✅ Données disponibles</span>' :
          '<span class="rtconnect-status-badge loading">🔄 Chargement...</span>';
        valueElement.innerHTML = statusBadge;
      }
    }
  });
}

// Fonction simple de détection et traitement RDS
function findAndProcessRDS() {
  console.log('🔍 Recherche de codes RDS dans la page...');
  
  const pageText = document.body.innerText || document.body.textContent || '';
  console.log('🔍 Taille du texte de la page:', pageText.length, 'caractères');
  
  // Afficher un échantillon du texte pour debug
  if (pageText.length > 0) {
    console.log('📄 Échantillon du texte (200 premiers caractères):', pageText.substring(0, 200));
  } else {
    console.log('⚠️ Aucun texte trouvé dans document.body !');
    return;
  }
  
  const rdsRegex = /\b([A-Z]{2}-\d{4}-[A-Z]{2})\b/g;
  const matches = pageText.match(rdsRegex);
  
  if (matches) {
    console.log('✅ Codes RDS trouvés:', matches);
    
    const uniqueRDS = [...new Set(matches)];
    
    // Traitement en batch pour optimiser le chargement
    console.log(`🚀 Pré-chargement en batch de ${uniqueRDS.length} codes RDS`);
    
    uniqueRDS.forEach((rdsCode, index) => {
      if (!processedRDSOnPage.has(rdsCode)) {
        console.log(`🔍 Traitement du code RDS: ${rdsCode} (${index + 1}/${uniqueRDS.length})`);
        processedRDSOnPage.add(rdsCode);
        processRDSInPage(rdsCode);
      } else {
        console.log(`⚠️ ${rdsCode} déjà traité, ignoré`);
      }
    });
    
    // Pré-charger les données pour tous les RDS avec un léger délai pour étaler les requêtes
    uniqueRDS.forEach((rdsCode, index) => {
      if (!rdsCache.has(rdsCode)) {
        // Étaler le pré-chargement sur 2 secondes maximum
        const preloadDelay = Math.min(index * 100, 2000);
        setTimeout(() => {
          const button = document.querySelector(`[data-rds-code="${rdsCode}"]`);
          if (button) {
            console.log(`🔍 Pré-chargement données pour ${rdsCode}`);
            rdsQueue.add(rdsCode, button, false); // false = pas de dashboard ouvert
          } else {
            console.log(`⚠️ Bouton introuvable pour ${rdsCode}, pré-chargement ignoré`);
          }
        }, preloadDelay);
      } else {
        console.log(`💾 ${rdsCode} déjà en cache, pré-chargement ignoré`);
      }
    });
    
  } else {
    console.log('🔄 Aucun code RDS trouvé avec la regex');
    
    // Tests de fallback pour des codes spécifiques
    const testCodes = ['TW-1126-HS', 'FR-1234-AB', 'UK-5678-CD'];
    console.log('🔍 Test de codes spécifiques...', testCodes);
    
    testCodes.forEach(testCode => {
      if (pageText.includes(testCode)) {
        console.log(`✅ Code spécifique ${testCode} trouvé dans le texte !`);
        if (!processedRDSOnPage.has(testCode)) {
          processedRDSOnPage.add(testCode);
          processRDSInPage(testCode);
        }
      } else {
        console.log(`🔄 Code spécifique ${testCode} introuvable`);
      }
    });
  }
  
  // Afficher l'état actuel
  console.log('📊 État actuel RTConnect:');
  console.log('   - RDS traités:', Array.from(processedRDSOnPage));
  console.log('   - RDS en cache:', Array.from(rdsCache.keys()));
  console.log('   - Boutons RDS trouvés:', document.querySelectorAll('.rtconnect-rds-button').length);
}

// Fonction pour traiter un code RDS spécifique dans la page
function processRDSInPage(rdsCode) {
  console.log(`🔍 Traitement de ${rdsCode} dans la page...`);
  
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );
  
  const textNodes = [];
  let node;
  while (node = walker.nextNode()) {
    if (node.textContent.includes(rdsCode)) {
      textNodes.push(node);
    }
  }
  
  console.log(`🔍 ${textNodes.length} nœuds contiennent ${rdsCode}`);
  
  textNodes.forEach(textNode => {
    replaceRDSInTextNode(textNode, rdsCode);
  });
}

// Fonction pour remplacer le code RDS dans un nÅud de texte
function replaceRDSInTextNode(textNode, rdsCode) {
  const text = textNode.textContent;
  const index = text.indexOf(rdsCode);
  
  if (index === -1) return;
  
  console.log(`🔍 Remplacement de ${rdsCode} dans: "${text.substring(0, 50)}..."`);
  
  const beforeText = text.substring(0, index);
  const afterText = text.substring(index + rdsCode.length);
  
  // Créer le bouton RDS moderne
  const rdsButton = document.createElement('button');
  rdsButton.className = 'rtconnect-rds-button loading';
  rdsButton.innerHTML = `${rdsCode} <span style="font-size: 10px;">🔄</span>`;
  rdsButton.dataset.rdsCode = rdsCode;
  
  // Gestionnaire de clic pour ouvrir le dashboard
  rdsButton.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    console.log(`Ouverture dashboard pour ${rdsCode}`);
    
    const cachedData = rdsCache.get(rdsCode);
    if (cachedData && cachedData.success) {
      // Afficher immédiatement les données en cache
      console.log(`Utilisation cache existant pour dashboard ${rdsCode}`);
      createDashboard(rdsCode, cachedData.data);
    } else {
      // Pas de données en cache - Afficher le dashboard avec message d'attente
      console.log(`Dashboard ${rdsCode} - En attente du chargement initial...`);
      createDashboard(rdsCode, null);
      
      // Demander le chargement des données seulement si pas en cache
      console.log(`Chargement des données pour ${rdsCode} (pas en cache)`);
      rdsQueue.add(rdsCode, rdsButton, true); // true = dashboard ouvert
    }
  };
  
  // Remplacer le nœud de texte
  const parent = textNode.parentNode;
  if (parent) {
    parent.removeChild(textNode);
    
    if (beforeText) {
      parent.insertBefore(document.createTextNode(beforeText), null);
    }
    
    parent.insertBefore(rdsButton, null);
    
    if (afterText) {
      parent.insertBefore(document.createTextNode(afterText), null);
    }
    
    console.log(`✅ ${rdsCode} remplacé avec succès`);
  }
}

// Fonction pour récupérer les données RDS via API (maintenant utilise la file d'attente)
async function fetchRDSData(rdsCode, buttonElement, isDashboardOpen = false) {
  console.log(`Ajout de ${rdsCode} à la file d'attente RDS`);
  rdsQueue.add(rdsCode, buttonElement, isDashboardOpen);
}

// Fonction pour mettre à jour le bouton RDS
function updateRDSButton(data, buttonElement, rdsCode) {
  console.log(`🔍 Mise à jour bouton pour ${rdsCode}`, data);
  
  // Vérifier d'abord si la requête a réussi côté serveur
  if (!data || data.success === false) {
    console.log(`❌ Requête échouée pour ${rdsCode}:`, data?.error || 'Données manquantes');
    scheduleRetry(rdsCode, buttonElement, data?.error || 'Requête échouée');
    return;
  }
  
  const rdsData = data.data || data;
  console.log(`📊 Données extraites pour ${rdsCode}:`, {
    success: data.success,
    site: rdsData?.site,
    ipSupervision: rdsData?.ipSupervision,
    ipWanCpe: rdsData?.ipWanCpe,
    loginRadius: rdsData?.loginRadius,
    groupeRadius: rdsData?.groupeRadius,
    attributsRadius: rdsData?.attributsRadius?.length || 0
  });
  
  // Si la requête a réussi côté serveur, on considère comme succès même avec données partielles
  if (data.success === true) {
    // Vérifier si on doit faire un retry seulement pour les IPs manquantes
    const needsIPRetry = shouldRetryForMissingIPs(rdsData);
    
    if (needsIPRetry) {
      console.log(`🔄 ${rdsCode} - IPs manquantes, retry programmé pour les récupérer`);
      scheduleIPRetry(rdsCode, buttonElement, rdsData);
    } else {
      // Nettoyer le retry s'il y en avait un
      if (retryQueue.has(rdsCode)) {
        const retryInfo = retryQueue.get(rdsCode);
        if (retryInfo.timeoutId) {
          clearTimeout(retryInfo.timeoutId);
        }
        retryQueue.delete(rdsCode);
        console.log(`✅ ${rdsCode} retiré de la queue de retry (données suffisantes)`);
      }
    }
    
    // Mettre à jour le cache avec les données reçues
    rdsCache.set(rdsCode, data);
    console.log(`💾 Cache mis à jour pour ${rdsCode}`);
    
    // Mettre à jour TOUS les boutons avec ce code RDS
    const allRDSButtons = document.querySelectorAll(`[data-rds-code="${rdsCode}"]`);
    allRDSButtons.forEach(btn => {
      btn.className = 'rtconnect-rds-button';
      btn.innerHTML = `${rdsCode} <span style="font-size: 10px;">▼</span>`;
    });
    
    const hasAnyData = rdsData && (rdsData.site || rdsData.ipSupervision || rdsData.ipWanCpe || rdsData.loginRadius || rdsData.groupeRadius || (rdsData.attributsRadius && rdsData.attributsRadius.length > 0));
    console.log(`✅ ${rdsCode} - ${allRDSButtons.length} bouton(s) mis à jour avec succès ${hasAnyData ? '(avec données)' : '(réponse vide)'}`);
    
  } else {
    // Si pas de flag success explicite, vérifier les données comme avant
    if (rdsData && (rdsData.site || rdsData.ipSupervision || rdsData.ipWanCpe || rdsData.loginRadius || rdsData.groupeRadius || (rdsData.attributsRadius && rdsData.attributsRadius.length > 0))) {
      // Vérifier si on doit faire un retry seulement pour les IPs manquantes
      const needsIPRetry = shouldRetryForMissingIPs(rdsData);
      
      if (needsIPRetry) {
        console.log(`🔄 ${rdsCode} - IPs manquantes, retry programmé pour les récupérer`);
        scheduleIPRetry(rdsCode, buttonElement, rdsData);
      } else {
        // Nettoyer le retry s'il y en avait un
        if (retryQueue.has(rdsCode)) {
          const retryInfo = retryQueue.get(rdsCode);
          if (retryInfo.timeoutId) {
            clearTimeout(retryInfo.timeoutId);
          }
          retryQueue.delete(rdsCode);
          console.log(`✅ ${rdsCode} retiré de la queue de retry (données détectées)`);
        }
      }
      
      // Mettre à jour le cache avec les données reçues
      rdsCache.set(rdsCode, { success: true, data: rdsData });
      console.log(`💾 Cache mis à jour pour ${rdsCode} (données détectées)`);
      
      // Mettre à jour TOUS les boutons avec ce code RDS
      const allRDSButtons = document.querySelectorAll(`[data-rds-code="${rdsCode}"]`);
      allRDSButtons.forEach(btn => {
        btn.className = 'rtconnect-rds-button';
        btn.innerHTML = `📋 ${rdsCode} <span style="font-size: 10px;">▼</span>`;
      });
      
      console.log(`✅ ${rdsCode} - ${allRDSButtons.length} bouton(s) mis à jour avec succès (données détectées)`);
    } else {
      console.log(`⚠️ Aucune donnée valide trouvée pour ${rdsCode} - Pas de retry (données fixes manquantes)`);
      // Pas de retry pour les données fixes manquantes, on met en mode "incomplet" mais fonctionnel
      updateButtonIncomplete(buttonElement, rdsCode);
    }
  }
}

// Fonction pour vérifier s'il faut faire un retry seulement pour les IPs manquantes
function shouldRetryForMissingIPs(rdsData) {
  // On fait un retry seulement si au moins une donnée de base est présente
  // ET qu'au moins une IP est manquante
  const hasBasicData = rdsData && (
    rdsData.site || 
    rdsData.loginRadius || 
    rdsData.groupeRadius || 
    (rdsData.attributsRadius && rdsData.attributsRadius.length > 0)
  );
  
  const missingIPs = !rdsData?.ipSupervision || !rdsData?.ipWanCpe;
  
  return hasBasicData && missingIPs;
}

// Fonction pour programmer un retry spécifiquement pour les IPs
function scheduleIPRetry(rdsCode, buttonElement, existingData) {
  if (retryQueue.has(rdsCode)) {
    const retryInfo = retryQueue.get(rdsCode);
    retryInfo.attempts++;
    
    if (retryInfo.attempts >= MAX_RETRIES) {
      console.log(`❌ ${rdsCode} - Maximum de tentatives atteint pour les IPs (${MAX_RETRIES}) - Abandon`);
      retryQueue.delete(rdsCode);
      // Ne pas mettre hors ligne, garder les données existantes
      return;
    }
    
    console.log(`🔄 ${rdsCode} - Retry IPs programmé dans 30s (TENTATIVE ${retryInfo.attempts}/${MAX_RETRIES})`);
  } else {
    console.log(`⏰ ${rdsCode} - Premier retry IPs programmé dans 30s`);
    retryQueue.set(rdsCode, { attempts: 1, buttonElement, type: 'ip_only', existingData });
  }
  
  const retryInfo = retryQueue.get(rdsCode);
  
  // Annuler le timeout précédent s'il existe
  if (retryInfo.timeoutId) {
    clearTimeout(retryInfo.timeoutId);
  }
  
  const timeoutId = setTimeout(() => {
    console.log(`🔄 ${rdsCode} - Exécution du retry IPs (TENTATIVE ${retryInfo.attempts}/${MAX_RETRIES})`);
    // Utiliser fetchIPsInBackground pour récupérer seulement les IPs
    fetchIPsInBackground(rdsCode);
  }, RETRY_INTERVAL);
  
  retryInfo.timeoutId = timeoutId;
  // Ne pas changer l'apparence du bouton pour un retry IPs seulement
}

// Fonction pour programmer un retry général (en cas d'erreur serveur)
function scheduleRetry(rdsCode, buttonElement, reason) {
  if (retryQueue.has(rdsCode)) {
    const retryInfo = retryQueue.get(rdsCode);
    retryInfo.attempts++;
    
    if (retryInfo.attempts >= MAX_RETRIES) {
      console.log(`❌ ${rdsCode} - Maximum de tentatives atteint (${MAX_RETRIES}) - Abandon`);
      updateButtonOffline(buttonElement, rdsCode);
      retryQueue.delete(rdsCode);
      return;
    }
    
    console.log(`🔄 ${rdsCode} - Retry programmé dans 30s (ECHEC ${retryInfo.attempts}/${MAX_RETRIES})`);
  } else {
    console.log(`⏰ ${rdsCode} - Premier retry programmé dans 30s (raison: ${reason})`);
    retryQueue.set(rdsCode, { attempts: 1, buttonElement, type: 'full' });
  }
  
  const retryInfo = retryQueue.get(rdsCode);
  
  // Annuler le timeout précédent s'il existe
  if (retryInfo.timeoutId) {
    clearTimeout(retryInfo.timeoutId);
  }
  
  const timeoutId = setTimeout(() => {
    console.log(`🔄 ${rdsCode} - Exécution du retry (TENTATIVE ${retryInfo.attempts}/${MAX_RETRIES})`);
    rdsQueue.add(rdsCode, retryInfo.buttonElement, false, true); // true = forceRefresh
  }, RETRY_INTERVAL);
  
  retryInfo.timeoutId = timeoutId;
  updateButtonRetrying(buttonElement, retryInfo.attempts);
}

// Fonction pour mettre à jour le bouton en mode incomplet mais fonctionnel
function updateButtonIncomplete(buttonElement, rdsCode) {
  // Mettre à jour TOUS les boutons avec ce code RDS
  const allRDSButtons = document.querySelectorAll(`[data-rds-code="${rdsCode}"]`);
  allRDSButtons.forEach(btn => {
    btn.className = 'rtconnect-rds-button';
    btn.innerHTML = `📋 ${rdsCode} <span style="font-size: 10px; opacity: 0.7;">⚠</span>`;
    btn.title = 'RDS trouvé mais données incomplètes';
  });
  console.log(`⚠️ ${rdsCode} - ${allRDSButtons.length} bouton(s) mis en mode incomplet`);
}

// Fonction pour mettre à jour le bouton en mode retry
function updateButtonRetrying(buttonElement, attempt) {
  const rdsCode = buttonElement.dataset.rdsCode;
  if (rdsCode) {
    // Mettre à jour TOUS les boutons avec ce code RDS
    const allRDSButtons = document.querySelectorAll(`[data-rds-code="${rdsCode}"]`);
    allRDSButtons.forEach(btn => {
      btn.className = 'rtconnect-rds-button loading';
      btn.innerHTML = `⏳ ${rdsCode} (${attempt}/${MAX_RETRIES})`;
    });
    console.log(`🔄 ${rdsCode} - ${allRDSButtons.length} bouton(s) mis en mode retry (${attempt}/${MAX_RETRIES})`);
  }
}

// Fonction pour mettre à jour le bouton en mode hors ligne
function updateButtonOffline(buttonElement, rdsCode) {
  // Mettre à jour TOUS les boutons avec ce code RDS
  const allRDSButtons = document.querySelectorAll(`[data-rds-code="${rdsCode}"]`);
  allRDSButtons.forEach(btn => {
    btn.className = 'rtconnect-rds-button error';
    btn.innerHTML = `⚪ ${rdsCode} (Hors ligne)`;
  });
  console.log(`❌ ${rdsCode} - ${allRDSButtons.length} bouton(s) mis hors ligne`);
}

// Fonction pour récupérer les IPs en arrière-plan
async function fetchIPsInBackground(rdsCode) {
  try {
    console.log(`Récupération IPs en arrière-plan pour ${rdsCode}...`);
    
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'fetchRDSIPs', rdsCode: rdsCode },
        (response) => {
          if (chrome.runtime.lastError) {
            console.error('Erreur runtime IPs:', chrome.runtime.lastError.message);
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            console.log(`Réponse IPs reçue pour ${rdsCode}:`, response);
            resolve(response);
          }
        }
      );
    });

    if (response && response.success) {
      console.log(`✅ IPs reçues pour ${rdsCode}:`, response.data);
      
      // Mettre à jour le dashboard avec les IPs - traiter chaque IP individuellement
      const dashboardElement = document.getElementById(`rtconnect-dashboard-${rdsCode}`);
      if (dashboardElement) {
        // Logs détaillés pour debug
        console.log(`📡 Mise à jour IP Supervision: "${response.data.ipSupervision}" (type: ${typeof response.data.ipSupervision})`);
        console.log(`🌐 Mise à jour IP WAN CPE: "${response.data.ipWanCpe}" (type: ${typeof response.data.ipWanCpe})`);
        
        // Toujours essayer de mettre à jour chaque IP, même si l'une est null
        updateDashboardCard(dashboardElement, 'ipSupervision', response.data.ipSupervision || null, 'IP Supervision');
        updateDashboardCard(dashboardElement, 'ipWanCpe', response.data.ipWanCpe || null, 'IP WAN CPE');
        
        // Mettre à jour le cache avec les nouvelles IPs
        if (rdsCache.has(rdsCode)) {
          const cachedData = rdsCache.get(rdsCode);
          const updatedData = {
            ...cachedData,
            data: {
              ...cachedData.data,
              ipSupervision: response.data.ipSupervision || cachedData.data.ipSupervision,
              ipWanCpe: response.data.ipWanCpe || cachedData.data.ipWanCpe
            }
          };
          rdsCache.set(rdsCode, updatedData);
          console.log(`💾 Cache IPs mis à jour pour ${rdsCode}:`, {
            ipSupervision: updatedData.data.ipSupervision || 'Non disponible',
            ipWanCpe: updatedData.data.ipWanCpe || 'Non disponible'
          });
        }
      } else {
        console.warn(`⚠️ Dashboard ${rdsCode} non trouvé pour mise à jour IPs`);
      }
      
    } else {
      console.log(`Problème récupération IPs pour ${rdsCode}:`, response?.error || 'Réponse vide');
      
      // Mettre les IPs en "Non disponible" après échec seulement si le dashboard existe
      const dashboardElement = document.getElementById(`rtconnect-dashboard-${rdsCode}`);
      if (dashboardElement) {
        console.log(`⚠️ Mise à jour dashboard ${rdsCode} avec IPs non disponibles après échec`);
        updateDashboardCard(dashboardElement, 'ipSupervision', null, 'IP Supervision');
        updateDashboardCard(dashboardElement, 'ipWanCpe', null, 'IP WAN CPE');
      }
    }
    
  } catch (error) {
    console.log(`Erreur récupération IPs pour ${rdsCode}:`, error.message);
    
    // Mettre les IPs en "Non disponible" après erreur
    const dashboardElement = document.getElementById(`rtconnect-dashboard-${rdsCode}`);
    if (dashboardElement) {
      updateDashboardCard(dashboardElement, 'ipSupervision', null, 'IP Supervision');
      updateDashboardCard(dashboardElement, 'ipWanCpe', null, 'IP WAN CPE');
    }
  }
}

// Fonction d'initialisation principale
function init() {
  console.log('🔍 RTConnect - Initialisation sur:', window.location.href);
  console.log('🔍 RTConnect - User agent:', navigator.userAgent);
  console.log('🔍 RTConnect - Document ready state:', document.readyState);
  
  // Injecter les styles CSS
  injectStyles();
  
  // Démarrer le système de vérification de mise à jour
  startUpdateChecker();
  
  // Vérifier si on est sur une page Praxedo supportée
  const isPraxedoPage = window.location.href.includes('eu9.praxedo.com/eTech/IntervAction.do');
  const isAdvancedSearchPage = isPraxedoAdvancedSearchPage();
  
  console.log('🔍 RTConnect - Vérification page Praxedo:', isPraxedoPage);
  console.log('🔍 RTConnect - Vérification page recherche avancée:', isAdvancedSearchPage);
  console.log('🔍 RTConnect - URL complète:', window.location.href);
  console.log('🔍 RTConnect - Hostname:', window.location.hostname);
  console.log('🔍 RTConnect - Pathname:', window.location.pathname);
  console.log('🔍 RTConnect - Search:', window.location.search);
  
  if (isPraxedoPage) {
    console.log('✅ RTConnect - Page Praxedo détectée, démarrage des fonctionnalités RDS...');
    
    // Test immédiat de la taille de la page
    const pageText = document.body.innerText || document.body.textContent || '';
    console.log('📄 RTConnect - Taille contenu page:', pageText.length, 'caractères');
    
    // Test immédiat de recherche RDS
    console.log('🔍 RTConnect - Test immédiat de détection RDS...');
    const rdsRegex = /\b([A-Z]{2}-\d{4}-[A-Z]{2})\b/g;
    const matches = pageText.match(rdsRegex);
    console.log('📊 RTConnect - Codes RDS détectés immédiatement:', matches);
    
    // Démarrer la recherche de codes RDS avec délai
    setTimeout(() => {
      console.log('🚀 RTConnect - Lancement findAndProcessRDS après 2s...');
      findAndProcessRDS();
    }, 2000);
    
    // Démarrage supplémentaire après 5 secondes au cas où
    setTimeout(() => {
      console.log('🔄 RTConnect - Deuxième tentative findAndProcessRDS après 5s...');
      findAndProcessRDS();
    }, 5000);
  
    // Observer les changements DOM pour les nouveaux codes RDS
    const observer = new MutationObserver((mutations) => {
      let shouldReprocess = false;
    
      mutations.forEach(mutation => {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          // Vérifier si les nœuds ajoutés ne sont pas des éléments RTConnect
          const hasNonRTConnectChanges = Array.from(mutation.addedNodes).some(node => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // Ignorer les éléments RTConnect (dashboards, overlays, etc.)
              const hasRTConnectClass = node.className && (
                node.className.includes('rtconnect-dashboard') ||
                node.className.includes('rtconnect-overlay') ||
                node.className.includes('rtconnect-update-toast')
              );
              
              const hasRTConnectId = node.id && (
                node.id.includes('rtconnect-dashboard') ||
                node.id.includes('rtconnect-verification') ||
                node.id.includes('rtconnect-styles')
              );
              
              // Si c'est un élément RTConnect, l'ignorer
              return !hasRTConnectClass && !hasRTConnectId;
            }
            // Pour les nœuds de texte, on considère que c'est un changement valide
            return node.nodeType === Node.TEXT_NODE;
          });
          
          if (hasNonRTConnectChanges) {
            shouldReprocess = true;
          }
        }
      });
    
      if (shouldReprocess) {
        console.log('🔄 RTConnect - Changements DOM détectés (non-RTConnect), retraitement RDS...');
        
        // Utiliser debouncing pour éviter les appels répétés
        if (rdsProcessingTimeout) {
          clearTimeout(rdsProcessingTimeout);
        }
        
        rdsProcessingTimeout = setTimeout(() => {
          console.log('🔄 RTConnect - Exécution du retraitement RDS après debouncing');
          findAndProcessRDS();
          rdsProcessingTimeout = null;
        }, 2000); // Délai augmenté à 2 secondes
      }
    });
  
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    console.log('👀 RTConnect - Observer DOM configuré');
  
    // ===== SYSTÈME DE VÉRIFICATION TECHNIQUE =====
    // Tentatives multiples d'injection du bouton de vérification
    console.log('🔄 RTConnect - Initialisation système de vérification...');
    
    // Première tentative après 2 secondes
    setTimeout(() => {
      console.log('🔄 RTConnect - Tentative 1 d\'injection du bouton de vérification...');
      injectVerificationButton();
      if (verificationButtonInjected) {
        loadCurrentVerificationStatus();
      }
    }, 2000);
    
    // Deuxième tentative après 5 secondes si pas encore injecté
    setTimeout(() => {
      if (!verificationButtonInjected) {
        console.log('🔄 RTConnect - Tentative 2 d\'injection du bouton de vérification...');
        verificationButtonInjected = false; // Reset pour permettre une nouvelle tentative
        injectVerificationButton();
        if (verificationButtonInjected) {
          loadCurrentVerificationStatus();
        }
      }
    }, 5000);
    
    // Troisième tentative après 10 secondes si pas encore injecté
    setTimeout(() => {
      if (!verificationButtonInjected) {
        console.log('🔄 RTConnect - Tentative 3 d\'injection du bouton de vérification...');
        verificationButtonInjected = false; // Reset pour permettre une nouvelle tentative
        injectVerificationButton();
        if (verificationButtonInjected) {
          loadCurrentVerificationStatus();
        }
      }
    }, 10000);

    // Observer les changements DOM pour réinjecter le bouton si nécessaire
    const verificationObserver = new MutationObserver((mutations) => {
      let shouldReinject = false;
      
      mutations.forEach(mutation => {
        if (mutation.type === 'childList') {
          // Vérifier si notre bouton a été supprimé
          if (!document.getElementById('rtconnect-verification-container')) {
            shouldReinject = true;
          }
        }
      });
      
      if (shouldReinject && verificationButtonInjected) {
        console.log('🔄 RTConnect - Bouton supprimé, réinjection...');
        verificationButtonInjected = false;
        setTimeout(() => {
          injectVerificationButton();
          if (verificationButtonInjected) {
            loadCurrentVerificationStatus();
          }
        }, 1000);
      }
    });
    
    verificationObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    console.log('✅ RTConnect - Système de vérification technique initialisé');
    
  } else if (isAdvancedSearchPage) {
    console.log('✅ RTConnect - Page recherche avancée détectée, démarrage affichage statuts...');
    
    // Tentatives plus rapides et optimisées
    const attemptTimes = [100, 300, 800, 1500]; // 0.1s, 0.3s, 0.8s, 1.5s (encore plus rapide)
    
    attemptTimes.forEach((delay, index) => {
      setTimeout(() => {
        console.log(`🔄 RTConnect - Tentative ${index + 1}/${attemptTimes.length} d'injection statuts après ${delay}ms...`);
        injectVerificationStatusInSearchPage();
      }, delay);
    });
    
    // Observer les changements pour réinjecter rapidement si nécessaire
    const searchObserver = new MutationObserver((mutations) => {
      let shouldReinject = false;
      
      mutations.forEach(mutation => {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          // Vérifier si de nouveaux résultats de recherche ont été ajoutés
          const hasNewResults = Array.from(mutation.addedNodes).some(node => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              return node.tagName === 'TABLE' || node.tagName === 'TR' || node.tagName === 'TD' || 
                     node.className && (node.className.includes('search') || node.className.includes('result'));
            }
            return false;
          });
          
          if (hasNewResults) {
            shouldReinject = true;
          }
        }
      });
      
      if (shouldReinject) {
        console.log('🔄 RTConnect - Nouveaux résultats détectés, réinjection statuts rapide...');
        setTimeout(() => {
          injectVerificationStatusInSearchPage();
        }, 50); // Réaction plus rapide : 200ms -> 50ms
      }
    });
    
    searchObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    console.log('✅ RTConnect - Système statuts recherche avancée initialisé');
    
  } else {
    console.log('ℹ️ RTConnect - Page non supportée pour RDS, mais système de mise à jour actif');
    console.log('🔍 RTConnect - Pour info, on est sur:', window.location.href);
    
    // Même sur les pages non supportées, on peut ajouter des logs pour debug
    if (window.location.href.includes('eu9.praxedo.com')) {
      console.log('🔍 RTConnect - Page Praxedo détectée mais non supportée');
      console.log('🔍 RTConnect - Contenu de la page:', document.body.innerText.substring(0, 200) + '...');
    }
  }
}

// Nettoyage lors du déchargement de la page
window.addEventListener('beforeunload', () => {
  console.log('Nettoyage des timers avant déchargement...');
  
  // Arrêter le vérificateur de mise à jour
  stopUpdateChecker();
  
  // Nettoyer le timeout de debouncing RDS
  if (rdsProcessingTimeout) {
    clearTimeout(rdsProcessingTimeout);
    rdsProcessingTimeout = null;
  }
  
  // Nettoyer les timers de retry
  retryQueue.forEach((retryInfo, rdsCode) => {
    if (retryInfo.timeoutId) {
      clearTimeout(retryInfo.timeoutId);
      console.log(`Timer annulé pour ${rdsCode}`);
    }
  });
  retryQueue.clear();
  closeDashboard();
});

// Démarrage
if (document.readyState === 'loading') {
  console.log('🔄 RTConnect - Script chargé, attente DOMContentLoaded...');
  document.addEventListener('DOMContentLoaded', init);
} else {
  console.log('🔄 RTConnect - Script chargé, DOM déjà prêt, initialisation immédiate...');
  init();
}

console.log('✅ RTConnect Content Script chargé et prêt');

// ===== SYSTÈME DE VéRIFICATION TECHNIQUE PRAXEDO =====

// Variables pour la vérification technique
let verificationButtonInjected = false;
let currentVerificationStatus = null;

// Fonction pour détecter si on est sur une page Praxedo d'intervention
function isPraxedoInterventionPage() {
  return window.location.href.includes('eu9.praxedo.com/eTech/IntervAction.do');
}

// Fonction pour injecter le bouton de demande de vérification
function injectVerificationButton() {
  if (verificationButtonInjected || !isPraxedoInterventionPage()) {
    console.log('RTConnect - Injection ignorée:', {
      buttonInjected: verificationButtonInjected,
      isPraxedo: isPraxedoInterventionPage()
    });
      return;
    }

  console.log('RTConnect - Recherche de l\'emplacement pour le bouton de vérification...');

  // Chercher l'élément de référence spécifique
  const workOrderTitle = document.getElementById('workOrderDataTitle');
  
  if (workOrderTitle) {
    console.log('✅ RTConnect - élément workOrderDataTitle trouvé, injection du bouton...');
    
    // Créer le conteneur de vérification
    const verificationContainer = document.createElement('div');
    verificationContainer.id = 'rtconnect-verification-container';
    verificationContainer.style.cssText = `
      margin: 15px 0;
      padding: 12px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    `;
    
    // Créer le bouton de demande de vérification
    const verificationButton = document.createElement('button');
    verificationButton.id = 'rtconnect-verification-btn';
    verificationButton.textContent = 'Demander une vérification technique';
    verificationButton.style.cssText = `
      background: #fff;
      color: #667eea;
      border: none;
      padding: 10px 20px;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      font-size: 14px;
      max-width: 300px;
      width: auto;
      display: block;
      margin: 0 auto;
      transition: all 0.3s ease;
    `;
    
    // Créer le conteneur de statut
    const statusContainer = document.createElement('div');
    statusContainer.id = 'rtconnect-verification-status';
    statusContainer.style.cssText = `
      margin: 10px auto 0 auto;
      padding: 8px 12px;
      border-radius: 4px;
      font-size: 13px;
      display: none;
      max-width: 600px;
      word-wrap: break-word;
      line-height: 1.4;
      text-align: center;
    `;
    
    verificationContainer.appendChild(verificationButton);
    verificationContainer.appendChild(statusContainer);
    
    // Insérer après l'élément workOrderDataTitle
    workOrderTitle.parentNode.insertBefore(verificationContainer, workOrderTitle.nextSibling);
    
    // Ajouter les gestionnaires d'événements
    verificationButton.addEventListener('mouseover', () => {
      verificationButton.style.background = '#f0f0f0';
      verificationButton.style.transform = 'translateY(-1px)';
    });
    
    verificationButton.addEventListener('mouseout', () => {
      verificationButton.style.background = '#fff';
      verificationButton.style.transform = 'translateY(0)';
    });
    
    verificationButton.addEventListener('click', handleVerificationRequest);
    
    verificationButtonInjected = true;
    console.log('✅ RTConnect - Bouton de vérification injecté avec succès après workOrderDataTitle');
      return;
    }

  console.log('RTConnect - élément workOrderDataTitle non trouvé');
  
  // Méthode de fallback : chercher d'autres éléments logiques
  const fallbackSelectors = [
    '.etech-content-title',
    '#content',
    'form[name="intervForm"]',
    'table',
    'body'
  ];
  
  for (const selector of fallbackSelectors) {
    const fallbackElement = document.querySelector(selector);
    if (fallbackElement) {
      console.log(`RTConnect - Injection de fallback avec sélecteur: ${selector}`);
      
      const verificationContainer = document.createElement('div');
      verificationContainer.id = 'rtconnect-verification-container';
      verificationContainer.style.cssText = `
        position: relative;
        margin: 15px;
        padding: 12px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 9999;
      `;
      
      const verificationButton = document.createElement('button');
      verificationButton.id = 'rtconnect-verification-btn';
      verificationButton.textContent = 'Demander une vérification technique';
      verificationButton.style.cssText = `
        background: #fff;
        color: #667eea;
        border: none;
        padding: 10px 20px;
        border-radius: 6px;
        font-weight: bold;
        cursor: pointer;
        font-size: 14px;
        max-width: 300px;
        width: auto;
        display: block;
        margin: 0 auto;
        transition: all 0.3s ease;
      `;
      
      const statusContainer = document.createElement('div');
      statusContainer.id = 'rtconnect-verification-status';
      statusContainer.style.cssText = `
        margin: 10px auto 0 auto;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 13px;
        display: none;
        max-width: 600px;
        word-wrap: break-word;
        line-height: 1.4;
        text-align: center;
      `;
      
      verificationContainer.appendChild(verificationButton);
      verificationContainer.appendChild(statusContainer);
      
      if (selector === 'body') {
        fallbackElement.appendChild(verificationContainer);
      } else {
        fallbackElement.parentNode.insertBefore(verificationContainer, fallbackElement.nextSibling);
      }
      
      verificationButton.addEventListener('click', handleVerificationRequest);
      
      verificationButtonInjected = true;
      console.log(`✅ RTConnect - Bouton de vérification injecté avec fallback (${selector})`);
      return;
    }
  }
  
  console.log('RTConnect - Impossible de trouver un emplacement pour le bouton de vérification');
}

// Fonction pour gérer la demande de vérification
async function handleVerificationRequest() {
  const button = document.getElementById('rtconnect-verification-btn');
  const statusElement = document.getElementById('rtconnect-verification-status');

  if (!button || !statusElement) return;

  console.log('RTConnect - Création demande de vérification...');

  // Désactiver le bouton et montrer le chargement
  button.disabled = true;
  const originalText = button.innerHTML;
  button.innerHTML = 'Envoi de la demande...';

  try {
    // Extraire le numéro d'intervention depuis le DOM
    let interventionNumber = null;
    const interventionElement = document.querySelector('#workOrderDataTitle .no-screen');
    if (interventionElement) {
      interventionNumber = interventionElement.textContent.trim();
      console.log('🔢 RTConnect - Numéro d\'intervention trouvé:', interventionNumber);
    } else {
      console.log('⚠️ RTConnect - Numéro d\'intervention non trouvé dans le DOM');
    }

    // Préparer les données de la demande
    const verificationData = {
      url: window.location.href,
      title: document.title || `Intervention Praxedo - ${new Date().toLocaleDateString()}`,
      description: `Demande de vérification technique pour la page: ${window.location.href}`,
      submittedBy: 'Utilisateur Praxedo',
      interventionNumber: interventionNumber // Nouveau champ
    };

    // Envoyer via le background script
      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
        { type: 'createVerification', data: verificationData },
          (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(response);
            }
          }
        );
      });

    if (response.success) {
      console.log('✅ RTConnect - Demande de vérification créée:', response.data._id);
      
      // Mettre à jour le statut
      updateVerificationStatus('pending', '', '', new Date().toISOString());
      
      // Feedback visuel
      button.innerHTML = '✅ Demande envoyée';
      
      setTimeout(() => {
        button.innerHTML = 'Demande en cours de traitement';
        button.disabled = true;
      }, 2000);

    } else {
      throw new Error(response.error || 'Erreur lors de la création de la demande');
    }

  } catch (error) {
    console.error('RTConnect - Erreur demande vérification:', error);
    
    // Afficher l'erreur
    button.innerHTML = 'Erreur - Réessayer';
    button.disabled = false;
    
    statusElement.style.display = 'block';
    statusElement.style.background = '#f8d7da';
    statusElement.style.color = '#721c24';
    statusElement.innerHTML = `Erreur: ${error.message}`;
    
    setTimeout(() => {
      statusElement.style.display = 'none';
      button.innerHTML = originalText;
    }, 5000);
  }
}

// Fonction pour charger le statut actuel de vérification
async function loadCurrentVerificationStatus() {
  try {
    console.log('RTConnect - Chargement statut vérification actuel...');

    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'getVerificationStatus', url: window.location.href },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
      } else {
            resolve(response);
          }
        }
      );
    });

    if (response.success && response.data) {
      const status = response.data.status;
      console.log('RTConnect - Statut vérification:', status);

      if (status !== 'not_requested') {
        updateVerificationStatus(
          status,
          response.data.comment || '',
          response.data.reviewedBy || '',
          response.data.reviewedAt || ''
        );
      }
      }
      
    } catch (error) {
    console.error('RTConnect - Erreur chargement statut vérification:', error);
  }
}

// Fonction pour mettre à jour l'affichage du statut de vérification
function updateVerificationStatus(status, comment, reviewedBy, reviewedAt) {
  const button = document.getElementById('rtconnect-verification-btn');
  const statusElement = document.getElementById('rtconnect-verification-status');

  if (!button || !statusElement) return;

  currentVerificationStatus = status;

  switch (status) {
    case 'pending':
      button.innerHTML = 'En traitement';
      button.disabled = true;
      
      statusElement.style.display = 'block';
      statusElement.style.background = '#fff3cd';
      statusElement.style.color = '#856404';
      statusElement.innerHTML = 'Demande de vérification en cours de traitement...';
      break;
      
    case 'approved':
      button.innerHTML = '✅ Approuvée';
      button.disabled = true;
      
      statusElement.style.display = 'block';
      statusElement.style.background = '#d4edda';
      statusElement.style.color = '#155724';
      
      let approvedMessage = '✅ Cette intervention a été approuvée techniquement';
      if (reviewedBy) {
        approvedMessage += ` par ${reviewedBy}`;
      }
      if (reviewedAt) {
        const date = new Date(reviewedAt).toLocaleDateString('fr-FR');
        approvedMessage += ` le ${date}`;
      }
      if (comment) {
        approvedMessage += `<br><strong>Commentaire:</strong> ${comment}`;
      }
      statusElement.innerHTML = approvedMessage;
      break;
      
    case 'rejected':
      button.innerHTML = 'Refaire une demande';
      button.disabled = false; // Réactiver pour permettre une nouvelle demande
      
      statusElement.style.display = 'block';
      statusElement.style.background = '#f8d7da';
      statusElement.style.color = '#721c24';
      
      let rejectedMessage = 'Cette intervention a été rejetée techniquement';
      if (reviewedBy) {
        rejectedMessage += ` par ${reviewedBy}`;
      }
      if (reviewedAt) {
        const date = new Date(reviewedAt).toLocaleDateString('fr-FR');
        rejectedMessage += ` le ${date}`;
      }
      if (comment) {
        rejectedMessage += `<br><strong>Raison:</strong> ${comment}`;
      }
      rejectedMessage += `<br><em>Vous pouvez modifier l'intervention et refaire une demande de vérification.</em>`;
      statusElement.innerHTML = rejectedMessage;
      break;
      
    default:
      statusElement.style.display = 'none';
      break;
  }
}

// Fonction pour vérifier si on doit afficher la notification toast
async function shouldShowUpdateToast(newVersion) {
  return new Promise((resolve) => {
    chrome.storage.local.get(['rtconnect_update_toast_dismissed', 'rtconnect_update_toast_dismissed_time'], (result) => {
      const dismissedVersion = result.rtconnect_update_toast_dismissed;
      const dismissedTime = result.rtconnect_update_toast_dismissed_time;
      
      console.log(`RTConnect - Vérification notification pour version ${newVersion}:`);
      console.log(`Version précédemment ignorée: ${dismissedVersion}`);
      console.log(`Temps d'ignore: ${dismissedTime ? new Date(dismissedTime).toLocaleString() : 'jamais'}`);
      
      // DEBUG TEMPORAIRE: Nettoyer l'ancien storage pour tester
      if (newVersion === "2.1.0" && dismissedVersion === "2.1.0") {
        console.log(`🧪 RTConnect - NETTOYAGE DEBUG: suppression ancien reject pour 2.1.0`);
        chrome.storage.local.remove(['rtconnect_update_toast_dismissed', 'rtconnect_update_toast_dismissed_time']);
        resolve(true);
        return;
      }
      
      // Si c'est une version différente de celle rejetée, afficher
      if (dismissedVersion !== newVersion) {
        console.log(`✅ Nouvelle version détectée, affichage de la notification`);
        resolve(true);
      return;
    }

      // Si c'est la même version mais que ça fait plus de 6 heures, afficher à nouveau
      const now = Date.now();
      const hoursAgo = dismissedTime ? (now - dismissedTime) / (1000 * 60 * 60) : Infinity;
      
      console.log(`Heures écoulées depuis dernier ignore: ${hoursAgo.toFixed(2)}h`);
      
      const shouldShow = hoursAgo > 6;
      console.log(`Décision finale: ${shouldShow ? 'AFFICHER' : 'IGNORER'} (seuil: 6h)`);
      
      resolve(shouldShow); // Reposer la question après 6h au lieu de 24h
    });
  });
}

// Fonction pour afficher la notification toast de mise à jour
function showUpdateToast(currentVersion, newVersion, updateUrl) {
  // Vérifier si une notification est déjà affichée
  const existingToast = document.querySelector('.rtconnect-update-toast');
  if (existingToast) {
    existingToast.remove();
  }
  
  console.log('RTConnect - Affichage notification toast de mise à jour');
  
  // Créer la notification toast
  const toast = document.createElement('div');
  toast.className = 'rtconnect-update-toast';
  
  toast.innerHTML = `
    <div class="rtconnect-update-toast-header">
      <div class="rtconnect-update-toast-icon">🚀</div>
      <div class="rtconnect-update-toast-title">RTConnect</div>
      <button class="rtconnect-update-toast-close">🔄</button>
    </div>
    <div class="rtconnect-update-toast-message">
      Nouvelle version disponible !
    </div>
    <div class="rtconnect-update-toast-versions">
      <div>Actuelle: <span class="rtconnect-update-toast-version-current">${currentVersion}</span></div>
      <div>Nouvelle: <span class="rtconnect-update-toast-version-new">${newVersion}</span></div>
    </div>
    <div class="rtconnect-update-toast-actions">
      <button class="rtconnect-update-toast-btn rtconnect-update-toast-btn-later">Plus tard</button>
      <button class="rtconnect-update-toast-btn rtconnect-update-toast-btn-download">Télécharger</button>
    </div>
    <div class="rtconnect-update-toast-progress"></div>
  `;
  
  // Ajouter à la page
  document.body.appendChild(toast);
  
  // Gestionnaires d'événements
  const closeBtn = toast.querySelector('.rtconnect-update-toast-close');
  const laterBtn = toast.querySelector('.rtconnect-update-toast-btn-later');
  const downloadBtn = toast.querySelector('.rtconnect-update-toast-btn-download');
  
  // Fonction pour fermer la notification
  const closeToast = () => {
    toast.style.animation = 'rtconnect-slideOutRight 0.3s ease-out forwards';
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 300);
  };
  
  // Bouton fermer
  closeBtn.onclick = (e) => {
    e.stopPropagation();
    closeToast();
  };
  
  // Bouton "Plus tard"
  laterBtn.onclick = (e) => {
    e.stopPropagation();
    closeToast();
    // Sauvegarder le report
    chrome.storage.local.set({
      'rtconnect_update_toast_dismissed': newVersion,
      'rtconnect_update_toast_dismissed_time': Date.now()
    });
    console.log('RTConnect - Notification toast reportée');
  };
  
  // Bouton "Télécharger"
  downloadBtn.onclick = (e) => {
    e.stopPropagation();
    closeToast();
    window.open(updateUrl, '_blank');
    console.log('RTConnect - Ouverture lien téléchargement:', updateUrl);
  };
  
  // Fermeture automatique après 30 secondes
  setTimeout(() => {
    if (toast.parentNode) {
      closeToast();
    }
  }, UPDATE_NOTIFICATION_DURATION);
}

// Fonction pour démarrer la vérification périodique des mises à jour
function startUpdateChecker() {
  // Vérifier si l'extension est encore valide avant de démarrer
  if (!chrome.runtime || !chrome.runtime.id) {
    console.log('🔄 RTConnect - Extension context invalide, vérificateur non démarré');
    return;
  }
  
  console.log('🚀 RTConnect - Vérificateur de mise à jour démarré');
  
  // Vérification immédiate pour debug (après 3 secondes)
  setTimeout(() => {
    console.log('🧪 RTConnect - Vérification IMMÉDIATE pour debug...');
    checkForUpdates();
  }, 3000);
  
  // Vérification normale après 30 secondes 
  setTimeout(() => {
    console.log('⏰ RTConnect - Vérification normale après 30s...');
    checkForUpdates();
  }, 30000);
  
  // Puis vérification toutes les 10 minutes
  updateCheckInterval = setInterval(() => {
    // Vérifier le contexte avant chaque vérification périodique
    if (!chrome.runtime || !chrome.runtime.id) {
      console.log('🔄 RTConnect - Extension context invalidated, arrêt du vérificateur périodique');
      stopUpdateChecker();
      return;
    }
    
    const now = Date.now();
    if (now - lastUpdateCheck >= UPDATE_CHECK_INTERVAL) {
      lastUpdateCheck = now;
      console.log('🔄 RTConnect - Vérification périodique...');
      checkForUpdates();
    }
  }, UPDATE_CHECK_INTERVAL);
  
  console.log('✅ RTConnect - Vérificateur configuré (vérification toutes les 10 minutes)');
}

// Fonction pour arrêter la vérification périodique
function stopUpdateChecker() {
  if (updateCheckInterval) {
    clearInterval(updateCheckInterval);
    updateCheckInterval = null;
    console.log('RTConnect - Vérificateur de mise à jour arrêté');
  }
}

// Fonction pour vérifier si on est sur la page de recherche avancée des ordres de travail
function isPraxedoAdvancedSearchPage() {
  const isAdvancedSearch = window.location.href.includes('AdvancedSearchWorkOrder.do');
  console.log('🔍 RTConnect - Vérification page recherche avancée:', {
    url: window.location.href,
    isAdvancedSearch: isAdvancedSearch
  });
  return isAdvancedSearch;
}

// Fonction pour injecter les statuts de vérification sur la page de recherche avancée
async function injectVerificationStatusInSearchPage() {
  if (!isPraxedoAdvancedSearchPage()) {
    console.log('❌ RTConnect - Pas sur la page de recherche avancée, abandon');
    return;
  }
  
  console.log('🔍 RTConnect - Détection page recherche avancée Praxedo');
  console.log('📄 RTConnect - Taille du DOM:', document.body.innerHTML.length, 'chars');
  console.log('📄 RTConnect - Contenu visible:', document.body.innerText.length, 'chars');
  
  // Attendre que la page soit chargée avec un délai plus court
  setTimeout(async () => {
    try {
      await processInterventionNumbers();
    } catch (error) {
      console.error('RTConnect - Erreur traitement numéros intervention:', error);
    }
  }, 100); // Réduit de 500ms à 100ms
}

// Fonction pour traiter les numéros d'intervention dans la page
async function processInterventionNumbers() {
  console.log('🔢 RTConnect - === DÉBUT RECHERCHE NUMÉROS INTERVENTION ===');
  console.log('📍 URL actuelle:', window.location.href);
  
  // Rechercher tous les numéros d'intervention dans la page
  const interventionNumbers = new Set();
  
  // Méthode 1: Recherche dans tout le texte visible
  const pageText = document.body.innerText || document.body.textContent || '';
  console.log('📄 RTConnect - Taille texte page:', pageText.length, 'caractères');
  console.log('📄 RTConnect - Extrait du contenu:', pageText.substring(0, 500) + '...');
  
  // Pattern plus large pour les numéros d'intervention
  const patterns = [
    /\b\d{4,6}\b/g,  // 4 à 6 chiffres
    /\b\d{3,5}\b/g,  // 3 à 5 chiffres (au cas où)
    /WO\s*:?\s*(\d{4,6})/gi, // Pattern "WO: 12345"
    /Intervention\s*:?\s*(\d{4,6})/gi, // Pattern "Intervention: 12345"
    /Order\s*:?\s*(\d{4,6})/gi // Pattern "Order: 12345"
  ];
  
  patterns.forEach((pattern, index) => {
    const matches = pageText.match(pattern);
    if (matches) {
      console.log(`🔍 RTConnect - Pattern ${index + 1} trouvé:`, matches.slice(0, 10)); // Limiter à 10 pour les logs
      matches.forEach(match => {
        // Extraire le numéro si c'est un pattern avec groupe de capture
        const cleanMatch = match.replace(/\D/g, ''); // Enlever tout ce qui n'est pas un chiffre
        const num = parseInt(cleanMatch);
        if (num >= 1000 && num <= 999999) {
          interventionNumbers.add(cleanMatch);
        }
      });
    } else {
      console.log(`❌ RTConnect - Pattern ${index + 1} aucun match`);
    }
  });
  
  // Méthode 2: Recherche spécifique dans les éléments HTML
  console.log('🔍 RTConnect - Recherche dans les éléments HTML...');
  
  // Rechercher dans les tables
  const tables = document.querySelectorAll('table');
  console.log(`📋 RTConnect - ${tables.length} tables trouvées`);
  
  tables.forEach((table, tableIndex) => {
    const cells = table.querySelectorAll('td, th');
    console.log(`📋 RTConnect - Table ${tableIndex + 1}: ${cells.length} cellules`);
    
    cells.forEach((cell, cellIndex) => {
      const text = cell.textContent.trim();
      if (text.length > 0 && text.length < 20) { // Éviter les cellules trop longues
        const matches = text.match(/\b\d{4,6}\b/g);
        if (matches) {
          console.log(`📋 RTConnect - Table ${tableIndex + 1}, cellule ${cellIndex + 1}: "${text}" -> ${matches}`);
          matches.forEach(match => {
            const num = parseInt(match);
            if (num >= 1000 && num <= 999999) {
              interventionNumbers.add(match);
            }
          });
        }
      }
    });
  });
  
  // Méthode 3: Recherche dans les liens
  const links = document.querySelectorAll('a[href*="IntervAction"]');
  console.log(`🔗 RTConnect - ${links.length} liens d'intervention trouvés`);
  
  links.forEach((link, linkIndex) => {
    const href = link.href;
    const text = link.textContent.trim();
    console.log(`🔗 RTConnect - Lien ${linkIndex + 1}: href="${href}", text="${text}"`);
    
    // Rechercher dans l'URL du lien
    const urlMatches = href.match(/[?&](?:id|workorder|intervention)=(\d{4,6})/gi);
    if (urlMatches) {
      urlMatches.forEach(match => {
        const num = match.replace(/\D/g, '');
        if (num.length >= 4 && num.length <= 6) {
          interventionNumbers.add(num);
          console.log(`🎯 RTConnect - Numéro trouvé dans URL: ${num}`);
        }
      });
    }
    
    // Rechercher dans le texte du lien
    const textMatches = text.match(/\b\d{4,6}\b/g);
    if (textMatches) {
      textMatches.forEach(match => {
        const num = parseInt(match);
        if (num >= 1000 && num <= 999999) {
          interventionNumbers.add(match);
          console.log(`🎯 RTConnect - Numéro trouvé dans texte lien: ${match}`);
        }
      });
    }
  });
  
  // Méthode 4: Recherche dans les formulaires
  const forms = document.querySelectorAll('form');
  console.log(`📝 RTConnect - ${forms.length} formulaires trouvés`);
  
  forms.forEach((form, formIndex) => {
    const inputs = form.querySelectorAll('input[type="text"], input[type="number"], input[value]');
    console.log(`📝 RTConnect - Formulaire ${formIndex + 1}: ${inputs.length} champs`);
    
    inputs.forEach(input => {
      const value = input.value || input.getAttribute('value') || '';
      if (value.match(/^\d{4,6}$/)) {
        const num = parseInt(value);
        if (num >= 1000 && num <= 999999) {
          interventionNumbers.add(value);
          console.log(`📝 RTConnect - Numéro trouvé dans champ: ${value}`);
        }
      }
    });
  });
  
  console.log(`🔢 RTConnect - === RÉSULTAT RECHERCHE ===`);
  console.log(`🔢 RTConnect - ${interventionNumbers.size} numéros d'intervention uniques trouvés:`, Array.from(interventionNumbers));
  
  if (interventionNumbers.size === 0) {
    console.log('⚠️ RTConnect - Aucun numéro d\'intervention trouvé - Debug supplémentaire:');
    console.log('📄 RTConnect - Premier paragraphe de la page:', pageText.substring(0, 200));
    console.log('📄 RTConnect - Dernier paragraphe de la page:', pageText.substring(pageText.length - 200));
    
    // Lister tous les nombres trouvés pour debug
    const allNumbers = pageText.match(/\d+/g) || [];
    console.log('🔢 RTConnect - Tous les nombres dans la page:', allNumbers.slice(0, 20));
  }
  
  if (interventionNumbers.size > 0) {
    await addVerificationStatusToInterventions(Array.from(interventionNumbers));
  } else {
    console.log('❌ RTConnect - Aucun numéro d\'intervention à traiter');
  }
}

// Fonction pour ajouter les statuts de vérification aux numéros d'intervention
async function addVerificationStatusToInterventions(interventionNumbers) {
  console.log('📋 RTConnect - Ajout des statuts de vérification...');
  
  try {
    // Récupérer tous les statuts de vérification
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'getAllVerifications' },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(response);
          }
        }
      );
    });
    
    if (!response.success) {
      console.error('RTConnect - Erreur récupération vérifications:', response.error);
      return;
    }
    
    const verifications = response.data || [];
    console.log(`📊 RTConnect - ${verifications.length} vérifications trouvées en base`);
    
    // Créer un map numéro intervention -> vérification
    const verificationsByNumber = new Map();
    verifications.forEach(verification => {
      if (verification.interventionNumber) {
        verificationsByNumber.set(verification.interventionNumber, verification);
      }
    });
    
    // N'injecter des statuts que pour les interventions qui ont une vérification
    const interventionsWithVerification = interventionNumbers.filter(number => 
      verificationsByNumber.has(number)
    );
    
    console.log(`🎯 RTConnect - ${interventionsWithVerification.length}/${interventionNumbers.length} interventions ont une vérification`);
    
    // Injecter les statuts dans la page
    interventionsWithVerification.forEach(number => {
      const verification = verificationsByNumber.get(number);
      addStatusToInterventionNumber(number, verification);
    });
    
  } catch (error) {
    console.error('RTConnect - Erreur ajout statuts:', error);
  }
}

// Fonction pour ajouter le statut visuel à un numéro d'intervention
function addStatusToInterventionNumber(number, verification) {
  // Éviter de traiter si on n'a pas de vérification pour ce numéro
  if (!verification) return;
  
  // Rechercher d'abord dans les liens (plus spécifiques)
  const interventionLinks = document.querySelectorAll('a[href*="IntervAction"]');
  interventionLinks.forEach(link => {
    if (link.textContent.includes(number) || link.href.includes(number)) {
      addStatusIndicator(link, number, verification);
    }
  });
  
  // Puis rechercher dans les cellules de tableaux
  const tableCells = document.querySelectorAll('td, th');
  tableCells.forEach(cell => {
    const text = cell.textContent.trim();
    // Vérifier que c'est exactement le bon numéro (pas une partie d'un autre nombre)
    if (text === number || text.match(new RegExp(`\\b${number}\\b`))) {
      addStatusIndicator(cell, number, verification);
    }
  });
  
  // En dernier recours, recherche générale (limitée aux éléments visibles)
  const visibleElements = document.querySelectorAll('span, div, p');
  visibleElements.forEach(element => {
    const text = element.textContent.trim();
    if (text.length < 50 && text.match(new RegExp(`\\b${number}\\b`))) {
      addStatusIndicator(element, number, verification);
    }
  });
}

// Ajouter le gestionnaire de messages pour récupérer toutes les vérifications
// (sera ajouté au background.js séparément)

// Fonction pour ajouter l'indicateur de statut
function addStatusIndicator(element, number, verification) {
  // Éviter de dupliquer les indicateurs
  if (element.querySelector('.rtconnect-verification-status')) return;
  
  const statusIndicator = document.createElement('span');
  statusIndicator.className = 'rtconnect-verification-status';
  statusIndicator.style.cssText = `
    margin-left: 6px;
    margin-right: 6px;
    padding: 3px 6px;
    font-size: 14px;
    vertical-align: middle;
    cursor: help;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    background-color: rgba(255, 255, 255, 0.95);
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15);
    transition: all 0.15s ease;
    line-height: 1;
    min-width: 22px;
    min-height: 22px;
    text-align: center;
    position: relative;
    top: -1px;
    font-weight: normal;
  `;
  
  switch (verification.status) {
    case 'pending':
      statusIndicator.innerHTML = '⏳';
      statusIndicator.style.color = '#856404';
      statusIndicator.style.backgroundColor = '#fff3cd';
      statusIndicator.style.border = '1px solid #ffeaa7';
      statusIndicator.title = `Intervention ${number} - Vérification en attente de traitement`;
      break;
      
    case 'approved':
      statusIndicator.innerHTML = '✅';
      statusIndicator.style.color = '#155724';
      statusIndicator.style.backgroundColor = '#d4edda';
      statusIndicator.style.border = '1px solid #c3e6cb';
      statusIndicator.title = `Intervention ${number} - Vérification approuvée`;
      if (verification.comment) {
        statusIndicator.title += `\nCommentaire: ${verification.comment}`;
      }
      break;
      
    case 'rejected':
      statusIndicator.innerHTML = '❌';
      statusIndicator.style.color = '#721c24';
      statusIndicator.style.backgroundColor = '#f8d7da';
      statusIndicator.style.border = '1px solid #f5c6cb';
      statusIndicator.title = `Intervention ${number} - Vérification rejetée`;
      if (verification.comment) {
        statusIndicator.title += `\nRaison: ${verification.comment}`;
      }
      break;
  }
  
  // Effet hover
  statusIndicator.addEventListener('mouseenter', () => {
    statusIndicator.style.transform = 'scale(1.05) translateY(-1px)';
    statusIndicator.style.boxShadow = '0 3px 8px rgba(0, 0, 0, 0.25)';
    statusIndicator.style.zIndex = '9999';
  });
  
  statusIndicator.addEventListener('mouseleave', () => {
    statusIndicator.style.transform = 'scale(1) translateY(0)';
    statusIndicator.style.boxShadow = '0 1px 3px rgba(0, 0, 0, 0.15)';
    statusIndicator.style.zIndex = 'auto';
  });
  
  element.appendChild(statusIndicator);
}

// Fonction pour ajouter les statuts de vérification aux numéros d'intervention (optimisée)
async function addVerificationStatusToInterventions(interventionNumbers) {
  console.log('📋 RTConnect - Ajout des statuts de vérification...');
  
  try {
    // Récupérer tous les statuts de vérification
    const response = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'getAllVerifications' },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(response);
          }
        }
      );
    });
    
    if (!response.success) {
      console.error('RTConnect - Erreur récupération vérifications:', response.error);
      return;
    }
    
    const verifications = response.data || [];
    console.log(`📊 RTConnect - ${verifications.length} vérifications trouvées en base`);
    
    // Créer un map numéro intervention -> vérification
    const verificationsByNumber = new Map();
    verifications.forEach(verification => {
      if (verification.interventionNumber) {
        verificationsByNumber.set(verification.interventionNumber, verification);
      }
    });
    
    // N'injecter des statuts que pour les interventions qui ont une vérification
    const interventionsWithVerification = interventionNumbers.filter(number => 
      verificationsByNumber.has(number)
    );
    
    console.log(`🎯 RTConnect - ${interventionsWithVerification.length}/${interventionNumbers.length} interventions ont une vérification`);
    
    // Injecter les statuts dans la page
    interventionsWithVerification.forEach(number => {
      const verification = verificationsByNumber.get(number);
      addStatusToInterventionNumber(number, verification);
    });
    
  } catch (error) {
    console.error('RTConnect - Erreur ajout statuts:', error);
  }
}


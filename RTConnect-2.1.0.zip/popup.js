// RTConnect Popup Script - Version simplifiée avec auto-sync
document.addEventListener('DOMContentLoaded', async () => {
  console.log('🚀 Popup RTConnect chargé');
  
  // Récupérer la version depuis le manifest.json de l'extension
  const EXTENSION_VERSION = chrome.runtime.getManifest().version;
  console.log(`📦 Version de l'extension: ${EXTENSION_VERSION}`);
  
  const STORAGE_KEY = 'rtconnect_state';
  const CONFIG_KEY = 'rtconnect_config';
  
  // Configuration par défaut
  const DEFAULT_CONFIG = {
    environment: 'prod', // 'dev' ou 'prod'
    serverUrls: {
      dev: 'http://localhost:3001',
      prod: 'http://10.210.35.203:3001'
    }
  };

  // Variables globales pour la configuration
  let currentConfig = { ...DEFAULT_CONFIG };
  let SERVER_URL = currentConfig.serverUrls[currentConfig.environment];

  // Fonction pour charger la configuration
  async function loadConfig() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get([CONFIG_KEY], (result) => {
          if (chrome.runtime.lastError) {
            console.error('❌ Erreur chargement config:', chrome.runtime.lastError);
            resolve(DEFAULT_CONFIG);
            return;
          }
          const savedConfig = result[CONFIG_KEY];
          if (savedConfig) {
            currentConfig = { ...DEFAULT_CONFIG, ...savedConfig };
            console.log('📂 Configuration chargée:', currentConfig);
          } else {
            console.log('📂 Configuration par défaut utilisée');
          }
          SERVER_URL = currentConfig.serverUrls[currentConfig.environment];
          resolve(currentConfig);
        });
      } catch (error) {
        console.error('❌ Erreur chargement config:', error);
        resolve(DEFAULT_CONFIG);
      }
    });
  }

  // Fonction pour sauvegarder la configuration
  function saveConfig(config) {
    try {
      chrome.storage.local.set({ [CONFIG_KEY]: config }, () => {
        if (chrome.runtime.lastError) {
          console.error('❌ Erreur sauvegarde config:', chrome.runtime.lastError);
          return;
        }
        console.log('💾 Configuration sauvegardée:', config);
        // Notifier le background script du changement
        chrome.runtime.sendMessage({ 
          type: 'CONFIG_CHANGED', 
          config: config 
        }).catch(err => console.log('Background script pas encore prêt:', err));
      });
    } catch (error) {
      console.error('❌ Erreur sauvegarde config:', error);
    }
  }

  // Fonction pour mettre à jour l'environnement
  function updateEnvironment(newEnv) {
    currentConfig.environment = newEnv;
    SERVER_URL = currentConfig.serverUrls[newEnv];
    saveConfig(currentConfig);
    updateEnvironmentUI();
    
    // Rafraîchir le statut avec le nouveau serveur
    setTimeout(() => {
      checkServerStatus();
    }, 100);
  }

  // Fonction pour mettre à jour l'UI de l'environnement
  function updateEnvironmentUI() {
    const envOptions = document.querySelectorAll('.env-option');
    const currentUrlElement = document.getElementById('current-url');
    
    envOptions.forEach(option => {
      const env = option.dataset.env;
      if (env === currentConfig.environment) {
        option.classList.add('active');
      } else {
        option.classList.remove('active');
      }
    });
    
    if (currentUrlElement) {
      currentUrlElement.textContent = SERVER_URL;
    }
  }

  // Charger la configuration au démarrage
  await loadConfig();

  // Fonction pour gérer l'affichage de la section développeur
  function toggleDevSection() {
    const configSection = document.getElementById('config-section');
    const isVisible = configSection.classList.contains('visible');
    
    if (isVisible) {
      configSection.classList.remove('visible');
      saveDevSectionState(false);
      console.log('🔧 Section développeur masquée');
    } else {
      configSection.classList.add('visible');
      saveDevSectionState(true);
      console.log('🔧 Section développeur affichée');
    }
  }

  // Fonction pour sauvegarder l'état de la section développeur
  function saveDevSectionState(isVisible) {
    try {
      chrome.storage.local.set({ 'rtconnect_dev_section_visible': isVisible }, () => {
        if (chrome.runtime.lastError) {
          console.error('❌ Erreur sauvegarde état section dev:', chrome.runtime.lastError);
        }
      });
    } catch (error) {
      console.error('❌ Erreur sauvegarde état section dev:', error);
    }
  }

  // Fonction pour charger l'état de la section développeur
  function loadDevSectionState() {
    try {
      chrome.storage.local.get(['rtconnect_dev_section_visible'], (result) => {
        if (chrome.runtime.lastError) {
          console.error('❌ Erreur chargement état section dev:', chrome.runtime.lastError);
          return;
        }
        
        const isVisible = result.rtconnect_dev_section_visible;
        if (isVisible) {
          document.getElementById('config-section').classList.add('visible');
          console.log('🔧 Section développeur restaurée comme visible');
        }
      });
    } catch (error) {
      console.error('❌ Erreur chargement état section dev:', error);
    }
  }

  // Fonction pour obtenir les éléments DOM avec vérification
  function getDOMElements() {
    const requiredElements = {
      status: document.getElementById('status'),
      serverStatus: document.getElementById('server-status'),
      cookiesStatus: document.getElementById('cookies-status'),
      version: document.getElementById('version'),
      refreshBtn: document.getElementById('refresh-btn'),
      currentUrl: document.getElementById('current-url'),
      logo: document.getElementById('logo'),
      configSection: document.getElementById('config-section'),
      // Nouveaux éléments pour la notification
      updateOverlay: document.getElementById('update-overlay'),
      currentVersionSpan: document.getElementById('current-version'),
      newVersionSpan: document.getElementById('new-version'),
      updateBtnLater: document.getElementById('update-btn-later'),
      updateBtnDownload: document.getElementById('update-btn-download')
    };

    const missingElements = Object.entries(requiredElements)
      .filter(([key, element]) => !element)
      .map(([key]) => key);

    if (missingElements.length > 0) {
      throw new Error(`Éléments manquants: ${missingElements.join(', ')}`);
    }

    return requiredElements;
  }

  // Variable pour suivre si une requête est en cours
  let isRefreshing = false;
  let elements = null;

  try {
    elements = getDOMElements();
    
    // Configurer le gestionnaire de double-clic sur le logo
    let clickCount = 0;
    elements.logo.addEventListener('click', () => {
      clickCount++;
      setTimeout(() => {
        if (clickCount === 1) {
          // Simple clic - ne rien faire
        } else if (clickCount === 2) {
          // Double clic - toggle la section développeur
          toggleDevSection();
        }
        clickCount = 0;
      }, 300);
    });
    
    // Configurer les gestionnaires d'événements pour les options d'environnement
    const envOptions = document.querySelectorAll('.env-option');
    envOptions.forEach(option => {
      option.addEventListener('click', () => {
        const newEnv = option.dataset.env;
        if (newEnv !== currentConfig.environment) {
          updateEnvironment(newEnv);
        }
      });
    });
    
    // Charger l'état de la section développeur
    loadDevSectionState();
    
    // Initialiser l'UI de l'environnement
    updateEnvironmentUI();
    
  } catch (error) {
    console.error('❌ Erreur initialisation DOM:', error);
    return;
  }

  // Fonction pour sauvegarder l'état
  function saveState(state) {
    try {
      chrome.storage.local.set({ [STORAGE_KEY]: state }, () => {
        if (chrome.runtime.lastError) {
          console.error('❌ Erreur sauvegarde état:', chrome.runtime.lastError);
          return;
        }
        console.log('💾 État sauvegardé:', state);
      });
    } catch (error) {
      console.error('❌ Erreur sauvegarde état:', error);
    }
  }

  // Fonction pour restaurer l'état
  async function restoreState() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get([STORAGE_KEY], (result) => {
          if (chrome.runtime.lastError) {
            console.error('❌ Erreur restauration état:', chrome.runtime.lastError);
            resolve(null);
            return;
          }
          const state = result[STORAGE_KEY];
          console.log('📂 État restauré:', state);
          if (state) {
            updateUI(state);
          }
          resolve(state);
        });
      } catch (error) {
        console.error('❌ Erreur restauration état:', error);
        resolve(null);
      }
    });
  }

  // Fonction pour mettre à jour l'interface utilisateur
  function updateUI(state) {
    if (!state || !elements) {
      console.warn('⚠️ Impossible de mettre à jour l\'UI: état ou éléments manquants');
      return;
    }

    try {
      // Mettre à jour le statut du serveur
      if (state.serverConnected) {
        safeUpdateElement(elements.status, {
          className: 'status connected',
          innerHTML: '✅ Serveur connecté'
        });
      } else {
        safeUpdateElement(elements.status, {
          className: 'status disconnected',
          innerHTML: '❌ Serveur inaccessible - Démarrez le serveur'
        });
      }

      // Mettre à jour les autres éléments
      safeUpdateElement(elements.serverStatus, {
        textContent: state.serverStatus,
        style: { color: state.serverConnected ? '#28a745' : '#dc3545' }
      });

      safeUpdateElement(elements.cookiesStatus, {
        textContent: state.cookieStatus,
        style: { color: state.cookieStatus === 'Synchronisés' ? '#28a745' : '#ffc107' }
      });

      safeUpdateElement(elements.version, {
        textContent: `v${EXTENSION_VERSION}`,
        style: { color: state.needsUpdate ? '#ffc107' : '#28a745' }
      });
    } catch (error) {
      console.error('❌ Erreur mise à jour UI:', error);
    }
  }

  // Fonction pour mettre à jour un élément en toute sécurité
  function safeUpdateElement(element, updates) {
    try {
      if (!element) {
        console.warn('⚠️ Tentative de mise à jour d\'un élément null');
        return;
      }

      if (!document.body.contains(element)) {
        console.warn('⚠️ L\'élément n\'est plus dans le DOM');
        return;
      }

      if (typeof updates === 'object') {
        Object.entries(updates).forEach(([key, value]) => {
          try {
            if (!element) return; // Vérification supplémentaire
            
            if (key === 'innerHTML' || key === 'textContent') {
              element[key] = value;
            } else if (key === 'style' && typeof value === 'object') {
              Object.assign(element.style, value);
            } else if (key === 'className') {
              if (typeof value === 'string') {
                element.className = value;
              } else {
                console.warn('⚠️ Valeur invalide pour className:', value);
              }
            }
          } catch (updateError) {
            console.error(`❌ Erreur mise à jour ${key}:`, updateError);
          }
        });
      }
    } catch (error) {
      console.error('❌ Erreur mise à jour élément:', error);
    }
  }

  // Fonction pour comparer les versions
  function compareVersions(v1, v2) {
    try {
      const parts1 = v1.split('.').map(Number);
      const parts2 = v2.split('.').map(Number);
      
      for (let i = 0; i < 3; i++) {
        if (parts1[i] > parts2[i]) return 1;
        if (parts1[i] < parts2[i]) return -1;
      }
      return 0;
    } catch (error) {
      console.error('❌ Erreur comparaison versions:', error);
      return 0;
    }
  }

  // Fonction pour afficher la notification de mise à jour
  function showUpdateNotification(currentVersion, newVersion, updateUrl) {
    if (!elements.updateOverlay) return;

    console.log('🔔 Affichage de la notification de mise à jour');
    
    // Mettre à jour les informations de version
    elements.currentVersionSpan.textContent = currentVersion;
    elements.newVersionSpan.textContent = newVersion;
    
    // Ajouter le badge de notification sur la version
    elements.version.classList.add('version-badge');
    
    // Afficher l'overlay
    elements.updateOverlay.classList.add('show');
    
    // Gestionnaire pour "Plus tard"
    elements.updateBtnLater.onclick = () => {
      elements.updateOverlay.classList.remove('show');
      // Sauvegarder qu'on a rejeté cette version (pour ne pas la reproposer immédiatement)
      chrome.storage.local.set({ 
        'rtconnect_update_dismissed': newVersion,
        'rtconnect_update_dismissed_time': Date.now()
      });
      console.log('🔕 Notification de mise à jour reportée');
    };
    
    // Gestionnaire pour "Télécharger"
    elements.updateBtnDownload.onclick = () => {
      elements.updateOverlay.classList.remove('show');
      window.open(updateUrl, '_blank');
      console.log('📥 Ouverture du lien de téléchargement:', updateUrl);
    };
    
    // Fermer en cliquant sur l'overlay
    elements.updateOverlay.onclick = (e) => {
      if (e.target === elements.updateOverlay) {
        elements.updateOverlay.classList.remove('show');
      }
    };
  }

  // Fonction pour vérifier si on doit afficher la notification de mise à jour
  async function shouldShowUpdateNotification(newVersion) {
    return new Promise((resolve) => {
      chrome.storage.local.get(['rtconnect_update_dismissed', 'rtconnect_update_dismissed_time'], (result) => {
        const dismissedVersion = result.rtconnect_update_dismissed;
        const dismissedTime = result.rtconnect_update_dismissed_time;
        
        // Si c'est une version différente de celle rejetée, afficher
        if (dismissedVersion !== newVersion) {
          resolve(true);
          return;
        }
        
        // Si c'est la même version mais que ça fait plus de 24h, afficher à nouveau
        const now = Date.now();
        const hoursAgo = dismissedTime ? (now - dismissedTime) / (1000 * 60 * 60) : Infinity;
        
        if (hoursAgo > 24) {
          resolve(true);
        } else {
          resolve(false);
        }
      });
    });
  }

  // Fonction pour vérifier la version lors des checks de cookies
  async function checkVersionUpdate() {
    try {
      console.log('🔍 Vérification de version lors du check des cookies...');
      
      const serverResponse = await fetch(`${SERVER_URL}/api/status`);
      if (!serverResponse.ok) {
        console.log('⚠️ Impossible de récupérer les infos de version du serveur');
        return;
      }
      
      const serverData = await serverResponse.json();
      
      if (serverData.success && serverData.server && serverData.server.version) {
        const serverVersion = serverData.server.version;
        const versionCompare = compareVersions(serverVersion, EXTENSION_VERSION);
        const needsUpdate = versionCompare > 0;
        
        console.log(`🔍 Comparaison versions: Serveur=${serverVersion}, Extension=${EXTENSION_VERSION}, Mise à jour nécessaire=${needsUpdate}`);
        
        if (needsUpdate) {
          const shouldShow = await shouldShowUpdateNotification(serverVersion);
          if (shouldShow) {
            const updateUrl = serverData.updateUrl || 'https://math-frx.github.io/RTConnect/';
            showUpdateNotification(EXTENSION_VERSION, serverVersion, updateUrl);
          } else {
            console.log('🔕 Notification de mise à jour déjà reportée pour cette version');
          }
        } else {
          console.log('✅ Extension à jour');
          // Retirer le badge s'il y en a un
          elements.version.classList.remove('version-badge');
        }
      } else {
        console.log('⚠️ Version du serveur non disponible dans la réponse');
      }
    } catch (error) {
      console.error('❌ Erreur lors de la vérification de version:', error);
    }
  }

  // Fonction pour tester la connexion au serveur
  async function checkServerStatus() {
    if (isRefreshing || !elements) {
      console.log('⚠️ Vérification impossible: rafraîchissement en cours ou éléments non initialisés');
      return;
    }

    try {
      isRefreshing = true;
      console.log('🔍 Vérification du statut serveur...');
      
      // Vérifier le statut d'authentification
      const authResponse = await fetch(`${SERVER_URL}/api/auth/status`);
      const authData = await authResponse.json();
      
      console.log('🔐 Statut auth:', authData);

      // Créer l'état à sauvegarder
      const newState = {
        serverConnected: true,
        serverStatus: 'En ligne',
        cookieStatus: authData.cookieStatus === 'synchronized' ? 'Synchronisés' : 'Non synchronisés',
        lastCheck: new Date().toISOString(),
        needsUpdate: false // Géré séparément maintenant
      };

      // Mettre à jour l'UI et sauvegarder l'état
      updateUI(newState);
      saveState(newState);
      
      // Vérifier la version seulement si les cookies sont synchronisés
      if (authData.cookieStatus === 'synchronized') {
        console.log('🍪 Cookies synchronisés - Vérification de version...');
        setTimeout(() => checkVersionUpdate(), 500); // Petit délai pour ne pas surcharger
      }
      
    } catch (error) {
      console.error('❌ Erreur vérification serveur:', error);
      
      const errorState = {
        serverConnected: false,
        serverStatus: 'Hors ligne',
        cookieStatus: 'Indisponible',
        lastCheck: new Date().toISOString(),
        needsUpdate: false
      };

      updateUI(errorState);
      saveState(errorState);
    } finally {
      isRefreshing = false;
    }
  }

  // Gestionnaire pour le bouton actualiser
  if (elements.refreshBtn) {
    elements.refreshBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      
      // Revérifier les éléments DOM avant l'actualisation
      try {
        elements = getDOMElements();
      } catch (error) {
        console.error('❌ Éléments DOM non disponibles pour l\'actualisation:', error);
        return;
      }
      
      if (isRefreshing) {
        console.log('⚠️ Une actualisation est déjà en cours');
        return;
      }
      
      console.log('🔄 Actualisation manuelle du statut...');
      
      // Désactiver le bouton et montrer le chargement
      elements.refreshBtn.disabled = true;
      const originalText = elements.refreshBtn.innerHTML;
      elements.refreshBtn.innerHTML = '⏳ Actualisation...';
      
      try {
        await checkServerStatus();
        elements.refreshBtn.innerHTML = '✅ Actualisé';
      } catch (error) {
        console.error('❌ Erreur lors de l\'actualisation:', error);
        elements.refreshBtn.innerHTML = '❌ Erreur';
      } finally {
        setTimeout(() => {
          if (elements.refreshBtn) {
            elements.refreshBtn.innerHTML = originalText;
            elements.refreshBtn.disabled = false;
          }
        }, 1500);
      }
    });
  }

  // Gestionnaire pour le bouton vérifications techniques
  const verificationsBtn = document.getElementById('verifications-btn');
  if (verificationsBtn) {
    verificationsBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      
      console.log('📋 Ouverture page vérifications techniques...');
      
      // Désactiver le bouton et montrer le chargement
      verificationsBtn.disabled = true;
      const originalText = verificationsBtn.innerHTML;
      verificationsBtn.innerHTML = '⏳ Ouverture...';
      
      try {
        // Envoyer le message au background script pour ouvrir la page
        const response = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            { type: 'openVerificationsPage' },
            (response) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(response);
              }
            }
          );
        });
        
        if (response.success) {
          verificationsBtn.innerHTML = '✅ Ouvert';
          console.log('✅ Page vérifications ouverte:', response.url);
          
          // Fermer le popup après ouverture réussie
          setTimeout(() => {
            window.close();
          }, 1000);
        } else {
          throw new Error(response.error || 'Erreur lors de l\'ouverture');
        }
        
      } catch (error) {
        console.error('❌ Erreur ouverture page vérifications:', error);
        verificationsBtn.innerHTML = '❌ Erreur';
        
        // Fallback: essayer d'ouvrir directement l'URL
        setTimeout(() => {
          try {
            const SERVER_URL = currentConfig.serverUrls[currentConfig.environment];
            window.open(`${SERVER_URL}/verifications/`, '_blank');
            console.log('🔄 Ouverture en fallback mode');
            window.close();
          } catch (fallbackError) {
            console.error('❌ Erreur fallback:', fallbackError);
          }
        }, 1000);
        
      } finally {
        setTimeout(() => {
          if (verificationsBtn) {
            verificationsBtn.innerHTML = originalText;
            verificationsBtn.disabled = false;
          }
        }, 2000);
      }
    });
  }
  
  try {
    // Restaurer l'état au chargement
    const savedState = await restoreState();
    
    // Si pas d'état sauvegardé ou dernier check trop ancien (> 5 minutes), vérifier le statut
    if (!savedState || 
        !savedState.lastCheck || 
        (new Date() - new Date(savedState.lastCheck)) > 5 * 60 * 1000) {
      console.log('🔄 Vérification automatique nécessaire');
      await checkServerStatus();
    }
  } catch (error) {
    console.error('❌ Erreur initialisation état:', error);
  }
  
  console.log('✅ Popup RTConnect initialisé');
}); 
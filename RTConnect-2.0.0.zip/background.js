// RTConnect Background Script - Avec cache automatique des cookies
console.log('🚀 RTConnect Background Script chargé');

// Configuration du serveur avec option dev
const DEV_MODE = false; // Mettre à true pour le développement
const SERVER_URL = DEV_MODE ? 'http://localhost:3001' : 'http://10.210.35.203:3001';
let rdsCache = new Map();

// Cache automatique des cookies
let cookieAutoSync = {
  lastCheck: null,
  isServerReady: false,
  autoSyncEnabled: true
};

// Fonction pour récupérer les cookies du navigateur
async function getBrowserCookies() {
  try {
    console.log('🍪 Récupération des cookies du navigateur...');
    
    // Liste des configurations à essayer
    const configs = [
      { domain: 'ref-technique.linkt.lan', url: 'http://ref-technique.linkt.lan' },
      { domain: '.linkt.lan', url: 'http://ref-technique.linkt.lan' },
      { domain: 'linkt.lan', url: 'http://ref-technique.linkt.lan' }
    ];
    
    let allCookies = [];
    
    // Essayer chaque configuration
    for (const config of configs) {
      console.log(`\n🔍 Tentative pour ${config.domain}:`);
      
      try {
        // Essai 1: Par domaine
        let cookies = await chrome.cookies.getAll({ domain: config.domain });
        console.log(`  - Par domaine: ${cookies.length} cookies trouvés`);
        
        // Essai 2: Par URL
        let urlCookies = await chrome.cookies.getAll({ url: config.url });
        console.log(`  - Par URL: ${urlCookies.length} cookies trouvés`);
        
        // Fusionner les résultats uniques
        cookies = [...new Map([...cookies, ...urlCookies].map(c => [c.name, c])).values()];
        
        if (cookies.length > 0) {
          console.log(`✅ Total pour ${config.domain}: ${cookies.length} cookies uniques`);
          cookies.forEach(c => {
            console.log(`  - ${c.name}=${c.value.substring(0, 20)}... (domain: ${c.domain}, path: ${c.path})`);
          });
          allCookies = cookies;
          break;
        }
        
      } catch (configError) {
        console.log(`⚠️ Erreur pour ${config.domain}:`, configError.message);
      }
    }
    
    if (allCookies.length === 0) {
      // Dernière tentative: chercher tous les cookies
      console.log('\n🔍 Dernière tentative: recherche globale...');
      const allDomainCookies = await chrome.cookies.getAll({});
      console.log(`  - ${allDomainCookies.length} cookies totaux trouvés`);
      
      // Filtrer les cookies pertinents
      const relevantCookies = allDomainCookies.filter(c => 
        c.domain.includes('linkt') || 
        c.domain.includes('ref-technique')
      );
      
      if (relevantCookies.length > 0) {
        console.log(`✅ ${relevantCookies.length} cookies pertinents trouvés:`);
        relevantCookies.forEach(c => {
          console.log(`  - ${c.name}=${c.value.substring(0, 20)}... (domain: ${c.domain}, path: ${c.path})`);
        });
        allCookies = relevantCookies;
      } else {
        console.log('❌ Aucun cookie pertinent trouvé');
      }
    }
    
    if (allCookies.length === 0) {
      throw new Error('Aucun cookie trouvé après toutes les tentatives');
    }
    
    // Convertir en format Cookie header
    const cookieString = allCookies
      .map(cookie => `${cookie.name}=${cookie.value}`)
      .join('; ');
    
    console.log(`\n✅ Résultat final: ${allCookies.length} cookies (${cookieString.length} chars)`);
    return cookieString;
    
  } catch (error) {
    console.error('❌ Erreur récupération cookies:', error);
    throw error;
  }
}

// Fonction pour vérifier le statut des cookies du serveur
async function checkServerCookieStatus() {
  try {
    console.log('🔍 Vérification statut cookies serveur...');
    const response = await fetch(`${SERVER_URL}/api/auth/status`);
    const data = await response.json();
    
    console.log('📊 Statut serveur cookies:', data);
    
    return {
      success: data.success,
      hasCookies: data.hasCookies,
      isValid: data.isValid,
      needsRefresh: data.needsRefresh,
      lastUpdate: data.lastUpdate,
      lastValidation: data.lastValidation
    };
    
  } catch (error) {
    console.error('❌ Erreur vérification statut serveur:', error);
    return {
      success: false,
      needsRefresh: true,
      error: error.message
    };
  }
}

// Fonction pour envoyer les cookies au serveur
async function sendCookiesToServer(cookies) {
  try {
    console.log('📤 Envoi cookies vers serveur...');
    
    const response = await fetch(`${SERVER_URL}/api/auth/cookies`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ cookies })
    });
    
    const data = await response.json();
    
    if (data.success) {
      console.log('✅ Cookies envoyés avec succès:', data.message);
      return { success: true, data };
    } else {
      throw new Error(data.error || 'Erreur envoi cookies');
    }
    
  } catch (error) {
    console.error('❌ Erreur envoi cookies:', error);
    throw error;
  }
}

// Fonction de synchronisation automatique des cookies
async function autoSyncCookies(force = false) {
  try {
    console.log('🔄 Synchronisation automatique des cookies...');
    
    // Vérifier le statut du serveur
    const serverStatus = await checkServerCookieStatus();
    
    if (!serverStatus.success) {
      console.log('❌ Serveur non disponible pour sync cookies');
      return { success: false, error: 'Serveur non disponible' };
    }
    
    // Déterminer si on doit envoyer les cookies
    const needsSync = force || 
                     !serverStatus.hasCookies || 
                     !serverStatus.isValid || 
                     serverStatus.needsRefresh;
    
    if (!needsSync) {
      console.log('✅ Cookies serveur déjà valides, pas de sync nécessaire');
      return { success: true, alreadyValid: true };
    }
    
    console.log('🔄 Sync cookies nécessaire:', {
      force: force,
      hasCookies: serverStatus.hasCookies,
      isValid: serverStatus.isValid,
      needsRefresh: serverStatus.needsRefresh
    });
    
    // Récupérer les cookies du navigateur seulement si nécessaire
    let browserCookies;
    try {
      browserCookies = await getBrowserCookies();
    } catch (cookieError) {
      console.error('❌ Erreur récupération cookies navigateur:', cookieError);
      return { success: false, error: 'Impossible de récupérer les cookies du navigateur' };
    }
    
    // Si on a des cookies en cache côté serveur, les comparer avant d'envoyer
    if (serverStatus.hasCookies && !force) {
      console.log('🔍 Comparaison avec les cookies serveur existants...');
      
      // On fait un hash simple pour comparer sans exposer les cookies complets dans les logs
      const browserCookiesHash = btoa(browserCookies).slice(0, 20);
      console.log(`📝 Hash cookies navigateur: ${browserCookiesHash}`);
      
      // Pour une comparaison plus fine, on peut envoyer quand même mais le serveur optimisera
      console.log('📤 Envoi pour vérification côté serveur...');
    }
    
    // Envoyer au serveur
    const sendResult = await sendCookiesToServer(browserCookies);
    
    cookieAutoSync.lastCheck = new Date();
    cookieAutoSync.isServerReady = true;
    
    if (sendResult.data?.cached) {
      console.log('✅ Cookies déjà synchronisés côté serveur - Pas de changement');
    } else if (sendResult.data?.updated) {
      console.log('✅ Nouveaux cookies synchronisés avec succès');
    } else {
      console.log('✅ Synchronisation cookies terminée avec succès');
    }
    
    return { success: true, synced: !sendResult.data?.cached, result: sendResult };
    
  } catch (error) {
    console.error('❌ Erreur synchronisation cookies:', error);
    cookieAutoSync.isServerReady = false;
    return { success: false, error: error.message };
  }
}

// Fonction pour récupérer les données RDS avec auto-sync
async function fetchRDSData(rdsCode) {
  try {
    console.log(`📡 Requête RDS pour: ${rdsCode}`);
    
    // Vérifier le cache
    if (rdsCache.has(rdsCode)) {
      console.log(`📦 Cache hit pour ${rdsCode}`);
      return rdsCache.get(rdsCode);
    }
    
    // Tentative de récupération
    let response;
    let data;
    
    try {
      response = await fetch(`${SERVER_URL}/api/rds/${rdsCode}`);
      data = await response.json();
    } catch (serverError) {
      console.log(`⚠️ Serveur non accessible pour ${rdsCode}:`, serverError.message);
      return {
        success: false,
        error: 'Serveur inaccessible',
        serverOffline: true
      };
    }
    
    // Si erreur d'authentification, tenter auto-sync
    if (!data.success && (data.needsAuth || response.status === 401)) {
      console.log('🔑 Authentification requise, tentative auto-sync...');
      
      const syncResult = await autoSyncCookies(true);
      
      if (syncResult.success) {
        console.log('✅ Auto-sync réussi, nouvelle tentative RDS...');
        
        // Nouvelle tentative après sync
        try {
          response = await fetch(`${SERVER_URL}/api/rds/${rdsCode}`);
          data = await response.json();
        } catch (serverError) {
          console.log(`⚠️ Serveur non accessible après sync pour ${rdsCode}:`, serverError.message);
          return {
            success: false,
            error: 'Serveur inaccessible après sync',
            serverOffline: true
          };
        }
      } else {
        console.log('⚠️ Auto-sync échoué:', syncResult.error);
        return {
          success: false,
          error: 'Auto-sync impossible',
          needsManualAuth: true
        };
      }
    }
    
    // Mettre en cache si succès
    if (data.success) {
      console.log(`✅ Données RDS récupérées pour ${rdsCode}`);
      rdsCache.set(rdsCode, data);
      
      // Cache pendant 30 minutes
      setTimeout(() => {
        rdsCache.delete(rdsCode);
        console.log(`🗑️ Cache expiré pour ${rdsCode}`);
      }, 30 * 60 * 1000);
    } else {
      console.log(`⚠️ Réponse serveur non-succès pour ${rdsCode}:`, data.error);
    }
    
    return data;
    
  } catch (error) {
    console.log(`⚠️ Erreur générale fetch RDS ${rdsCode}:`, error.message);
    return {
      success: false,
      error: 'Erreur de communication',
      serverOffline: true
    };
  }
}

// Fonction pour tester la connectivité serveur
async function testServerConnection() {
  try {
    const response = await fetch(`${SERVER_URL}/api/status`);
    const data = await response.json();
    
    console.log('✅ Connexion serveur OK:', data);
    return { success: true, data };
    
  } catch (error) {
    console.error('❌ Erreur connexion serveur:', error);
    return { success: false, error: error.message };
  }
}

// Fonction pour récupérer les IPs en arrière-plan
async function fetchRDSIPs(rdsCode) {
  try {
    console.log(`📡 Requête IPs pour: ${rdsCode}`);
    
    const response = await fetch(`${SERVER_URL}/api/rds/${rdsCode}/ips`);
    const data = await response.json();
    
    if (data.success) {
      console.log(`✅ IPs récupérées pour ${rdsCode}:`, data.data);
      return {
        success: true,
        data: data.data
      };
    } else {
      console.log(`⚠️ Erreur récupération IPs pour ${rdsCode}:`, data.error);
      return {
        success: false,
        error: data.error
      };
    }
    
  } catch (error) {
    console.error(`❌ Erreur requête IPs ${rdsCode}:`, error);
    return {
      success: false,
      error: error.message,
      serverOffline: true
    };
  }
}

// Gestionnaire des messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Message reçu:', request);
  
  switch (request.type) {
    case 'fetchRDS':
      fetchRDSData(request.rdsCode)
        .then(sendResponse)
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
      
    case 'fetchRDSIPs':
      fetchRDSIPs(request.rdsCode)
        .then(sendResponse)
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
      
    case 'testConnection':
      testServerConnection()
        .then(sendResponse)
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
      
    case 'checkCookieStatus':
      checkServerCookieStatus()
        .then(sendResponse)
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
      
    case 'syncCookies':
      autoSyncCookies(true)
        .then(sendResponse)
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
      
    case 'manualSetCookies':
      sendCookiesToServer(request.cookies)
        .then(sendResponse)
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;
      
    default:
      console.log('❓ Type de message inconnu:', request.type);
      sendResponse({ success: false, error: 'Type de message inconnu' });
  }
});

// Auto-sync au démarrage (après 2 secondes)
setTimeout(async () => {
  console.log('🏁 Initialisation auto-sync cookies...');
  
  const connectionTest = await testServerConnection();
  if (connectionTest.success) {
    // Ne pas forcer la sync au démarrage, laisser le serveur décider
    const syncResult = await autoSyncCookies(false); // false = pas de force
    if (syncResult.success) {
      if (syncResult.alreadyValid) {
        console.log('✅ Auto-sync initial: cookies serveur déjà valides');
      } else if (syncResult.synced) {
        console.log('✅ Auto-sync initial: nouveaux cookies synchronisés');
      } else {
        console.log('✅ Auto-sync initial: cookies déjà à jour côté serveur');
      }
    } else {
      console.log('⚠️ Auto-sync initial échoué:', syncResult.error);
    }
  } else {
    console.log('⚠️ Serveur non disponible pour auto-sync initial');
  }
}, 2000);

// Auto-sync périodique (toutes les 5 minutes)
setInterval(async () => {
  if (cookieAutoSync.autoSyncEnabled) {
    console.log('🔄 Auto-sync périodique...');
    const syncResult = await autoSyncCookies();
    if (!syncResult.success && !syncResult.alreadyValid) {
      console.log('⚠️ Auto-sync périodique échoué:', syncResult.error);
    }
  }
}, 5 * 60 * 1000);

console.log('✅ RTConnect Background Script prêt avec auto-sync cookies'); 
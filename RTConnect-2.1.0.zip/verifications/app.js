// Variables globales
let verifications = [];
let filteredVerifications = [];
let currentVerification = null;
let lastKnownHash = null;
let pollInterval = null;

// Configuration API
const API_BASE_URL = getAPIBaseURL();
const POLL_INTERVAL = 10000; // 10 secondes au lieu de 30

// Éléments du DOM
const loadingMessage = document.getElementById('loadingMessage');
const errorMessage = document.getElementById('errorMessage');
const noDataMessage = document.getElementById('noDataMessage');
const verificationsContainer = document.getElementById('verificationsContainer');
const verificationsList = document.getElementById('verificationsList');
const pendingCount = document.getElementById('pendingCount');
const totalCount = document.getElementById('totalCount');
const statusFilter = document.getElementById('statusFilter');
const sortSelect = document.getElementById('sortSelect');
const retryBtn = document.getElementById('retryBtn');

// Éléments du modal
const reviewModal = document.getElementById('reviewModal');
const modalTitle = document.getElementById('modalTitle');
const modalUrlButton = document.getElementById('modalUrlButton');
const modalTitleText = document.getElementById('modalTitleText');
const modalSubmittedAt = document.getElementById('modalSubmittedAt');
const approveBtn = document.getElementById('approveBtn');
const rejectBtn = document.getElementById('rejectBtn');
const commentSection = document.getElementById('commentSection');
const rejectionComment = document.getElementById('rejectionComment');
const cancelReject = document.getElementById('cancelReject');
const confirmReject = document.getElementById('confirmReject');
const closeModal = document.getElementById('closeModal');

// Fonction pour obtenir l'URL de base de l'API
function getAPIBaseURL() {
    // Détecter l'environnement basé sur l'URL
    const hostname = window.location.hostname;
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
        return 'http://localhost:3001';
    } else {
        return 'http://10.210.35.203:3001';
    }
}

// Fonction pour charger les vérifications
async function loadVerifications() {
    try {
        showLoading();
        
        const response = await fetch(`${API_BASE_URL}/api/verifications`);
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            verifications = data.data || [];
            applyFiltersAndSort();
            updateStats();
            showVerifications();
        } else {
            throw new Error(data.error || 'Erreur lors du chargement des vérifications');
        }
        
    } catch (error) {
        console.error('Erreur chargement vérifications:', error);
        showError(`Impossible de charger les vérifications: ${error.message}`);
    }
}

// Fonction pour afficher l'état de chargement
function showLoading() {
    loadingMessage.style.display = 'block';
    errorMessage.style.display = 'none';
    noDataMessage.style.display = 'none';
    verificationsContainer.style.display = 'none';
}

// Fonction pour afficher une erreur
function showError(message) {
    document.getElementById('errorText').textContent = message;
    loadingMessage.style.display = 'none';
    errorMessage.style.display = 'block';
    noDataMessage.style.display = 'none';
    verificationsContainer.style.display = 'none';
}

// Fonction pour afficher les vérifications
function showVerifications() {
    loadingMessage.style.display = 'none';
    errorMessage.style.display = 'none';
    
    if (verifications.length === 0) {
        // Vraiment aucune demande de vérification
        noDataMessage.style.display = 'block';
        verificationsContainer.style.display = 'none';
        
        const noDataIcon = document.querySelector('.no-data-icon');
        const noDataTitle = noDataMessage.querySelector('h3');
        const noDataText = noDataMessage.querySelector('p');
        
        noDataIcon.textContent = '📋';
        noDataTitle.textContent = 'Aucune demande de vérification';
        noDataText.textContent = 'Les demandes de vérification technique apparaîtront ici une fois créées depuis les pages Praxedo.';
    } else {
        // Il y a des demandes, toujours afficher le container (avec filtres)
        noDataMessage.style.display = 'none';
        verificationsContainer.style.display = 'block';
        
        if (filteredVerifications.length === 0) {
            // Aucune demande avec le filtre actuel
            verificationsList.innerHTML = '';
            
            const currentFilter = statusFilter.value;
            const filterText = {
                'pending': 'en attente',
                'approved': 'approuvées', 
                'rejected': 'rejetées',
                'all': ''
            };
            
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'empty-filter-message';
            emptyMessage.style.cssText = `
                text-align: center;
                padding: 40px 20px;
                color: #6c757d;
                background: #f8f9fa;
                border-radius: 8px;
                margin: 20px 0;
            `;
            
            emptyMessage.innerHTML = `
                <div style="font-size: 48px; margin-bottom: 16px;">🔍</div>
                <h3 style="margin: 0 0 8px 0; color: #495057;">Aucune demande ${filterText[currentFilter]}</h3>
                <p style="margin: 0; font-size: 14px;">Il y a ${verifications.length} demande(s) au total, mais aucune avec le statut "${filterText[currentFilter]}".<br>Changez le filtre ci-dessus pour voir les autres demandes.</p>
            `;
            
            verificationsList.appendChild(emptyMessage);
        } else {
            // Il y a des demandes avec le filtre actuel
            renderVerifications();
        }
    }
}

// Fonction pour appliquer les filtres et tri
function applyFiltersAndSort() {
    const statusValue = statusFilter.value;
    const sortValue = sortSelect.value;
    
    // Filtrer par statut
    filteredVerifications = verifications.filter(verification => {
        if (statusValue === 'all') return true;
        return verification.status === statusValue;
    });
    
    // Trier
    filteredVerifications.sort((a, b) => {
        switch (sortValue) {
            case 'newest':
                return new Date(b.submittedAt) - new Date(a.submittedAt);
            case 'oldest':
                return new Date(a.submittedAt) - new Date(b.submittedAt);
            case 'status':
                const statusOrder = { pending: 0, approved: 1, rejected: 2 };
                return statusOrder[a.status] - statusOrder[b.status];
            default:
                return 0;
        }
    });
}

// Fonction pour mettre à jour les statistiques
function updateStats() {
    const pending = verifications.filter(v => v.status === 'pending').length;
    const total = verifications.length;
    
    pendingCount.textContent = `${pending} en attente`;
    totalCount.textContent = `${total} total`;
}

// Fonction pour rendre les vérifications
function renderVerifications() {
    verificationsList.innerHTML = '';
    
    filteredVerifications.forEach(verification => {
        const card = createVerificationCard(verification);
        verificationsList.appendChild(card);
    });
}

// Fonction pour créer une carte de vérification
function createVerificationCard(verification) {
    const card = document.createElement('div');
    card.className = `verification-card ${verification.status}`;
    card.dataset.id = verification._id;
    
    const statusText = {
        pending: 'En attente',
        approved: 'Approuvé',
        rejected: 'Rejeté'
    };
    
    const submittedDate = new Date(verification.submittedAt).toLocaleString('fr-FR');
    const reviewedDate = verification.reviewedAt ? 
        new Date(verification.reviewedAt).toLocaleString('fr-FR') : '';
    
    card.innerHTML = `
        <div class="verification-header">
            <div class="verification-title-section">
                <div class="verification-title">${verification.title}</div>
                ${verification.interventionNumber ? `
                    <div class="intervention-number">📋 Intervention: ${verification.interventionNumber}</div>
                ` : ''}
            </div>
            <div class="verification-status">
                <span class="status-badge ${verification.status}">${statusText[verification.status]}</span>
            </div>
        </div>
        
        <div class="verification-info">
            <div class="info-item">
                <span class="info-label">Date de soumission</span>
                <span class="info-value">${submittedDate}</span>
            </div>
            ${verification.reviewedAt ? `
                <div class="info-item">
                    <span class="info-label">Date de vérification</span>
                    <span class="info-value">${reviewedDate}</span>
                </div>
            ` : ''}
        </div>
        
        ${verification.comment ? `
            <div class="verification-comment">
                <div class="comment-label">Commentaire</div>
                <div class="comment-text">${verification.comment}</div>
            </div>
        ` : ''}
    `;
    
    // Ajouter l'événement de clic seulement si en attente
    if (verification.status === 'pending') {
        card.addEventListener('click', () => openReviewModal(verification));
        card.style.cursor = 'pointer';
    } else {
        card.style.cursor = 'default';
    }
    
    return card;
}

// Fonction pour ouvrir le modal de révision
function openReviewModal(verification) {
    currentVerification = verification;
    
    modalUrlButton.innerHTML = '🔗 Ouvrir la page Praxedo';
    modalUrlButton.onclick = () => {
        window.open(verification.url, '_blank');
    };
    modalTitleText.textContent = verification.title;
    modalSubmittedAt.textContent = new Date(verification.submittedAt).toLocaleString('fr-FR');
    
    // Afficher le numéro d'intervention
    const modalInterventionNumber = document.getElementById('modalInterventionNumber');
    if (modalInterventionNumber) {
        modalInterventionNumber.textContent = verification.interventionNumber || 'Non disponible';
    }
    
    // Réinitialiser le modal
    commentSection.style.display = 'none';
    rejectionComment.value = '';
    
    reviewModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

// Fonction pour fermer le modal
function closeReviewModal() {
    reviewModal.style.display = 'none';
    document.body.style.overflow = 'auto';
    currentVerification = null;
}

// Fonction pour approuver une vérification
async function approveVerification() {
    if (!currentVerification) return;
    
    try {
        approveBtn.disabled = true;
        approveBtn.innerHTML = '⏳ Traitement...';
        
        const response = await fetch(`${API_BASE_URL}/api/verifications/${currentVerification._id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: 'approved',
                comment: '',
                reviewedBy: 'Vérificateur technique'
            })
        });
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            closeReviewModal();
            // Forcer le rechargement immédiat après action
            lastKnownHash = null; // Réinitialiser pour forcer le rechargement
            await loadVerifications(); // Recharger la liste
        } else {
            throw new Error(data.error || 'Erreur lors de l\'approbation');
        }
        
    } catch (error) {
        console.error('Erreur approbation:', error);
        alert(`Erreur lors de l'approbation: ${error.message}`);
    } finally {
        approveBtn.disabled = false;
        approveBtn.innerHTML = '✅ Approuver la demande';
    }
}

// Fonction pour commencer le processus de rejet
function startRejectProcess() {
    commentSection.style.display = 'block';
    rejectionComment.focus();
}

// Fonction pour annuler le rejet
function cancelRejectProcess() {
    commentSection.style.display = 'none';
    rejectionComment.value = '';
}

// Fonction pour confirmer le rejet
async function confirmRejectVerification() {
    if (!currentVerification) return;
    
    const comment = rejectionComment.value.trim();
    if (!comment) {
        alert('Un commentaire est obligatoire pour le rejet.');
        rejectionComment.focus();
        return;
    }
    
    try {
        confirmReject.disabled = true;
        confirmReject.innerHTML = '⏳ Traitement...';
        
        const response = await fetch(`${API_BASE_URL}/api/verifications/${currentVerification._id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: 'rejected',
                comment: comment,
                reviewedBy: 'Vérificateur technique'
            })
        });
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success) {
            closeReviewModal();
            // Forcer le rechargement immédiat après action
            lastKnownHash = null; // Réinitialiser pour forcer le rechargement
            await loadVerifications(); // Recharger la liste
        } else {
            throw new Error(data.error || 'Erreur lors du rejet');
        }
        
    } catch (error) {
        console.error('Erreur rejet:', error);
        alert(`Erreur lors du rejet: ${error.message}`);
    } finally {
        confirmReject.disabled = false;
        confirmReject.innerHTML = 'Confirmer le rejet';
    }
}

// Gestionnaires d'événements
retryBtn.addEventListener('click', loadVerifications);

statusFilter.addEventListener('change', () => {
    applyFiltersAndSort();
    showVerifications();
});

sortSelect.addEventListener('change', () => {
    applyFiltersAndSort();
    showVerifications();
});

// Gestionnaires du modal
closeModal.addEventListener('click', closeReviewModal);
approveBtn.addEventListener('click', approveVerification);
rejectBtn.addEventListener('click', startRejectProcess);
cancelReject.addEventListener('click', cancelRejectProcess);
confirmReject.addEventListener('click', confirmRejectVerification);

// Fermer le modal en cliquant à l'extérieur
reviewModal.addEventListener('click', (e) => {
    if (e.target === reviewModal) {
        closeReviewModal();
    }
});

// Fermer le modal avec Escape
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && reviewModal.style.display === 'flex') {
        closeReviewModal();
    }
});

// Fonction pour vérifier s'il y a des changements (polling optimisé)
async function checkForChanges() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/verifications/changes`);
        
        if (!response.ok) {
            console.warn('Impossible de vérifier les changements, passage au polling normal');
            return { hasChanges: true }; // Si on ne peut pas vérifier, on assume qu'il y a des changements
        }
        
        const data = await response.json();
        
        if (data.success) {
            const currentHash = data.data.hash;
            const hasChanges = lastKnownHash !== null && lastKnownHash !== currentHash;
            
            // Mettre à jour les statistiques même sans changement complet
            if (data.data.stats) {
                const pendingSpan = document.getElementById('pendingCount');
                const totalSpan = document.getElementById('totalCount');
                if (pendingSpan) pendingSpan.textContent = `${data.data.stats.pending} en attente`;
                if (totalSpan) totalSpan.textContent = `${data.data.stats.total} total`;
            }
            
            console.log(`🔍 Vérification changements: hash=${currentHash.substring(0, 8)}..., changes=${hasChanges}`);
            
            // Mettre à jour le hash connu
            lastKnownHash = currentHash;
            
            return { 
                hasChanges: hasChanges || lastKnownHash === null, // Toujours vrai au premier passage
                stats: data.data.stats
            };
        }
        
        return { hasChanges: true }; // En cas d'erreur, on assume qu'il y a des changements
        
    } catch (error) {
        console.warn('Erreur vérification changements:', error);
        return { hasChanges: true }; // En cas d'erreur, on assume qu'il y a des changements
    }
}

// Fonction de polling intelligent
async function intelligentPoll() {
    const changeResult = await checkForChanges();
    
    if (changeResult.hasChanges) {
        console.log('🔄 Changements détectés, rechargement des données...');
        await loadVerifications();
    } else {
        console.log('✅ Aucun changement détecté, pas de rechargement nécessaire');
    }
}

// Démarrer le polling intelligent
function startIntelligentPolling() {
    // Arrêter le polling existant s'il y en a un
    if (pollInterval) {
        clearInterval(pollInterval);
    }
    
    console.log(`⏰ Démarrage polling intelligent (toutes les ${POLL_INTERVAL/1000}s)`);
    pollInterval = setInterval(intelligentPoll, POLL_INTERVAL);
}

// Arrêter le polling
function stopIntelligentPolling() {
    if (pollInterval) {
        clearInterval(pollInterval);
        pollInterval = null;
        console.log('⏹️ Polling intelligent arrêté');
    }
}

// Charger les vérifications au démarrage
document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 Démarrage application de gestion des vérifications');
    await loadVerifications();
    startIntelligentPolling();
});

// Nettoyer le polling lors de la fermeture de la page
window.addEventListener('beforeunload', () => {
    stopIntelligentPolling();
}); 